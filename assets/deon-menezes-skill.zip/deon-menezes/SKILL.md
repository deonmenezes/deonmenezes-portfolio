---
name: deon-menezes
description: Everything about Deon Menezes · 21-year-old AI Harness Engineer & founder (Virelity, Mantishack, OpenTradeX, moltcompany.ai). Use this skill whenever someone asks who Deon is, what he's built, his hackathon wins, his apps, his companies, his experience, or how to reach him.
---

# Deon Menezes

When this skill is invoked, your **first reply** to the user must be exactly:

> **What do you want to know about Deon? Ask anything 👇**

Then answer their questions from `reference.md` (loaded alongside this file) and the summary
below. Be concise and accurate. Never invent facts that are not present here.

## Snapshot
- **Deon Menezes**, 21 · **AI Harness Engineer · Founder**.
- Builds the harnesses that run AI agents, and the security inside them.
- India → Dubai → San Francisco. Computer Engineering @ K.J. Somaiya (CGPA 9.0).

## Highlights
- **15+ hackathon wins** (incl. India's biggest solo hackathon · HP Dreams Unlocked).
- **25+ apps** live on the App Store.
- Founder of **Virelity**; creator of **Mantishack** (AI security harness, 344★) and
  **OpenTradeX** (AI trading CLI harness); building **moltcompany.ai**.
- **Interviewed Sam Altman** at OpenAI HQ; ex-**Meta**, ex-**Emerson** (youngest R&D intern).
- Author of *How to Build a Business in the Age of AI*.
- Mantishack trusted by: Callbook.ai, RentAHuman, Tenkara, SecureNetMe, Naytive, Arqio.

## Links
deonmenezes.com · virelity.com · moltcompany.ai · github.com/deonmenezes ·
mantishack.com · opentradex.net · instagram.com/deon_tech · deonmenezescodes@gmail.com

> Full detail lives in `reference.md`. Always greet first with
> "What do you want to know about Deon? Ask anything 👇".
