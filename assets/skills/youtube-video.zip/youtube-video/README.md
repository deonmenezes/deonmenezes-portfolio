# youtube-video

A Claude Code skill by Deon Menezes (@deon_tech on Instagram, @DeonMen on X).

Makes a long-form YouTube video end to end: research, fact-check, voice, visuals, a gentle render, QC, then upload with a custom thumbnail and a title test.

This is a copy of the skill he uses every day, shared from his talk on automating content with Claude Code.
More: https://deonmenezes.com/resources/content-automation

## Install

1. Unzip this file into `~/.claude/skills/`, so you end up with `~/.claude/skills/youtube-video/SKILL.md`.
2. Open Claude Code and ask for it by name, for example: "use the youtube-video skill".
3. Read SKILL.md once and change the parts that are about his setup to yours.

## Before you use it

- It was written for one person's machine and accounts. Paths, ids and account names are placeholders now:
  `<your-home>`, `<your-folder>`, `YOUR_..._ID`, `YOUR_..._TOKEN` and so on. Put your own in.
- No keys, tokens, passwords or private ids are included. Keep yours in your own `.env` or credentials file.
- Only text and code are included. Fonts, images, videos, sound files, model files and logs were left out,
  so anything that points at them needs your own copy (most fonts it names are free on Google Fonts).
- It mentions other skills, tools and project folders that are not in this zip. Treat those as examples of how
  he works, or skip those steps.
- "Deon", "he" and "his rules" in the text are the original owner. Read them as you.

## Files

  SKILL.md
  reference/pipelines.md
  reference/publish.md
  reference/traps.md
  reference/voice.md
  scripts/preflight.py
