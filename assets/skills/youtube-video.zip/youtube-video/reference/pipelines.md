# The pipelines, one per visual style

Checked on disk 2026-10-08. Every folder below exists. They are the finished projects of earlier videos: **read
and copy from them, never edit or render inside them.** A new video gets its own folder, `<your-folder>/<slug>-video`
(E: had 0.3 GB free on 2026-10-08; `preflight.py` says which drive has room).

All of them share one shape: `script.py` holds `SEGMENTS = [("s00_name", [paragraph, ...]), ...]`, one paragraph
is one beat is one voice take, and the voice step writes `audio/<seg>.mp3` plus `audio/<seg>.json` (duration,
beat start times, a start and end time for every character). Visuals are timed by naming the words they start on,
never by typing seconds.

## 1. Documentary: real screenshots, source cards, optional clips (the default)

"You know the drill of how we make youtube videos" (2026-10-07) means this one. Three published: AI and God
(youtu.be/JCkmHZZAWr4), the Vals magnet (youtu.be/Oepv0yTF0U4), OpenAI 722 papers (youtu.be/cs26cS0XjdM).

Start from `<your-folder>/openai-math-video` (the newest; it has every helper and the gentle settings everywhere).

```bash
NEW=<your-folder>/<slug>-video; T=<your-folder>/openai-math-video
mkdir -p $NEW/thumb $NEW/research $NEW/shots $NEW/sources $NEW/clips
cp $T/*.py $NEW/ && cp -r $T/fonts $T/music.mp3 $NEW/
cp $T/thumb/make_thumb.py $NEW/thumb/; cp $T/research/fetch.py $NEW/research/; cp $T/shots/make_jobs.py $NEW/shots/
cd $NEW && mv script.py script_openai_example.py && mv shots.py shots_openai_example.py
rm build_before_review.py shots_before_review.py script_vals_example.py shots_vals_example.py
```

Then change, in the copy: `TITLE`, `FINAL` and the `SPECIAL` dict in `build.py`; the segment name in
`concat()` that the title card follows (`if seg == "s00_cold"`: the title card plays AFTER the cold open, not at
0:00); `VIDEO`, `TITLE`, `TAGS` in `upload_yt.py`; the job list in `shots/make_jobs.py`; `thumb/make_thumb.py`.

| step | command | what it does |
| --- | --- | --- |
| research | `python research/fetch.py <url> research/<name>.txt` | page text and links through headless Chrome, for sites that 403 WebFetch |
| script | `script.py`, then the youtube-script linter | see SKILL.md steps 2 and 3 |
| voice | `python vapi_narrate.py` | missing takes only (`audio/vparts/<seg>_<i>.mp3`), aligned with faster-whisper small.en on 4 threads, joined per segment. `--assemble` only re-joins. To re-voice a paragraph, move its two files out of `vparts` and run again |
| voice check | `python tail_check.py` | flags a take whose last words or word count do not match the script |
| screenshots | `python shots/make_jobs.py` then `PYTHONIOENCODING=utf-8 python pw_shots.py shots/jobs_a.json [name ...]` | the real page with the sentence highlighted (T = top of page, H = highlighted phrase) |
| tweets | `python tw.py name=<status id>[:thread][:nomedia]` | the real post from the public embed page, times in UTC |
| long tweets | `python tw_full.py name=<handle>/<status id>` | the embed cuts at "Show more"; this opens x.com logged out |
| Hacker News | `python hn_b.py name=<item id> ["phrase"] [width]` | one comment or the story header, nothing else |
| PDFs | `python pdf_shot_b.py <pdf> <page index> <out.png> "<phrase>"` | a region of the page, phrase highlighted with the PDF's own text search |
| fixes | `retake.py` (popups, blank captures), `crop_b.py` (crop only), `figs.py` (a source's own SVG diagrams) | each appends a line to `shots/jobs.log` |
| look | `python build.py cards`, `python card_sheets.py` | every `shots/*.png` becomes a 1920x1080 card; contact sheets with file names in `out/sheets/`. Read the sheets |
| shot list | `shots.py` | `SHOTS[seg][beat] = [(anchor words, card or clip, in_seconds, opts?)]`; `OVERLAYS = [(seg, beat, anchor, kind, payload, opts?)]`, kinds `label date def quote stat src` |
| dry run | `python build.py check` | every shot and overlay resolved against the audio timing, missing files listed, no rendering |
| cut | `python build.py cut [seg ...]` | `out/<seg>_base.mp4`. Cuts are cached by a key that includes the source's mtime, so a rebuilt card is re-cut |
| overlay | `python watch_mem.py overlay [seg ...]` | `out/<seg>.mp4` with overlays and narration; stops the step if free RAM falls under 5 GB |
| verify | `python verify_ov.py [seg ...]` | each overlay must change the frame inside its box while it is up. Exit 1 if one is missing |
| join | `python build.py concat` | title card, segments, looped music bed at 0.20 ducked under the voice, loudnorm to -16 LUFS |
| QC | `python qc_final.py [n]` | stream facts, chapter offsets for the description, contact sheets in `out/qc/` of frames taken while overlays are up |
| thumbnails | `python thumb/make_thumb.py [background.png]` | three 1280x720 title/thumbnail variants; with no background it builds one from the source's own pages |
| upload | `python upload_yt.py`, later `--poll` | see publish.md |

Overlay kinds and the rule each serves: `def` is the on-screen definition every term needs; `quote` carries the
exact words of a source; `src` names the source when the narration paraphrases; `stat` is a big number (pass
`"right"` when the left panel would cover the highlighted sentence); `label` names the person or outlet; `date`
fixes when. Tie a `quote` or `src` to its sentence with `{"to": "last words", "hold": 0.4}`.

Clips and soundbites (real footage, someone speaking for themselves) use the same `build.py`. The worked example
is `<your-folder>/religion-video`: `dl.sh <youtube id> <name> [start-end]` into `clips/`, `python sheets.py <name>` for a
timestamped contact sheet, `python transcribe.py` for word times, and a beat written as
`{"clip": name, "from": "first words", "to": "last words", "label": (who, where)}` plays the clip's own audio.
`audition.py` and `voice_stats.py` there compare Vapi voices on one paragraph. Its `vapi_narrate.py` runs whisper
on all cores: use the openai-math copy.

`<your-folder>/vals-video` is the same pipeline one video earlier; its `thumb/variants.py` is the Gemini-background
thumbnail route. `<your-folder>/rust-video` is the oldest clip edit (`build_edit.py`, `clips.py`): do not start from it, its
cut cache ignores changed shots. Its `script_human_draft.py` is the youtube-script skill's worked example.

Numbers from the last one: 17.8 min, 183 card shots, 9.0 GB project folder, 1.4 GB final.

## 2. Calm motion-graphics explainer (Remotion)

`<your-folder>/sonnet55-video`, published as youtu.be/9QnYYjhoVb0 (7:43). Use it for a launch explained with benchmarks,
what changed and what people built, when it has to be out the same day.

`script.py` (beats, `CUES` phrases, `DEFS` cards, `TITLES`) -> `tts.py` -> `timeline.py` (phrase to seconds, writes
`src/data.json` and `audio/voice.wav`) -> scenes in `src/scenes1.tsx`, `src/scenes2.tsx`, `src/parts.tsx` ->
`node stills.mjs [seg]` (stills at the times in `stills/picks.json`; look before rendering) ->
`npx remotion render src/index.ts Full out/silent.mp4 --muted` (about 4 min for 13.9k frames) -> `mux.sh` (voice,
ducked music, loudnorm -14) -> `node thumbs.mjs` (two thumbnails from `src/Thumb.tsx`).

- `node_modules` is a junction to `<your-folder>/inference-video/overlay/node_modules`. A copied project needs the same
  junction, not an `npm install` (E: has no room).
- `mux.sh` has `cd <your-folder>/sonnet55-video` and the music path hard-coded: fix both in the copy.
- `tts.py` is the ElevenLabs clone route (voice.md). To use a Vapi voice, take `vapi_narrate.py` and
  `vapi_tts.py` from the documentary template; they write the same `audio/<seg>.mp3|json`.
- Remotion renders on many cores by default. Capping it (`--concurrency`) has not been tried on this PC: tell
  Deon before the render and run nothing else beside it.
- He has called flat motion graphics "vibe coded". Use real tweet and benchmark cards inside it, with handle,
  stats and a source footer.

## 3. Hand-drawn sketch (Remotion)

`<your-folder>/sonnet55-sketch`, published as youtu.be/NKoeHkv4Gzk. Use it when he asks for "hand-drawn", "plain white,
artistic", reactions on screen. Same steps as 2 with a different kit: `src/kit.tsx` (Permanent Marker, Patrick
Hand and Caveat fonts, a "boiling line" SVG filter, sticky-note definition cards, reaction stickers fired by
`REACTS` in `script.py`, a mascot whose mouth follows `src/amp.json`).

- Voice: use `tts_v2.py` (the clone on its normal settings). `tts.py` there is the loud eleven_v3 version he
  rejected as "not my voice"; `audio_v3_rejected/` is that take.
- The filter makes frames heavy: about 8 min to render, 263 MB at crf 17. Re-encode at crf 24 for upload.

## 4. Manim, 3Blue1Brown style

`<your-folder>/harness-video`, published as youtu.be/8gP9Oj_rSPA (20.7 min). Use it for a book, a paper or one idea built
up from first principles, when he says "like 3blue1brown" or "fully animated" and does not want 3D.
(`<your-folder>/inference-video` holds the first Manim video in `scenes/`, `common.py`, `build.py`; harness is the better copy.)

`script.py` (`SEGMENTS`, `DEFS` = definition sentences copied word for word from the narration) -> `STYLE.md` and
`BRIEFS.md` (one brief per scene) -> `python fake_align.py` (scaffold timing at 3.35 words/s so scenes can be
written before the voice exists; real audio overwrites it) -> `scenes/<seg>.py` on `common.py`'s `SyncScene`
(`self.beat(i)`, `self.word("phrase")`, `run_time=self.until("phrase")`) -> `python qc.py <seg>` (480p15 render,
`[sync]` problems, labelled contact sheets in `stills/`) -> voice (`vapi_narrate.py` or `tts.py`) ->
`python build.py render assemble` -> `python qc.py <seg>` again against the real timing.

- Every `DEFS` sentence found in a segment's narration appears by itself as a dictionary card in the bottom
  band. Scenes only have to keep y < -2.35 clear.
- Seven forks wrote the scenes in parallel from `BRIEFS.md`. Writing is light; rendering is not: one `qc.py` at a
  time (two collide on `partial_movie_files`).
- `build.py render` runs four 1080p renders at once (`ThreadPoolExecutor(4)`). That predates the crash diagnosis.
  In the copy set it to 1, or render one scene per call.
- `times.py <seg>` prints each sentence's start and end. `python tts.py` needs ElevenLabs credits (about 22,100
  for a 20-minute script).
- No LaTeX is installed: `Text` only, no `MathTex`. Fonts: see traps.md.
- `thumbs.py` in `<your-folder>/inference-video` renders three thumbnails with Manim.

## 5. Blender 3D with Remotion cards

`<your-folder>/inference-video` (`b3d/kit.py`, `b3d/ART.md`, `b3d/scenes/`, `overlay/`). Finished as a 20.3 min file on
2026-09-28 and **never published**: he picked the Manim version to upload. Use it only when he asks for "3D" or
"cinematic", and tell him the cost first.

`render_all.py` (Blender 5.2 EEVEE to resumable JPEG frames, then one mp4 per segment) -> `render_fixes.py`
(re-renders the ranges in `out/fixes.txt`; the numbers are SECONDS) -> `assemble_v4.py stage|remotion|music`
(Remotion lays definition cards, chapter titles and narration over the 3D; about 35 min).

- About 0.8 s a frame at 1080p on the 4090, so a 20-minute video is roughly eight hours of GPU work (my
  arithmetic from that rate, not a measured total).
- `render_all.py` has `JOBS = 2`: set it to 1 in the copy.
- The 3D carries almost no text. Definitions and titles come from the overlay.

## 6. Cartoon, with his own recorded voice-over

`<your-folder>/mashup-edit`, published as youtu.be/brBxSJEz9h0 (3:47). Use it when he says "animated", points at the Agent
Flappy reference (youtu.be/yJBETduh0WM), or wants a countdown he narrates himself.

1. Script first (youtube-script skill), opened in Notepad for him to read. He records in Windows Sound Recorder
   (`Documents/Sound recordings`).
2. The recording is cut with the video-edit skill's tools: `new_project.py "<file>" <slug> --root <your-folder>/` (an
   audio-only file needs a black placeholder video first), `vk.py transcribe`, `vk.py edl ...`, `vk.py mix --voice`.
3. Copy `toon/kit.js`, `toon/s_demo.js`, `toon/BRIEF.md`, `toon_render.py`, `toon_build.py`, `timeline.py` from
   `<your-folder>/mashup-edit`. `timeline.py` lists each scene's name, start, end, the `ev` word times it reacts to, and any
   real clip laid into the cartoon TV.
4. Scenes are `toon/s_*.js`, one file per author, pure functions of t. Five fresh general-purpose agents wrote 27
   scenes in about 35 minutes from `BRIEF.md`.
5. `python toon_render.py stills <scene>` and `sheet <scene>` to look; `frames` for every frame (headless Chrome,
   cached per scene; 6,821 frames took about 20 min); `python toon_build.py check | clips | video -o out.mp4`.
6. `vk.py qc`, an independent QC agent, then `vk.py deliver` (hash-checked copies to the Drive folder).

These tools take the video-edit skill's machine-wide render lane by themselves, so agents can overlap. His
recording may hold the only copy of his take: never overwrite it. Whether "only animated" allows the real gameplay
clips on the cartoon TV is not confirmed (see SKILL.md, open points).

## What each published video used

| video | date | style | voice | length |
| --- | --- | --- | --- | --- |
| Inference Engineering - Explained (youtu.be/GKYUvayrLVo) | 2026-09-28 | Manim v3 | his clone | not re-checked (the local v3 file is 18.8 min) |
| Claude Sonnet 5.5 Explained (youtu.be/9QnYYjhoVb0) | 2026-09-29 | Remotion | his clone | 7:43 |
| the loud hand-drawn cut (youtu.be/NKoeHkv4Gzk) | 2026-09-29 | sketch | clone on v3, rejected | 7:53 |
| Agent Harness Engineering (youtu.be/8gP9Oj_rSPA) | 2026-10-02 | Manim | Vapi Leo | 20.7 min |
| Modders ... Using Rust (youtu.be/UjXqfFnqidw) | 2026-10-02 | clips | Vapi Leo | 8:12 |
| AI and God (youtu.be/JCkmHZZAWr4) | 2026-10-05 | documentary + clips | Vapi Brian | 15.6 min |
| 90 AI Agents ... a Magnet (youtu.be/Oepv0yTF0U4) | 2026-10-06 | documentary cards | Vapi Brian | 15:57 |
| Did OpenAI Just Solve 700 Math Problems? (youtu.be/cs26cS0XjdM) | 2026-10-07 | documentary cards | Vapi Brian | 17.8 min |
| Top 10 AI Game Mashups (youtu.be/brBxSJEz9h0) | 2026-10-08 | cartoon | his own recording | 3:47 |
