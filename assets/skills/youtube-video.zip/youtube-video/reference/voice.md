# Voice: which one, how, and what it costs

Decide the voice before the script is final, and say which one you are using in your first message to him. He
stopped a build to ask "r u using eleven labs and using my voice?" (2026-09-29) because it had been assumed.

No key is written in this skill. Keep the Vapi key and the ElevenLabs
key (`ELEVENLABS_API_KEY`) in your own `.env`. Never print either.

## Which voice

| route | use when | his words |
| --- | --- | --- |
| **Vapi voice** (default for narrated videos) | he has not asked for his own voice | "u can use any voice from vapi" (2026-09-29); "please use vapi any voice is fine something masculine would be better" (2026-09-30); "have a deep voice ... using vapi please make sure it sounds expressive" (2026-10-04) |
| **His own recording** | he says he will send a voice-over, or the video is personal | "make a script for me first so i can send u a voice over" (2026-10-08) |
| **His ElevenLabs clone** | he asks for "my voice" and will not record | "make a similar video with my voice in eleven labs" (2026-09-28). Credits were nearly gone on 2026-09-29: ask first |

The last three narrated videos all used Vapi "Brian". The first two used his clone. If he says "my voice", ask
one question: will he record it, or should the clone be used (and are there credits)?

## Vapi

Vapi has no plain text-to-speech endpoint. `vapi_tts.py` opens a websocket call whose assistant speaks one
paragraph as its first message and records the 24 kHz audio; `vapi_narrate.py` runs every paragraph (four calls
at a time, resumable in `audio/vparts`), trims and level-matches each, and gets character timing from
faster-whisper words aligned to the script.

- Voice: the `VAPI_VOICE` environment variable. Default in the documentary template is
  `11labs:nPczCjzI2devNBz1zQrb` (ElevenLabs "Brian" routed through Vapi, deep, with the settings in `EL` in
  `vapi_tts.py`). `Leo` is Vapi's own male voice, used on the harness and Rust videos.
- To choose between voices, `<your-folder>/religion-video/audition.py` speaks one paragraph in each and `voice_stats.py`
  prints pitch and range. Send him two short clips instead of a full narration when the choice matters.
- Cost was about $0.01 for a short paragraph (2026-09-30). Nobody has read the Vapi balance from this PC yet.
- After every run: `python tail_check.py`. Vapi sometimes stops a long paragraph early at a sentence end (4 of 50
  on the harness video, and retrying reproduced it), drops a phrase ("In August 2026" went missing), or returns a
  take under a second long. Listen to or re-transcribe (medium.en) every flagged take; re-voice by moving the
  take's two files out of `audio/vparts` and running `vapi_narrate.py` again.
- `<your-folder>/harness-video/vapi_fix_tails.py <keys>` voices the missing sentences as a second call and appends them. Do
  not import it (it runs on import), and its detector misses endings with numbers ("4%").
- Spell it the way it should be said: acronyms letter-spaced ("W G P U", "A I"), numbers as words, no symbols.
  "wgpu" came out mangled.
- Whisper's `initial_prompt` made the alignment skip text. Leave it off.
- The alignment step is a whisper run: it counts as a heavy job. Use the copy with `cpu_threads=4`
  (`<your-folder>/openai-math-video/vapi_narrate.py`).

## His own recording

1. The script goes through the youtube-script skill, then into Notepad for him to read from ("ok can u open this
   in a notepad", 2026-10-08). He reads into Windows Sound Recorder; the file lands in `Documents/Sound recordings`.
2. He asks for the fillers and mishaps to be cut. That is the video-edit skill's job: `new_project.py`,
   `vk.py transcribe`, `vk.py edl pauses | retakes | apply | verify`, `vk.py mix --voice`. Keep the second take
   when he says a line twice.
3. Traps from the one time this was done are in traps.md (transcriber looping on retakes, the quiet mix, the
   placeholder video).

## His ElevenLabs clone

The "Deon Menezes" professional clone, voice id `YOUR_ELEVENLABS_VOICE_ID`. It sounds like him on exactly one setup:

- model `eleven_multilingual_v2`, stability 0.45, similarity 0.85, style 0.35, speed 1.12
- one take per paragraph, generated in order with request stitching (`previous_request_ids` plus the previous and
  next text), loudness-matched per paragraph, no picking between takes
- script: `<your-folder>/harness-video/tts.py` (it also stores character end times). `<your-folder>/sonnet55-sketch/tts_v2.py` is the
  same settings for a script that carries `[tags]`.

What he rejected, and why it is not coming back without his say:

- Choosing the "liveliest" take per paragraph at stability 0.2: "the quality of voice keeps on changing" (2026-09-28).
- `eleven_v3`, stability 0, style 1.0, a 10% tempo speed-up, compressor and limiter: "but it is not my voice",
  "it sounded like me earlier" (2026-09-29). The clone is trained for v2, not v3.

So: energy comes from the script (exclamations, reactions, short sentences), not from the settings. No `atempo`;
raise `speed` in the API instead, 1.15 at most. If he wants a different delivery, change one setting, send a
short A/B clip, and say up front that it may change how he sounds.

Credits:

- A 20-minute script is about 22,100 credits on v2 (characters are roughly credits).
- The account was at 55 of 131,000 on 2026-09-29. An empty account answers HTTP 401 `quota_exceeded`, which looks
  like a bad key. The key cannot read the balance (`user_read` is missing): ask him, or look in the dashboard.
- With stitching, changing one paragraph means generating the whole narration again. That is why the fact-check
  comes first.
- `preflight.py --voices` only tells you the voice id is reachable. It says nothing about credits.

## One voice, start to finish

Whatever the route: one voice, one set of settings, every paragraph level-matched. A re-voiced paragraph must be
made with the same voice and settings as its neighbours, and listened to next to them.

## Music under the voice

Every narrated long-form so far has a quiet looped bed (`music.mp3` in the template, volume 0.20, ducked under
the voice, faded at both ends). He has not objected to it on long-form. On his reels the default is no music at
all. ElevenLabs Music refuses a prompt that names a channel or artist ("3Blue1Brown"): describe the sound instead.
