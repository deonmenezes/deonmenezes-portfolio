# Traps already paid for, by step

Each line is something that went wrong on one of Deon's videos, and the fix. Read the section for the step you
are about to start. Project names in brackets say where it happened.

## The machine

| trap | fix |
| --- | --- |
| The PC blue-screened twice mid-build on 2026-10-04 (all-core whisper + Vapi + headless Chrome, then ffmpeg overlay + NVENC). The cause is hardware bit flips, not a driver. BIOS flashed 2026-10-07 about 12:42; a Kernel-Power 41 event was logged at 20:48 that evening (bugcheck 0, cause not looked into), so the fix is not proven. | One heavy job at a time. ffmpeg on a few threads at below-normal priority (`GENTLE` and `LOW` in the documentary `build.py`), `cpu_threads=4` on faster-whisper, one segment at a time. Tell him before anything that loads the machine for more than a few minutes. `preflight.py` counts the shutdowns since the flash. |
| Older templates run in parallel: `build.py render` in harness-video and inference-video (4 renders), `render_all.py` (2 Blender jobs), whisper on all cores in the religion, rust and harness `vapi_narrate.py`. | Set them to 1 (or `cpu_threads=4`) in your copy before running. |
| Files written here can be silently corrupt (a download differed by one byte; a zip failed its CRC). | Hash the final twice, hash every copy, record the SHA-256. A file that hashes differently on two reads: stop and tell him. |
| A render ate memory until the PC was at risk [religion]. | `python watch_mem.py <build args>` stops the step when free RAM drops under 5 GB. |
| "STOP RENDER FOR NOW" (2026-10-04). | Stop at once, by the exact PID of your own job. Never `taskkill /IM python.exe` or `ffmpeg.exe`: python.exe also hosts CrossPost, the inbox hub and the MCP servers. |
| E: is full (0.3 GB free on 2026-10-08). The mashup video could not keep an E: copy. | New projects on D:. Check with `preflight.py`. |
| CUDA is broken for faster-whisper (`cublas64_12.dll`). | `device="cpu", compute_type="int8"`. Do not spend time on CUDA. |
| Bash heredocs eat backslashes (`\N`, `\t`) in Python written through them. | Write scripts with the Write tool; forward slashes in paths. |
| A session that died on "403 ... /login" took its background agents with it; nothing in flight was saved [vals]. | On resume, re-brief the agents from the Agent prompts in the transcript (the `session-recovery` skill finds what was cut off). Have agents write results to files as they go. |
| Messaging a running workflow agent forks a copy that keeps editing after the workflow moves on. | Change the brief file and tell the agent once it has reported. |

## Research and script

| trap | fix |
| --- | --- |
| The fact-check ran after the voice: two full ElevenLabs passes burned [sonnet55], 22 of 35 paragraphs re-recorded and every shot anchor re-checked [vals]. | A fact-check agent reads `script.py` against the research files BEFORE any voice is generated. |
| WebFetch gets ECONNREFUSED or 403 on news sites, openai.com, WordPress blogs. | `python research/fetch.py <url> <out.txt>` (headless Chrome; some pages answer 403 and still render). |
| news.ycombinator.com is unreachable from the shell. | `hn.algolia.com/api/v1/items/<id>` for the thread; `hn_b.py` for the card. |
| X is unreachable from the shell. | Logged-in Chrome: search URLs with `min_faves:N` and a scroller reading `article[data-testid=tweet]` gave real likes and views. Cards come from `tw.py` (no login). |
| APS, ACS, IOP and PMC bot-wall headless Chrome; so do Inc and Forbes. | University research portals and Crossref carry the same abstracts; use another outlet. Do not try to get around a bot wall. |
| His title or framing says more than the source ("solved 700+ problems" vs 722 manuscripts in 372 result families; "superconductor" for a magnet). Numbers from one outlet differ from the source (377 vs 372). | The video says what the source says. Offer a question-form title, never show a card with one number while the narration says another, and tell him what changed. |
| The closing opinion paragraphs were Claude's and went public unreviewed twice [vals, openai]. | Ask him one question for his take before writing. If he gives none, mark them `# TAKE` and say so in the report, before upload when there is time. Never invent a personal story for him. |
| Scripts opened with a list of sections, announced every reveal and read as generated. Clipped fragments sounded robotic in the voice. | The youtube-script skill and `lint_script.py` until OK. Complete sentences. |
| A term appeared with no definition (TTFT, TPS, distillation), or the word came first and the definition was bolted on. | Define it in a full sentence where it first appears, worked into the story, and as an on-screen `def`. |
| "Opus 5.5 wrote most of it" (the developer said Claude made it); "37 ms" (17); "one person" (several) [rust]. | Check each claim against the primary source: the repo, the post, the paper. Quote under 15 words or paraphrase. Something seen only in a news article is said as "told <outlet>". |

## Voice

| trap | fix |
| --- | --- |
| Vapi stopped a long paragraph early at a sentence end (4 of 50), dropped "In August 2026", returned a 0.7 s take. | `python tail_check.py` after every run; re-transcribe doubtful takes with medium.en; re-voice the take. |
| Vapi mangled "wgpu". | Letter-space acronyms in the script ("W G P U"). |
| `vapi_fix_tails.py` runs on import, and misses endings with numbers ("4%"). | Run it as a script with the keys; check number endings by ear. |
| Whisper `initial_prompt` made the alignment skip text. | Off. |
| Whisper stretches a word across the silence after it (any word over 1.5 s is not that long) and invents small words in very short windows. | Do not trust a word's end before a pause; verify a doubtful word by transcribing the result, not a tiny slice. |
| ElevenLabs out of credits answers HTTP 401 `quota_exceeded`; the key cannot read the balance. | Estimate first (characters are about credits), ask him before a full narration, reuse existing parts. |
| The loud eleven_v3 take: "it is not my voice". Take-picking at low stability: "the quality of voice keeps on changing". | voice.md: v2 settings only, stitched in order, one take, energy from the script. |
| eleven_v3 has no stitching and speaks at about 2.3 words/s when energetic; a pace check set above that re-rolls good takes and burns credits. | Not the route to use. If ever asked for again: words-per-second floor about 1.7. |
| His own recording, full of retakes: the transcriber looped one sentence for two minutes. | Cut the audio at the loop start, transcribe the tail on its own, merge with the offset. |
| An audio-only source: `new_project.py` wants a video. | Make a black placeholder video with the audio. |
| `mix --voice` came out at -16.8 LUFS on a quiet recording and QC failed it. | Gain plus `alimiter`: 4.3 dB with limit 0.76 gave -14.3 LUFS, -1.6 dBTP after AAC. |
| `qc --asr` failed on word count because `words_cut.json` itself was wrong. | Prove the audio another way: per-second waveform correlation of the final against `vo16_cut.wav`. |

## Visuals

| trap | fix |
| --- | --- |
| Flat Manim, even with glow and particles, and designed quote cards read as "vibe coded". A command in a box with a definition under it reads as a slide. | Real screenshots, real posts, real footage first. An animation shows the thing happening: the comment landing, the reply typing, the result arriving. |
| A `src` or `quote` overlay with a long `hold` outlived its card and sat over the next person's page [openai]. | `{"to": "last words", "hold": 0.4}` on every one. |
| Montserrat has no superscript minus or digits: "2⁻¹⁸²" rendered as a box. | Write `2^−182`. Look at every stat panel on the contact sheets. |
| CMU Serif lacks × → ≈ ² ✓ and breaks fi/fl ligatures [Manim]. No LaTeX installed. | `common.py` falls back to Cambria and disables ligatures. `Text` only, no `MathTex`. |
| The X embed cuts a long post at "Show more", so the quoted words are not on the card. | `tw_full.py`, or an exact-words `quote` overlay. |
| A Mastodon card shows this PC's time zone (IST) while the narration uses another. | Say the zone in the `date` overlay. |
| `pw_shots.py` died on the first odd character in a page title. | `PYTHONIOENCODING=utf-8`. |
| A capture came out blank, or under a cookie banner or popup; one card had a blank hero image. | `retake.py`, or the job's `hide` selectors; read `card_sheets.py` output before building. |
| A real card about the right person and the wrong thing (a comment shown as a post, a post from before the event shown as a reaction). | Keep the "cards that are easy to misuse" list at the top of `shots.py`, as the openai one does. |
| A stat panel on the left covered the highlighted sentence. | `ov_stat(..., "right")`. |
| A hook after an early `return null` in a Remotion component crashed the render (React #310). | All hooks above any return. |
| A like counter animated through numbers he never says; the file ended mid-motion [mashup, QC round 1]. | An animated number shows only its spoken value. End on a held pose. |
| Word times read off the transcript are early for the first two or three words after a pause, so a caption or a cartoon `ev` fires in dead air. | Add about 0.2 s to those by hand; `captions.py` in video-edit holds such captions until the voice returns. |
| ElevenLabs Music refused a prompt naming a channel. | Describe the sound. |

## Render

| trap | fix |
| --- | --- |
| ffmpeg 7.1 rebuilds the filter graph when colour tags or pixel aspect change between joined clips: looped overlay inputs stall forever (a segment froze at 27 s), single-frame inputs vanish silently. | `-reinit_filter 0` before the base input. Already in the documentary `build.py`; keep it in anything new that overlays timed graphics on concatenated clips. |
| Each overlay PNG looped for the whole segment: minutes of work and a low-memory kill. | Decode it only for its window: `-itsoffset t0 -loop 1 -t n`. A 270 s segment went to about 25 s and under 1 GB. |
| An overlay missing from the render with no error. | `python verify_ov.py` before `concat`. |
| `build_edit.py` in rust-video reuses any `out/<seg>_cutNN.mp4` that is long enough, keyed by index: changed shots were ignored and re-timed narration desynced the b-roll. | Do not start from rust-video. If you must rebuild there, delete `out/<seg>_cut*`, `_base` and `<seg>.mp4` first. The newer `build.py` keys cuts on source, in-point, duration, options and mtime. |
| Other stale caches: `stills/qc_all.done` from an earlier run [harness]; an animation cache that cannot see a swapped image [video-edit `render_anim`]. | Delete the marker first; `--force` after changing an asset. |
| Parallel Manim renders collided on the shared `scenes/media/texts` cache (WinError 32); two `qc.py` batches collided on `partial_movie_files`. | One at a time. Re-render the scene that failed. |
| A scene video shorter than its narration gets cut by `-shortest`. | Every scene at least as long as its audio, with 0.2 to 1.2 s of tail. |
| `[sync]` overruns after the real voice replaces the scaffold timing [Manim]. | `run_time=self.until("phrase")` so animations stretch; re-run `qc.py` per scene. Up to about 1 s was accepted as cosmetic. |
| `render_fixes.py` reads `out/fixes.txt`. | The numbers are seconds, not frames. |
| The title card is not at 0:00: `concat()` puts it after the cold open, while `qc_final.py` counts it before. | First chapter is 0:00, the rest are as printed. The first segment's QC frames are sampled 4.5 s late: check its overlays on `verify_ov.py` and by eye. |
| The sketch filter made a 263 MB file at crf 17. | Re-encode at crf 24 for upload. |

## Upload and after

| trap | fix |
| --- | --- |
| `post.py` lost its connection while polling a file near 1 GB; the upload itself was fine. | `upload_yt.py`: create once, save the id, poll with retries. Never re-run a create. |
| CrossPost refuses a description over 5,000 bytes. | Trim to `description_yt.txt`; keep the full source list in `description.txt`. |
| Three videos went up with no custom thumbnail because "the API cannot set one" [harness, rust, religion]; he asked "what happened to thumbnail". | `thumbnails.set` works with CrossPost's token (publish.md). |
| The thumbnail was saved in Studio and the public image still showed an auto frame. | Check again later. |
| In the A/B dialog, slot 1's file input replaces the current thumbnail. | Fill the slots in order, 1 to 3. |
| A copy into the Drive mount is not an upload; the letters G:, H:, I: swap; the old account has an empty folder of the same name. | The `drive-save` skill, and wait for its "MATCH" line. |
| Gemini: no API key works; a plain prompt returned text; the second download from one chat was dropped; a dim reference photo rendered him too dark. | publish.md, section 4. |
| The upload is public at once. | QC first. Nothing unreviewed goes up without saying so. |
