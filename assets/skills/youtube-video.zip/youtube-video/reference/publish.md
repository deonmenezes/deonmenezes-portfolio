# Deliver, upload, thumbnail, A/B test

An upload through CrossPost is **public the moment it finishes** (`YOUTUBE_PRIVACY` defaults to `public`). There
is no draft to fix afterwards, so everything in the QC checklist comes before this file.

## 1. Deliver to Drive (always, whether or not it is uploaded)

Finished files go in "Video edits of myself" on the 04 Drive: "it should be in video edits of myself"
(2026-10-03). Use the `drive-save` skill; it finds the folder by account and path (the letters swap), hash-checks
the copy and tells you when Google really has the file.

```bash
D=~/.claude/skills/drive-save/scripts/drive.py
python $D save "out/<Final>.mp4" --to edits --name "<Title>.mp4"            # dry run
python $D save "out/<Final>.mp4" --to edits --name "<Title>.mp4" --apply --wait 120
python $D save "thumb/thumb_A.jpg" --to edits --name "<Title> - thumbnail A.jpg" --apply
```

Names already in that folder: `AI and God - Grok, Sam Altman, Anthropic and the Pope.mp4`,
`Not Big News - thumbnail.jpg`, `OpenAI 722 Math Papers - thumbnail A.jpg`. Never "Unedited videos".
The cartoon pipeline is a video-edit project, so there `python vk.py deliver <final> "<Title>"` does the same job.

Write the final file's SHA-256 in your report. This PC has flipped bits in files: a copy counts only when the
hash matches, and a file that hashes differently on two reads means stop and tell him.

## 2. The description

Model: `<your-folder>/openai-math-video/description_yt.txt`. In this order:

1. Two or three sentences saying what happened and what the video found, with the real numbers.
2. `CHAPTERS`, first line `0:00`. `python qc_final.py` prints the offsets. It adds the 4.5 s title card before
   the first segment although `concat()` plays it after the cold open, so its first line reads 0:04: write 0:00
   there; the later ones are right. Chapter names are short and plain.
3. One paragraph on what is established and what is not, when the story has that gap.
4. `Sources`: every link the script relied on. If they do not fit, keep the ones not legible on screen and say
   "the rest are shown on screen in the video"; keep the full list in `description.txt`.
5. The closing line used so far: "The narration is an AI voice. Screenshots belong to their owners and are shown
   for reporting and commentary." Change the first sentence when he narrated it himself.

CrossPost refuses a description over **5,000 bytes** (bytes, not characters). `description_yt.txt` is the trimmed
one. The descriptions so far were written by Claude and not reviewed by him: say so when you report.

## 3. Titles

"the title can be ab tested and short, have multiple titles and thumbnails to keep it like 'is superconductors
finally here'" (2026-10-06). So: three short titles that make someone curious, each with its own thumbnail.

A title may not claim what the video itself says is untrue. His "openai solved 700+ math problems" became "Did
OpenAI Just Solve 700 Math Problems?", and "superconductors are here" was not used because the material is not a
superconductor. Offer the question form, and tell him what you changed and why.

## 4. Thumbnails

"what happened to thumbnail add that too" (2026-10-02): every upload gets a custom thumbnail. 1280x720 JPEG,
under 2 MB, readable at phone size.

- **From the video's own material:** `python thumb/make_thumb.py` builds three variants (headline in Montserrat
  Black, the source's real pages fanned on the right). No Deon, no Gemini.
- **Gemini picture with Deon in it** ("make a thumbnail using gemini and use deon as profiles make it
  attractive", 2026-10-06): there is no working Gemini API key here. Use gemini.google.com in Chrome
  (Claude-in-Chrome), choose "Create image" from the + menu (a plain prompt returned text), attach a well-lit
  photo of him (`<your-folder>/muse-carousel/tmp/serve/deon_ref2.jpg`), ask it to match the skin tone in the photo and dress
  him casually. Downloading the image needs his yes, and Chrome saves to the root of E:, which is nearly full.
  A second download from the same chat is silently dropped: take a zoomed screenshot of the image instead.
  The carousel skill and the gemini-image-generation memory note have the page mechanics.
- **Variants from one Gemini picture:** `<your-folder>/vals-video/thumb/variants.py` paints out the headline Gemini baked in
  and sets a new one, so only the text differs between A, B and C. Its mask rectangles are for that one picture:
  re-measure them.
- A plain fallback when nothing else is ready: the video's title card (the cartoon video used it).

Look at every thumbnail as an image before uploading it.

## 5. Upload

He has to have said to upload: in the request ("make sure the video is made and uploaded to youtube"), or after
("upload once done", "upload it and do some ab testing"). If he has not, deliver, report and ask.

Before creating the post: `python <your-home>/crosspost/autopost/post.py --status` shows `youtube connected`.
If CrossPost is not running or YouTube needs a sign-in, the post-video skill (step 0 and Troubleshooting) has the
steps; Deon approves Google sign-ins himself. Nothing of his starts at boot any more, so start it by hand.

Copy `<your-folder>/openai-math-video/upload_yt.py` into the project, set `VIDEO`, `TITLE`, `TAGS`, then:

```bash
python upload_yt.py           # creates the post ONCE, writes out/upload_post.json, polls every 10 s
python upload_yt.py --poll    # if the poll died: same post id, no new upload
```

It refuses to create a second post while `out/upload_post.json` exists. Plain `post.py "<mp4>" "<caption>"
--only youtube --title "..." --tags "a,b" --description "$(cat description_yt.txt)"` also works for a small file
and exits when the upload is done, but on a file near 1 GB its status poll has dropped with a connection reset
while the upload itself was fine. Never re-run a create because a poll failed: that is a second public video.

Long-form goes to YouTube only. A vertical cut for Reels, Shorts, TikTok or X is the post-video skill's job, and
only if he asks.

## 6. Set the thumbnail

Through the API, with CrossPost's own YouTube grant (it has `youtube.upload`, which is enough). Written down on
2026-10-06 as working; earlier notes that say "no thumbnail option, use Studio" are out of date.

```python
import json, requests
tok = json.load(open("<your-home>/crosspost/data/tokens.json"))["youtube"]["accessToken"]
r = requests.post("https://www.googleapis.com/upload/youtube/v3/thumbnails/set",
                  params={"videoId": "<id>", "uploadType": "media"},
                  headers={"Authorization": "Bearer " + tok, "Content-Type": "image/jpeg"},
                  data=open("thumb/thumb_A.jpg", "rb").read(), timeout=120)
print(r.status_code, r.text[:300])
```

Run it right after the upload, while the token is fresh (`expiresAt` is in the same file). Never print the
token. A 401 means it has expired: set the thumbnail in Studio instead (`studio.youtube.com/video/<id>/edit`,
find the thumbnail file input, `file_upload`, Save). Right after a save the public image server can still show an
auto frame; check again later before telling him it failed.

## 7. A/B test (Studio only, no API)

He wants a test on every long-form: "upload it and do some ab testing" (2026-10-07).

Studio > the video's details > "A/B Testing" under the title > "Title and thumbnail" > up to three pairs >
Set test > Save. The dialog's three file inputs are slots 1, 2, 3 in order, and **slot 1's input replaces the
current thumbnail**. This needs Chrome signed in to his channel; if Studio shows a login, he signs in.

## 8. Tell him

One message: the link and that it is public; the Drive file name; the three titles in the test; anything in the
video that is yours and not his (see SKILL.md, "What to tell him"). He asks "is the video live", "did u upload on
youtube" and "where is the video" when he has not been told, so tell him first.
