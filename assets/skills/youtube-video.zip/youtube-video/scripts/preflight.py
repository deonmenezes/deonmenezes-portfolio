"""preflight.py - is this PC ready to make a long-form YouTube video? Read-only.

    python preflight.py             tools, python modules, template folders, disk, Drive folder, machine, CrossPost
    python preflight.py --voices    also ask ElevenLabs whether Deon's cloned voice is reachable (one GET, no credits)

It writes nothing, starts nothing heavy and never prints a key. Lines start with ok / WARN / MISSING.
Exit code 1 when something marked MISSING is needed by every pipeline (ffmpeg, python modules, the default template).
"""
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request

HOME = os.path.expanduser("~").replace("\\", "/")
SKILLS = f"{HOME}/.claude/skills"
DRIVE_SUB = "My Drive/YOUR_DRIVE_FOLDER/Video edits of myself"
PVC_VOICE = "YOUR_ELEVENLABS_VOICE_ID"      # your pro voice clone on ElevenLabs (an id, not a credential)
EL_ENV = "<your-folder>/.env"                # your own .env with ELEVENLABS_API_KEY
GENTLE_SINCE = "2026-10-07T12:42:00"          # BIOS 3883 flashed; unclean shutdowns after this count against the fix

# style -> (template folder, files that make it usable)
PIPELINES = [
    ("documentary cards (default)", "<your-folder>/openai-math-video",
     ["build.py", "shots.py", "script.py", "vapi_narrate.py", "vapi_tts.py", "tail_check.py", "pw_shots.py", "tw.py",
      "tw_full.py", "hn_b.py", "pdf_shot_b.py", "verify_ov.py", "watch_mem.py", "qc_final.py", "upload_yt.py",
      "card_sheets.py", "thumb/make_thumb.py", "research/fetch.py", "shots/make_jobs.py", "fonts/Montserrat.ttf", "music.mp3"]),
    ("  same family, with clips and soundbites", "<your-folder>/religion-video",
     ["build.py", "dl.sh", "transcribe.py", "soundbites.py", "sheets.py", "audition.py", "voice_stats.py"]),
    ("  same family, Gemini thumbnail variants", "<your-folder>/vals-video", ["thumb/variants.py", "tail_check.py"]),
    ("calm explainer (Remotion)", "<your-folder>/sonnet55-video",
     ["script.py", "tts.py", "timeline.py", "stills.mjs", "thumbs.mjs", "mux.sh", "src/index.ts", "node_modules"]),
    ("hand-drawn sketch (Remotion)", "<your-folder>/sonnet55-sketch",
     ["script.py", "tts_v2.py", "timeline.py", "stills.mjs", "mux.sh", "src/kit.tsx", "node_modules"]),
    ("Manim, 3Blue1Brown style", "<your-folder>/harness-video",
     ["script.py", "common.py", "build.py", "qc.py", "times.py", "fake_align.py", "vapi_narrate.py", "tts.py", "STYLE.md", "BRIEFS.md"]),
    ("Blender 3D + Remotion cards", "<your-folder>/inference-video",
     ["b3d/kit.py", "b3d/ART.md", "render_all.py", "render_fixes.py", "assemble_v4.py", "overlay/package.json", "overlay/node_modules"]),
    ("cartoon, his own voice-over", "<your-folder>/mashup-edit",
     ["toon/kit.js", "toon/BRIEF.md", "toon_render.py", "toon_build.py", "timeline.py", "vk.py"]),
    ("legacy clip edit (do not start from it)", "<your-folder>/rust-video", ["build_edit.py", "script_human_draft.py"]),
]
OTHER = [
    ("youtube-script linter", f"{SKILLS}/youtube-script/lint_script.py"),
    ("video-edit shared code (vkit: lane lock, hash-verified copy)", f"{SKILLS}/video-edit/scripts/vkit.py"),
    ("post-video skill", f"{SKILLS}/post-video/SKILL.md"),
    ("CrossPost uploader", "<your-home>/crosspost/autopost/post.py"),
    ("Blender 5.2", "C:/Program Files/Blender Foundation/Blender 5.2/blender.exe"),
    ("Chrome (Playwright channel='chrome')", "C:/Program Files/Google/Chrome/Application/chrome.exe"),
    ("rclone (Drive fallback, remote d04:)", "<your-home>/tools/rclone/rclone.exe"),
    ("Deon reference photo for Gemini thumbnails", "<your-folder>/muse-carousel/tmp/serve/deon_ref2.jpg"),
]
MODULES = ["faster_whisper", "playwright", "psutil", "pymupdf", "parselmouth", "cv2", "PIL", "numpy", "requests",
           "websockets", "manim"]
HARD_MODULES = {"faster_whisper", "playwright", "psutil", "PIL", "numpy", "requests", "websockets"}

fatal = 0


def say(tag, what, detail=""):
    print(f"{tag:8}{what}" + (f"  - {detail}" if detail else ""))


def section(title):
    print(f"\n== {title}")


def tools():
    global fatal
    section("tools")
    for t, hard in [("ffmpeg", True), ("ffprobe", True), ("node", False), ("npx", False), ("manim", False), ("yt-dlp", False)]:
        p = shutil.which(t)
        if p:
            say("ok", t, p.replace("\\", "/"))
        else:
            say("MISSING", t, "needed by every pipeline" if hard else "needed by some pipelines")
            fatal += hard
    say("ok", "python", f"{sys.version.split()[0]} at {sys.executable}".replace("\\", "/"))
    for m in MODULES:
        if importlib.util.find_spec(m):
            say("ok", f"module {m}")
        else:
            say("MISSING", f"module {m}")
            fatal += m in HARD_MODULES
    for name, path in OTHER:
        say("ok" if os.path.exists(path) else "MISSING", name, path)


def pipelines():
    global fatal
    section("template folders (read from them, never edit them)")
    for style, root, files in PIPELINES:
        if not os.path.isdir(root):
            say("MISSING", style, f"{root} is gone")
            fatal += style.startswith("documentary")
            continue
        gone = [f for f in files if not os.path.exists(f"{root}/{f}")]
        if gone:
            say("WARN", style, f"{root} is missing: {', '.join(gone)}")
            fatal += style.startswith("documentary")
        else:
            say("ok", style, root)


def disk():
    section("disk (a 15-20 min documentary project used 5-10 GB; frame-based renders use more)")
    best = None
    for letter in "CDE":
        try:
            free = shutil.disk_usage(f"{letter}:/").free / 2**30
        except OSError:
            say("WARN", f"{letter}:", "not mounted")
            continue
        say("ok" if free >= 20 else "WARN", f"{letter}:", f"{free:.1f} GB free" + ("" if free >= 20 else "  (too little for a new project)"))
        if letter in "DE" and (best is None or free > best[1]):
            best = (letter, free)
    if best:
        say("ok" if best[1] >= 20 else "WARN", "new project root", f"{best[0]}:/<slug>-video")
    try:
        if shutil.disk_usage("<your-folder>/").free / 2**30 < 2:
            say("WARN", "Chrome downloads", "Gemini images download to the root of E:, which is nearly full")
    except OSError:
        pass


def drive():
    section("delivery folder (found by path: the Drive letters swap)")
    for letter in "GHIJKLDEF":
        d = f"{letter}:/{DRIVE_SUB}"
        if os.path.isdir(d):
            say("ok", "Video edits of myself", d)
            return
    say("WARN", "Video edits of myself", "not mounted on any letter; use rclone to d04:YOUR_DRIVE_FOLDER/Video edits of myself/")


def machine():
    section("machine (one heavy job at a time)")
    try:
        import psutil
    except ImportError:
        say("WARN", "psutil missing", "cannot look at memory or running jobs")
        return
    vm = psutil.virtual_memory()
    free = vm.available / 2**30
    say("ok" if free >= 10 else "WARN", "free RAM", f"{free:.1f} of {vm.total / 2**30:.0f} GB (watch_mem.py stops a build under 5)")
    heavy = []
    for p in psutil.process_iter(["pid", "name"]):
        n = (p.info["name"] or "").lower()
        if n.split(".")[0] in ("ffmpeg", "blender", "manim"):
            heavy.append(f"{n} pid {p.info['pid']}")
    say("WARN" if heavy else "ok", "heavy jobs running now", ", ".join(heavy) if heavy else "none (ffmpeg, blender, manim)")
    lock = f"{HOME}/.claude/video-edit-lane.lock"
    if os.path.exists(lock):
        try:
            h = json.load(open(lock))
            alive = psutil.pid_exists(h.get("pid", -1))
            say("WARN" if alive else "ok", "render lane lock", f"pid {h.get('pid')} {h.get('what')!r}" + ("" if alive else " (holder is dead: it will be taken over)"))
        except (OSError, ValueError):
            say("WARN", "render lane lock", "present but unreadable")
    else:
        say("ok", "render lane lock", "free")
    try:
        ps = ("(Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-Kernel-Power';Id=41;"
              f"StartTime=[datetime]'{GENTLE_SINCE}'}} -ErrorAction SilentlyContinue | Measure-Object).Count")
        n = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=40).stdout.strip()
        if n.isdigit():
            say("ok" if n == "0" else "WARN", "unclean shutdowns since the 2026-10-07 BIOS flash", n + ("" if n == "0" else "  (Kernel-Power 41 events, which a forced power-off also leaves; the gentle rule stays, tell Deon)"))
        else:
            say("WARN", "unclean shutdowns", "event log could not be read")
    except (OSError, subprocess.TimeoutExpired):
        say("WARN", "unclean shutdowns", "event log could not be read")


def crosspost():
    section("upload (CrossPost on localhost:5055)")
    try:
        with urllib.request.urlopen("http://localhost:5055/api/accounts", timeout=5) as r:
            acc = json.load(r)
    except (urllib.error.URLError, OSError, ValueError):
        say("WARN", "CrossPost", "not running. Start it by hand (post-video skill, step 0) when it is time to upload")
        return
    yt = acc.get("youtube") or {}
    who = (yt.get("account") or {}).get("handle") or (yt.get("account") or {}).get("name") or ""
    if yt.get("connected"):
        say("ok", "YouTube", f"connected {who}")
    else:
        say("WARN", "YouTube", "not connected: Deon signs in at http://localhost:5055 (the browser tools cannot click on accounts.google.com)")


def voices(ask_elevenlabs):
    section("voices")
    vt = "<your-folder>/openai-math-video/vapi_tts.py"
    try:
        has = bool(re.search(r'^KEY\s*=\s*"\S+"', open(vt, encoding="utf-8").read(), re.M))
        say("ok" if has else "WARN", "Vapi key", f"{'set' if has else 'not set'} in {vt} (value not shown; the balance is not checked here)")
    except OSError:
        say("WARN", "Vapi key", f"{vt} not readable")
    key = None
    try:
        for line in open(EL_ENV, encoding="utf-8"):
            if line.startswith("ELEVENLABS_API_KEY="):
                key = line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    say("ok" if key else "WARN", "ElevenLabs key", f"{'set' if key else 'not found'} in {EL_ENV} (value not shown)")
    if not ask_elevenlabs:
        say("ok", "ElevenLabs clone", "not asked (run with --voices). The credit balance is never visible to this key: check the dashboard")
        return
    if not key:
        return
    req = urllib.request.Request(f"https://api.elevenlabs.io/v1/voices/{PVC_VOICE}", headers={"xi-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            name = json.load(r).get("name", "?")
        say("ok", "ElevenLabs clone", f"voice {PVC_VOICE} reachable ({name}). This says nothing about credits")
    except urllib.error.HTTPError as e:
        say("WARN", "ElevenLabs clone", f"HTTP {e.code} for voice {PVC_VOICE} (a 401 here has also meant quota_exceeded)")
    except (urllib.error.URLError, OSError, ValueError) as e:
        say("WARN", "ElevenLabs clone", f"could not ask: {str(e)[:80]}")


if __name__ == "__main__":
    if "-h" in sys.argv or "--help" in sys.argv:
        print(__doc__)
        sys.exit(0)
    tools()
    pipelines()
    disk()
    drive()
    machine()
    crosspost()
    voices("--voices" in sys.argv)
    print("\n" + ("NOT READY: fix the MISSING lines above." if fatal else "Ready. WARN lines are things to plan around, not blockers."))
    sys.exit(1 if fatal else 0)
