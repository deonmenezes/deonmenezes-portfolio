"""render_anim.py - anim.html scenes -> PNG frames, one screenshot per video frame.

    python vk.py render_anim --plan                 every split / anim segment in plan.py, one after another
    python vk.py render_anim --plan s1 cta          only these scenes
    python vk.py render_anim --plan --stills        preview stills instead of all frames (one just after each event
                                                    and one at the end) -> prev_*.png
    python vk.py render_anim --plan --force         ignore the cache
    python vk.py render_anim <scene> <dur> <ev csv> [--size 1080x960] [--alpha] [--stills 0.5,2]

Frames go to anim_<scene>/f0000.png ... A scene is re-rendered only when its timing or anim.html changed; images
that anim.html loads are NOT tracked, so pass --force after swapping an asset. Preview with --stills first: a full
scene is 30 screenshots per second of video.
"""
import os, pathlib, re, shutil, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit

HTML = "anim.html"


def anim_key(j):
    """compose compares this before it uses the frames"""
    import planlib
    return planlib.anim_key(j, HTML)


def render(browser, j, stills=None, force=False):
    name, dur, ev, (w, h) = j["name"], j["dur"], ",".join(f"{x:.3f}" for x in j["ev"]), j["size"]
    out = f"anim_{name}"
    key = anim_key(j)
    n = int(round(dur * j["fps"]))
    if stills is None and not force and os.path.exists(f"{out}/.key") and open(f"{out}/.key").read() == key \
            and os.path.exists(f"{out}/f{n - 1:04d}.png"):
        print(f"  {name}: up to date ({n} frames)")
        return
    pg = browser.new_context(viewport={"width": w, "height": h}, device_scale_factor=1).new_page()
    errors = []
    pg.on("pageerror", lambda e: errors.append(str(e)))
    url = pathlib.Path(HTML).resolve().as_uri() + f"?a={name}&d={dur}&ev={ev}&w={w}&h={h}" + ("&alpha=1" if j["alpha"] else "")
    pg.goto(url)
    pg.wait_for_load_state("networkidle")
    pg.evaluate("document.fonts.ready")
    pg.wait_for_timeout(400)
    if errors or pg.title() != "READY":
        raise SystemExit(f"scene '{name}' did not load: {errors or pg.title()}")
    if stills is not None:
        times = stills or sorted({round(min(max(x + 0.35, 0.2), dur - 0.45), 2) for x in j["ev"]} | {round(dur - 0.45, 2)})
        for t in times:
            pg.evaluate(f"window.setT({t})")
            pg.screenshot(path=f"prev_{name}_{t:05.2f}.png", omit_background=j["alpha"])
        print(f"  {name}: stills at {times} -> prev_{name}_*.png")
    else:
        shutil.rmtree(out, ignore_errors=True)       # the key is written last: an interrupted render has none,
        os.makedirs(out)                             # and compose will not use frames without the right key
        for i in range(n):
            pg.evaluate(f"window.setT({i / j['fps']})")
            pg.screenshot(path=f"{out}/f{i:04d}.png", omit_background=j["alpha"])
        open(f"{out}/.key", "w").write(key)
        print(f"  {name}: {n} frames -> {out}/")
    if errors:
        raise SystemExit(f"scene '{name}' threw while drawing: {errors[:3]}")
    pg.context.close()


def main():
    a = sys.argv[1:]
    force = "--force" in a
    stills = None
    if "--stills" in a:
        i = a.index("--stills")
        nxt = a[i + 1] if i + 1 < len(a) else ""
        if re.fullmatch(r"[\d.]+(,[\d.]+)*", nxt):      # a list of times; anything else is a scene name
            stills = [float(x) for x in nxt.split(",")]
            del a[i:i + 2]
        else:
            stills = []
            del a[i]
    size, alpha = (1080, 960), "--alpha" in a
    if "--size" in a:
        i = a.index("--size")
        size = tuple(int(x) for x in a[i + 1].lower().split("x"))
        del a[i:i + 2]
    pos = [x for x in a if not x.startswith("--")]
    if not os.path.exists(HTML):
        raise SystemExit("no anim.html in this folder")
    if "--plan" in a:
        import planlib
        vkit.need_applied()
        jobs = planlib.anim_jobs(set(pos))
        if not jobs:
            raise SystemExit("plan.py has no split or anim segments" + (f" named {pos}" if pos else ""))
    elif len(pos) >= 2:
        ev = [float(x) for x in pos[2].split(",")] if len(pos) > 2 and pos[2] else []
        jobs = [dict(name=pos[0], dur=float(pos[1]), ev=ev, size=size, alpha=alpha, fps=vkit.project()["fps"])]
    else:
        print(__doc__)
        sys.exit(1)
    from playwright.sync_api import sync_playwright
    with vkit.lane("render_anim"), sync_playwright() as pw:
        b = pw.chromium.launch(channel="chrome", headless=True, args=["--allow-file-access-from-files"])
        for j in jobs:                               # one scene at a time, on purpose
            render(b, j, stills, force)
        b.close()


if __name__ == "__main__":
    main()
