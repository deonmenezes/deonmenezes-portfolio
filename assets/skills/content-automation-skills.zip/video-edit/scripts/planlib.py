"""planlib - plan.py (ORIGINAL seconds) read onto the cut timeline. Shared by compose, captions and render_anim."""
import os, sys

sys.path.insert(0, os.getcwd())
import vkit
from timemap import T, Tf, NEW_DUR

try:
    import plan
except ModuleNotFoundError:
    plan = None

P = vkit.project()
W, H, FPS = P["w"], P["h"], P["fps"]
KINDS = ("split", "card", "anim", "broll")


def get(name, default):
    return getattr(plan, name, default) if plan else default


# layout defaults follow the frame, so a horizontal clip gets sensible values without touching plan.py
PANEL_H = get("PANEL_H", H // 2)
SHIFT = get("SHIFT", H * 9 // 32)
FACE_C = get("FACE_C", (W // 2, round(H * 0.49)))


def segments():
    """plan.SEGMENTS with t0/t1 on the NEW timeline (exactly on frames) and ev as seconds after t0"""
    out = []
    for i, s in enumerate(get("SEGMENTS", [])):
        s = dict(s)
        if s.get("kind") not in KINDS:
            raise SystemExit(f"plan.py segment {i}: kind must be one of {KINDS}, got {s.get('kind')!r}")
        a, b = s["t"]
        s["t0"], s["t1"] = Tf(a), Tf(b)
        if s["t1"] - s["t0"] < 0.2:
            print(f"plan.py segment {i} ({s['kind']} {a}-{b}) is inside a removed stretch: skipped", file=sys.stderr)
            continue
        s["ev"] = [round(T(x) - s["t0"], 3) for x in s.get("ev", [])]
        s["name"] = s.get("anim") or os.path.splitext(os.path.basename(s.get("png") or s.get("src") or f"seg{i}"))[0]
        out.append(s)
    out.sort(key=lambda s: s["t0"])
    for x, y in zip(out, out[1:]):
        if x["kind"] == y["kind"] == "split" and y["t0"] < x["t1"] - 1e-6:
            raise SystemExit(f"plan.py: split segments {x['name']} and {y['name']} overlap")
    return out


def split_spans(gap=0.4):
    """merged [start, end] spans (NEW time) during which the screen is split"""
    spans = []
    for s in segments():
        if s["kind"] != "split":
            continue
        if spans and s["t0"] - spans[-1][1] < gap:
            spans[-1][1] = s["t1"]
        else:
            spans.append([s["t0"], s["t1"]])
    return spans


def pops():
    out = []
    for a, b, text in get("POPS", []):
        s, e = T(a), T(b)
        if e - s >= 0.3:
            out.append((s, e, text))
        else:
            print(f"plan.py pop {text!r} is inside a removed stretch: skipped", file=sys.stderr)
    return out


def anim_jobs(names=None):
    """one render job per animated scene in the plan"""
    seen = {}
    for s in segments():
        if s["kind"] not in ("split", "anim") or (names and s["name"] not in names):
            continue
        size = (W, PANEL_H) if s["kind"] == "split" else tuple(s.get("size", (W, H)))
        j = dict(name=s["name"], dur=round(s["t1"] - s["t0"] + 0.4, 3),     # a little extra: the last frame is
                 ev=s["ev"], size=size, alpha=s["kind"] == "anim", fps=FPS)  # held through the slide-out
        if s["name"] in seen and (seen[s["name"]]["dur"], seen[s["name"]]["ev"]) != (j["dur"], j["ev"]):
            raise SystemExit(f"plan.py uses scene '{s['name']}' twice with different timing: give the second its own name")
        seen[s["name"]] = j
    return list(seen.values())


def anim_key(j, html="anim.html"):
    """what a scene's frames were rendered from; compose refuses frames whose key is not this"""
    st = os.stat(html)
    ev = ",".join(f"{x:.3f}" for x in j["ev"])
    return f"{j['dur']}|{ev}|{j['size'][0]}x{j['size'][1]}|{int(j['alpha'])}|{j['fps']}|{st.st_mtime_ns}|{st.st_size}"


def anim_frames(j):
    return int(round(j["dur"] * j["fps"]))


def captions_id(none=False):
    """everything captions.ass depends on, as one id"""
    words = "words_cut.json" if os.path.exists("cuts.json") else "words.json"
    return vkit.text_id([vkit.cut_id(), bool(none), split_spans(), pops(), PANEL_H,
                         vkit.file_id("captions.json"), "" if none else vkit.file_id(words)])
