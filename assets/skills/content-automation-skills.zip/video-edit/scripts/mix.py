"""mix.py - the audio track for compose.py -> mix.wav (48 kHz stereo, about -14 LUFS).

    python vk.py mix --voice                                 voice only (the default look: he keeps taking music out)
    python vk.py mix --music "<your-folder>/x.mp3" --start 137 [--under 12]   music bed, ducked under the voice

Voice: high-pass at 80 Hz, a gentle compressor, loudness-normalised. No sound effects, ever, unless he asks for them.
Music, when he does ask: starts --start seconds into the track, is levelled to sit --under dB below the voice
(12 by default, measured, whatever the loudness of the file), ducks further while he speaks, fades in over 1 s and
out over 1.7 s.

Run it again after every `edl apply`: compose refuses a mix that was made for an earlier cut.
"""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit
from timemap import NEW_DUR

VOICE = "highpass=f=80,acompressor=threshold=0.1:ratio=3:attack=10:release=150"
NORM = "loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,aformat=channel_layouts=stereo"
ST = "aresample=48000,aformat=channel_layouts=stereo"


def lufs(args):
    """integrated loudness of whatever these ffmpeg input args + filter produce"""
    r = vkit.run(["ffmpeg", "-hide_banner", "-nostats", *args, "-f", "null", "-"], heavy=True, check=False)
    tail = r.stderr[r.stderr.rfind("Summary:"):]
    val = lambda k: next((ln.split()[1] for ln in tail.splitlines() if ln.strip().startswith(k)), None)
    return val("I:"), val("Peak:")


def main():
    a = sys.argv[1:]
    o = {}
    for k in ("--music", "--start", "--under"):
        if k in a:
            i = a.index(k)
            o[k] = a[i + 1]
            del a[i:i + 2]
    if "--voice" not in a and "--music" not in o:
        print(__doc__)
        sys.exit(1)
    vkit.need_applied()
    p = vkit.project()
    src = p["source"]["path"]
    if p["source"]["audio"] is None:
        raise SystemExit("the source has no audio")
    d = round(NEW_DUR, 3)
    voice = open("voice_cut.fc").read() if os.path.exists("voice_cut.fc") else "[0:a]anull[voc]"
    with vkit.lane("mix"):
        if "--music" not in o:
            fc = f"{voice};[voc]{VOICE},{NORM}[a]"
            cmd = ["ffmpeg", "-v", "error", "-y", "-i", src]
        else:
            music, start, under = o["--music"], float(o.get("--start", 0)), float(o.get("--under", 12))
            if not os.path.exists(music):
                raise SystemExit(f"no such music file: {music}")
            # measure both, then set the bed's gain so it really sits `under` dB below the voice
            open("mix_probe.fc", "w").write(f"{voice};[voc]{VOICE},ebur128=peak=true[a]")
            v_l, _ = lufs(["-i", src, "-/filter_complex", "mix_probe.fc", "-map", "[a]"])
            m_l, _ = lufs(["-ss", str(start), "-t", str(d), "-i", music, "-af", "ebur128=peak=true"])
            if v_l is None or m_l is None:
                raise SystemExit("could not measure the voice or the music loudness")
            gain = (float(v_l) - under) - float(m_l)
            fo = round(max(d - 1.7, 0), 3)
            fc = (f"{voice};[voc]{VOICE},{ST},asplit[vo][sc];"
                  f"[1:a]atrim=0:{d},asetpts=N/SR/TB,{ST},volume={gain:.2f}dB,"
                  f"afade=t=in:d=1.0,afade=t=out:st={fo}:d=1.7[mu];"
                  f"[mu][sc]sidechaincompress=threshold=0.02:ratio=3.5:attack=30:release=500:makeup=1[duck];"
                  f"[vo][duck]amix=inputs=2:normalize=0:duration=first,{NORM}[a]")
            cmd = ["ffmpeg", "-v", "error", "-y", "-i", src, "-ss", str(start), "-i", music]
            print(f"voice {v_l} LUFS, music {m_l} LUFS at {start} s -> music gain {gain:+.1f} dB ({under} dB under, before ducking)")
        open("mix.fc", "w").write(fc)
        vkit.run(cmd + ["-/filter_complex", "mix.fc", "-map", "[a]", "-c:a", "pcm_s16le", "-t", str(d), "mix.wav"],
                 heavy=True)
        out_l, peak = lufs(["-i", "mix.wav", "-af", "ebur128=peak=true"])
    vkit.stamp("mix", {"cut": vkit.cut_id(), "music": o.get("--music")})
    print(f"mix.wav  {d} s  {out_l} LUFS  true peak {peak} dBFS  ({'voice + music' if '--music' in o else 'voice only'})")


if __name__ == "__main__":
    main()
