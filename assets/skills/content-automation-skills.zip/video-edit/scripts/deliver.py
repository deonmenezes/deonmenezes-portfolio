"""deliver.py - put a finished edit where Deon looks for it.

    python vk.py deliver <final.mp4> "Startup problems"          -> "Startup problems - edited.mp4"
    python vk.py deliver <final.mp4> "Startup problems" --force  replace a file of that name
    python vk.py deliver <final.mp4> "Startup problems" --dry    only say where it would go

Copies to <your-folder>/ and to "YOUR_DRIVE_FOLDER/Video edits of myself" on your Drive account, found by path on
whichever letter it is mounted today. Never to "Unedited videos", and never to the other account's Drive, which is
full. Both copies are read back and hash-checked, because this PC has been flipping bits in files. It refuses a
file that qc.py has not passed.

It does not post anything. Posting is the post-video skill, and only when Deon says to post.
"""
import json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit


def main():
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    if len(a) != 2 or not os.path.exists(a[0]):
        print(__doc__)
        sys.exit(1)
    src, title = a
    name = re.sub(r'[\\/:*?"<>|]', "", title).strip() + " - edited.mp4"
    digest = vkit.sha256(src)
    try:
        q = json.load(open("qc.json", encoding="utf-8"))
    except OSError:
        raise SystemExit("no qc.json here: run `python vk.py qc <final>` first")
    if q["sha256"] != digest:
        raise SystemExit("qc.json is for a different render of this file: run qc again on THIS file")
    if q["verdict"] != "PASS":
        raise SystemExit("this file failed qc: fix it, do not deliver it")
    if q.get("excerpt"):
        raise SystemExit("this file is an excerpt (a --range render): deliver the full render")
    targets = ["<your-folder>/" + name]
    drive = vkit.drive_dir()
    if drive:
        targets.append(f"{drive}/{name}")
    else:
        print(f"No mounted drive has '{vkit.DRIVE_SUB}'. Upload with:\n"
              f'  <your-home>/tools/rclone/rclone.exe copyto "{os.path.abspath(src)}" '
              f'"d04:YOUR_DRIVE_FOLDER/Video edits of myself/{name}"')
    for t in targets:
        if "--dry" in sys.argv:
            print(f"would copy to: {t}{'  (EXISTS)' if os.path.exists(t) else ''}")
            continue
        if os.path.exists(t) and "--force" not in sys.argv:
            if vkit.sha256(t) == digest:
                print(f"already there, identical: {t}")
                continue
            raise SystemExit(f"{t} exists and is a different file. Pick another title or pass --force.")
        vkit.copy_verified(src, t)
        print(f"copied, hash verified: {t}")
    print(f"sha256 {digest}")
    print("Not posted. Tell Deon where it is and ask: ship it, or change it?")


if __name__ == "__main__":
    main()
