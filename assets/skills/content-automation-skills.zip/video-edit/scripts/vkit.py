"""vkit - shared helpers for the video-edit skill.

Three things every tool here needs:
  lane()      one heavy job at a time on this PC, across every agent and every session
  probe()     what the source really is (size, fps, HLG or SDR, rotation, audio)
  envelope()  a 5 ms-hop RMS envelope of the voice, the only timing source cuts are allowed to trust
"""
import contextlib, hashlib, json, os, shutil, subprocess, sys, time

import numpy as np

PY = sys.executable
for _s in (sys.stdout, sys.stderr):                 # page text and transcripts carry curly quotes; cp1252 cannot
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
LOW = 0x00004000 if os.name == "nt" else 0      # BELOW_NORMAL_PRIORITY_CLASS
DEC = ["-threads", "4"]                          # goes before an -i (decoder threads)
FILT = ["-filter_threads", "2", "-filter_complex_threads", "2"]
ENC = ["-threads", "6"]                          # goes before the output (encoder threads)
LOCK = os.path.expanduser("~/.claude/video-edit-lane.lock")
DRIVE_SUB = "My Drive/YOUR_DRIVE_FOLDER/Video edits of myself"     # on your Drive account
# one HLG/PQ -> SDR chain for the render AND for every sheet and still, so a preview looks like the result
TONEMAP = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,"
           "zscale=t=bt709:m=bt709:r=tv")


# ---------- the render lane ----------
def _holder():
    try:
        return json.load(open(LOCK))
    except (OSError, ValueError):
        return None


def _alive(h):
    try:
        import psutil
        if not psutil.pid_exists(h["pid"]):
            return False
        return psutil.Process(h["pid"]).create_time() <= h["t"] + 5     # a recycled pid is not the holder
    except Exception:
        return True


@contextlib.contextmanager
def lane(what):
    """Hold the machine-wide render lane. This PC corrupts memory under load, so whisper, frame renders and
    encodes never overlap: a second caller waits here until the first one is done. A lock left by a dead
    process is taken over."""
    if os.environ.get("VK_LANE_HELD"):
        yield
        return
    told = False
    while True:
        try:
            fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, json.dumps({"pid": os.getpid(), "what": what, "t": time.time()}).encode())
            os.close(fd)
            break
        except FileExistsError:
            h = _holder()
            if h is None or not _alive(h):
                # Take a dead holder's lock away by renaming it: only one waiter's rename can succeed. If what
                # we pulled out turns out to be someone's fresh lock, it goes straight back.
                time.sleep(0.2)
                grave = f"{LOCK}.{os.getpid()}"
                try:
                    os.rename(LOCK, grave)
                except OSError:
                    continue
                try:
                    got = json.load(open(grave))
                except (OSError, ValueError):
                    got = None
                if got is not None and got != h and _alive(got):
                    with contextlib.suppress(OSError):
                        os.rename(grave, LOCK)
                else:
                    with contextlib.suppress(OSError):
                        os.remove(grave)
                continue
            if not told:
                print(f"[lane] waiting: pid {h['pid']} is running '{h['what']}'", file=sys.stderr, flush=True)
                told = True
            time.sleep(3)
    os.environ["VK_LANE_HELD"] = "1"
    try:
        import psutil
        psutil.Process().nice(psutil.BELOW_NORMAL_PRIORITY_CLASS if os.name == "nt" else 10)
    except Exception:
        pass
    try:
        yield
    finally:
        os.environ.pop("VK_LANE_HELD", None)
        with contextlib.suppress(OSError):
            os.remove(LOCK)


def run(cmd, heavy=False, check=True):
    """subprocess.run with captured text output; heavy jobs run at below-normal priority."""
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=LOW if heavy else 0)
    if check and p.returncode:
        raise SystemExit(f"FAILED ({p.returncode}): {' '.join(map(str, cmd))[:1200]}\n{p.stderr[-2500:]}")
    return p


# ---------- probing ----------
def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode:
        raise SystemExit(f"cannot read {path}: {r.stderr.strip()[-300:] or 'ffprobe failed'} "
                         "(an unfinished or broken file?)")
    j = json.loads(r.stdout)
    v = next((s for s in j["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in j["streams"] if s["codec_type"] == "audio"), None)
    if v is None:
        raise SystemExit(f"no video stream in {path}")

    def rate(k):
        n, d = (v.get(k) or "0/1").split("/")
        return float(n) / float(d) if float(d) else 0.0

    side = v.get("side_data_list", [])
    rot = 0
    for sd in side:
        if "rotation" in sd:
            rot = int(round(float(sd["rotation"])))
    w, h = v["width"], v["height"]
    if abs(rot) % 180 == 90:
        w, h = h, w                                  # ffmpeg auto-rotates on decode
    trc = v.get("color_transfer", "unknown")
    fps, avg = rate("r_frame_rate"), rate("avg_frame_rate")
    return {
        "path": path.replace("\\", "/"), "w": w, "h": h, "fps": round(fps, 3), "avg_fps": round(avg, 3),
        "vfr": abs(fps - avg) > 0.02 * max(fps, 1),
        "dur": round(float(j["format"]["duration"]), 3),
        "frames": int(v.get("nb_frames") or 0),
        "codec": v["codec_name"], "pix_fmt": v.get("pix_fmt"), "range": v.get("color_range", "unknown"),
        "trc": trc, "primaries": v.get("color_primaries", "unknown"), "matrix": v.get("color_space", "unknown"),
        "hdr": "hlg" if trc == "arib-std-b67" else "pq" if trc == "smpte2084" else "sdr",
        "dovi": any("DOVI" in sd.get("side_data_type", "") for sd in side),
        "rotation": rot, "tag": v.get("codec_tag_string"),
        "v_start": round(float(v.get("start_time") or 0), 3),
        "a_start": None if a is None else round(float(a.get("start_time") or 0), 3),
        "audio": None if a is None else {"codec": a["codec_name"], "sr": int(a["sample_rate"]),
                                         "ch": a.get("channels"), "dur": round(float(a.get("duration") or 0), 3)},
    }


def project():
    """project.json of the edit folder we are standing in."""
    try:
        return json.load(open("project.json", encoding="utf-8"))
    except OSError:
        raise SystemExit("no project.json here - cd into the edit folder (made by new_project.py) first")


# ---------- is this file still built from the current cut? ----------
# Every derived file (the cut transcript, captions, the mix, a render) records what it was built from in
# stamps.json. A tool that is about to use one checks the record first and refuses a stale file, because a
# render made from last round's captions or audio looks finished and is wrong.
def file_id(*paths):
    h = hashlib.md5()
    for p in paths:
        h.update(open(p, "rb").read() if os.path.exists(p) else b"<none>")
    return h.hexdigest()[:12]


def text_id(obj):
    return hashlib.md5(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:12]


def cut_id():
    """identity of the cut that is applied right now"""
    return file_id("cuts.json")


def edl_pending():
    """True when edl.txt has changed since `edl apply` last ran"""
    if not os.path.exists("cuts.json"):
        return os.path.exists("edl.txt") and any(
            ln.strip() and not ln.lstrip().startswith("#") for ln in open("edl.txt", encoding="utf-8"))
    return json.load(open("cuts.json")).get("edl") != file_id("edl.txt")


def stamps():
    try:
        return json.load(open("stamps.json", encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def stamp(name, value):
    s = stamps()
    s[name] = value
    json.dump(s, open("stamps.json", "w", encoding="utf-8"), indent=1)


def need_applied():
    if edl_pending():
        raise SystemExit("edl.txt has changed since the last `edl apply`. Run `python vk.py edl apply`, then "
                         "`edl verify`, before building anything on the cut.")


# ---------- audio envelope ----------
def envelope(media, sr=16000):
    """(env_db, dur): RMS in dB on a 5 ms hop / 20 ms window. Frame i covers [i*0.005, i*0.005+0.020]."""
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", media, "-vn", "-f", "f32le", "-ac", "1", "-ar", str(sr), "-"],
                         capture_output=True).stdout
    x = np.frombuffer(raw, np.float32).astype(np.float64)
    hop, win = int(sr * 0.005), int(sr * 0.020)
    if len(x) < win * 2:
        raise SystemExit(f"no usable audio in {media}")
    c = np.concatenate([[0.0], np.cumsum(x * x)])
    idx = np.arange((len(x) - win) // hop) * hop
    ms = np.maximum((c[idx + win] - c[idx]) / win, 0)
    return 20 * np.log10(np.sqrt(ms) + 1e-9), len(x) / sr


def speech_threshold(env):
    """Quiet = the bottom 30% of the range between the noise floor and normal speech."""
    floor, peak = np.percentile(env, 5), np.percentile(env, 95)
    return float(floor + 0.30 * (peak - floor)), float(floor), float(peak)


# ---------- stills ----------
def grab(path, t, hdr="sdr", width=None):
    """One frame at time t as a PIL image (tonemapped when the file is HLG/PQ)."""
    from PIL import Image
    vf = [TONEMAP] if hdr != "sdr" else []
    if width:
        vf.append(f"scale={width}:-2")
    vf.append("format=rgb24")
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{max(t, 0):.3f}", "-i", path, "-frames:v", "1", "-vf", ",".join(vf),
           "-f", "image2pipe", "-vcodec", "png", "-"]
    raw = subprocess.run(cmd, capture_output=True, creationflags=LOW).stdout
    if not raw:
        return None
    import io
    return Image.open(io.BytesIO(raw)).convert("RGB")


def sheet(path, out, times, hdr="sdr", cols=6, width=270):
    """Labelled contact sheet of the frames at `times` (seconds)."""
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.truetype("C:/Windows/Fonts/consolab.ttf", 20)
    tiles = []
    for t in times:
        im = grab(path, t, hdr, width)
        if im is None:
            im = Image.new("RGB", (width, width * 16 // 9), (90, 0, 0))
        d = ImageDraw.Draw(im)
        d.rectangle((0, 0, 92, 26), fill=(0, 0, 0))
        d.text((5, 3), f"{t:6.2f}", font=font, fill=(255, 230, 90))
        tiles.append(im)
    tw, th = tiles[0].size
    rows = (len(tiles) + cols - 1) // cols
    canvas = Image.new("RGB", (cols * tw, rows * th), (20, 20, 20))
    for i, im in enumerate(tiles):
        canvas.paste(im.resize((tw, th)), ((i % cols) * tw, (i // cols) * th))
    canvas.save(out)
    return out


# ---------- files ----------
def drive_dir():
    """The finished-edits folder on your Drive account, wherever it is mounted today.
    The two Drive mounts have swapped letters before (G: and H:), and the other account's Drive is full and has
    its own "Video edits of myself" at the root, so the folder is found by its path, never by a letter."""
    for letter in "GHIJKLDEF":
        d = f"{letter}:/{DRIVE_SUB}"
        if os.path.isdir(d):
            return d
    return None



def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def copy_verified(src, dst, tries=3):
    """Copy and read back. This PC flips bits now and then, so a copy only counts when the hashes match."""
    want = sha256(src)
    if sha256(src) != want:
        raise SystemExit(f"{src} hashes differently on two reads - memory fault, stop and tell Deon")
    for _ in range(tries):
        shutil.copyfile(src, dst)
        if sha256(dst) == want:
            return want
    raise SystemExit(f"copy of {src} to {dst} failed its hash check {tries} times")
