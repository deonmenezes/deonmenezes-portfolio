"""overlay.py - plain cards on hard cuts over the untouched clip. The "just show the sources, don't over-edit" look.

    python vk.py overlay preview      preview.png: for every card the frame before it, its middle, the frame after
    python vk.py overlay render       the file named in overlay.json

Nothing animates, nothing is cut, the audio stream is copied bit for bit, and an HLG clip stays HLG (HEVC main10,
hvc1). Only the Dolby Vision layer is lost, and it is always lost on re-encode. Cards appear and disappear on HIS
jump cuts: get those frame numbers from `python vk.py probe source.mp4 --jumpcuts`.

overlay.json:
  {"out": "sources.mp4",
   "npl": 700,                  HLG only: how bright card white is (this tool's default). 700 sits just under
                                burned-in captions; at ffmpeg's usual 203 a white card looks grey next to them
   "items": [
     {"png": "cards/bbc.png", "f": [224, 270], "y": 254},        frames [first, last+1] of the source
     {"png": "cards/cta.png", "t": [50.17, 54.5], "x": 0, "y": 325}   or seconds
   ]}
x and y are the card's TOP-LEFT corner in the clip's own pixels; x defaults to centred. (plan.py is different:
there x and y are the centre, and top= gives a top edge.) Keep cards over hair and forehead (top edge near
y=250-280 of 1920) so his eyes stay visible. Two cards that overlap in time are both drawn, later on top.
"""
import json, os, subprocess, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit
from PIL import Image

P = vkit.project()
INFO = P["source"]
SRC, FPS, HDR, SW, SH = INFO["path"], INFO["fps"], INFO["hdr"], INFO["w"], INFO["h"]


def load():
    if not os.path.exists("overlay.json"):
        raise SystemExit("no overlay.json here (a template is copied in by new_project.py)")
    cfg = json.load(open("overlay.json", encoding="utf-8"))
    os.makedirs("_ov", exist_ok=True)
    items = []
    if not cfg.get("items"):
        raise SystemExit("overlay.json has no items yet. Add one per card, e.g. "
                         '{"png": "cards/bbc.png", "f": [224, 270], "y": 254}')
    for i, it in enumerate(cfg["items"]):
        if "f" in it:
            a, b = it["f"]
            when = f"between(n,{a},{b - 1})"
        else:                                          # seconds are matched on timestamps, so they also hold on a
            ta, tb = it["t"]                           # variable-frame-rate clip, where frame numbers do not
            a, b = round(ta * FPS), round(tb * FPS)
            when = f"gte(t,{ta - 0.5 / FPS:.4f})*lt(t,{tb - 0.5 / FPS:.4f})"
        if b <= a:
            raise SystemExit(f"overlay.json item {i}: the window is empty")
        if "f" in it and INFO["vfr"]:
            print(f"  note: this clip has a variable frame rate; give item {i} in seconds (\"t\") rather than frames",
                  file=sys.stderr)
        im = Image.open(it["png"]).convert("RGBA")
        w, h = im.size
        if w % 2 or h % 2:                             # zscale and 4:2:0 both need even sizes
            even = Image.new("RGBA", (w + w % 2, h + h % 2), (0, 0, 0, 0))
            even.paste(im, (0, 0))
            im = even
        path = f"_ov/{i:02d}.png"
        im.save(path)
        x = it.get("x", (SW - im.size[0]) // 2)
        if x + im.size[0] > SW or it["y"] + im.size[1] > SH or x < 0 or it["y"] < 0:
            print(f"  note: {it['png']} hangs off the {SW}x{SH} frame at x={x}, y={it['y']}", file=sys.stderr)
        items.append(dict(png=path, name=os.path.basename(it["png"]), a=a, b=b, when=when,
                          x=x - x % 2, y=it["y"] - it["y"] % 2))
    return cfg, items


def graph(cfg, items):
    if HDR == "pq":
        raise SystemExit("this clip is PQ/HDR10: overlay.py only keeps HLG. Use compose.py (it tonemaps to SDR).")
    if HDR == "hlg":
        conv = (f"format=gbrap,zscale=pin=bt709:tin=iec61966-2-1:min=gbr:rin=full:p=bt2020:t=arib-std-b67:"
                f"m=bt2020nc:r=limited:npl={cfg.get('npl', 700)},format=yuva420p10le")
        fmt = "yuv420p10"
    else:
        rng = "full" if INFO["range"] == "pc" else "limited"
        mat = "bt601" if INFO["matrix"] in ("smpte170m", "bt470bg") else "bt709"
        conv = f"scale=out_color_matrix={mat}:out_range={rng},format=yuva420p"
        fmt = "yuv420"
    fc, last = [], "0:v"
    for i, it in enumerate(items, 1):
        fc.append(f"[{i}:v]{conv}[o{i}]")
        fc.append(f"[{last}][o{i}]overlay={it['x']}:{it['y']}:format={fmt}:enable='{it['when']}'[v{i}]")
        last = f"v{i}"
    return fc, last


def inputs(items):
    cmd = [*vkit.DEC, "-i", SRC]
    for it in items:
        cmd += ["-i", it["png"]]
    return cmd


def preview(cfg, items):
    from PIL import ImageDraw, ImageFont
    fc, last = graph(cfg, items)
    picks = []
    for it in items:
        picks += [(it["a"] - 1, it["name"], "before"), ((it["a"] + it["b"]) // 2, it["name"], "ON"), (it["b"], it["name"], "after")]
    picks = [p for p in picks if p[0] >= 0]
    order = sorted({n for n, *_ in picks})
    tw = 270
    th = (tw * SH // SW) // 2 * 2
    sel = "+".join(f"eq(n,{n})" for n in order)
    tm = f"{vkit.TONEMAP}," if HDR == "hlg" else ""
    fc.append(f"[{last}]select='{sel}',{tm}scale={tw}:{th},format=rgb24[out]")
    open("_ov/preview.fc", "w").write(";".join(fc))
    with vkit.lane("overlay preview"):
        raw = subprocess.run(["ffmpeg", "-v", "error", *inputs(items), *vkit.FILT, "-/filter_complex", "_ov/preview.fc",
                              "-map", "[out]", "-fps_mode", "passthrough", "-f", "rawvideo", "-"],
                             capture_output=True, creationflags=vkit.LOW).stdout
    got = len(raw) // (tw * th * 3)
    if got != len(order):
        print(f"  warning: asked for {len(order)} frames, got {got} (a window may run past the end of the clip)")
    frame = {n: Image.frombytes("RGB", (tw, th), raw[k * tw * th * 3:(k + 1) * tw * th * 3]) for k, n in enumerate(order[:got])}
    font = ImageFont.truetype("C:/Windows/Fonts/consolab.ttf", 17)
    sheet = Image.new("RGB", (3 * tw, len(items) * th), (20, 20, 20))
    for r, it in enumerate(items):
        for c, (n, tag) in enumerate(((it["a"] - 1, "before"), ((it["a"] + it["b"]) // 2, "ON"), (it["b"], "after"))):
            if n not in frame:
                continue
            im = frame[n].copy()
            d = ImageDraw.Draw(im)
            d.rectangle((0, 0, tw, 24), fill=(0, 0, 0))
            d.text((4, 3), f"{it['name'][:14]} {tag} f{n}", font=font, fill=(255, 230, 90))
            sheet.paste(im, (c * tw, r * th))
    sheet.save("preview.png")
    print(f"preview.png: {len(items)} rows (before | ON | after). Each card must be there in the middle column and gone")
    print("in the other two (a back-to-back neighbour's card may show there instead). It must not cover his eyes, and")
    print("its white must not look grey next to any burned-in captions.")


def render(cfg, items):
    out = cfg.get("out", "overlay.mp4")
    fc, last = graph(cfg, items)
    open("_ov/render.fc", "w").write(";".join(fc))
    cmd = ["ffmpeg", "-hide_banner", "-v", "error", "-y", *inputs(items), *vkit.FILT, "-/filter_complex", "_ov/render.fc",
           "-map", f"[{last}]", "-map", "0:a?", "-c:a", "copy"]
    if HDR == "hlg":
        cmd += ["-c:v", "hevc_nvenc", "-profile:v", "main10", "-pix_fmt", "p010le", "-rc", "vbr", "-cq", "19", "-b:v", "0",
                "-preset", "p6", "-tag:v", "hvc1", "-color_primaries", "bt2020", "-color_trc", "arib-std-b67",
                "-colorspace", "bt2020nc", "-color_range", "tv"]
    else:
        tag = lambda k, d: INFO[k] if INFO[k] not in ("unknown", None) else d
        cmd += ["-c:v", "libx264", "-preset", "slow", "-crf", "17", "-profile:v", "high", "-pix_fmt", "yuv420p", *vkit.ENC,
                "-color_primaries", tag("primaries", "bt709"), "-color_trc", tag("trc", "bt709"),
                "-colorspace", tag("matrix", "bt709"), "-color_range", "pc" if INFO["range"] == "pc" else "tv"]
    cmd += ["-movflags", "+faststart", out]
    with vkit.lane(f"overlay render {out}"):
        vkit.run(cmd, heavy=True)
    print(f"{out}: {len(items)} cards over {SRC} ({HDR.upper()} kept, audio copied). Now: python vk.py qc {out}")


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("preview", "render"):
        print(__doc__)
        sys.exit(1)
    if os.path.exists("cuts.json"):
        print("  note: there is a cuts.json here, and this lane does not cut. Cards go on the UNCUT clip.", file=sys.stderr)
    cfg, items = load()
    (preview if sys.argv[1] == "preview" else render)(cfg, items)


if __name__ == "__main__":
    main()
