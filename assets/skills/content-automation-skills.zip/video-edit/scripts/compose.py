"""compose.py - the frame-by-frame compositor for every look that cuts, captions, splits or animates.

    python vk.py compose --stills 3.2,10.5,22      composite just these NEW-timeline seconds -> stills/ + stills/sheet.png
    python vk.py compose -o draft.mp4              the whole video (captions.ass and mix.wav are used when present)
    python vk.py compose -o part.mp4 --range 8 20  only this stretch, with its audio and captions in sync

It reads plan.py (what goes on screen), cuts.json (what was removed), captions.ass and mix.wav, all from the edit
folder. An HLG or PQ source is tonemapped to SDR here; output is 8-bit H.264 bt709. Look at stills before you
spend a full render: a wrong y or a card over his eyes is visible in one frame. (Stills show the grade and the
captions, not the fade-out.)

It refuses to build on stale inputs: if edl.txt changed without `edl apply`, or captions.ass, mix.wav or the
animation frames were made for an earlier cut or plan, it says which tool to run again. After any re-cut the
order is: edl apply -> edl verify -> captions -> mix -> render_anim --plan -> compose.

In a card or anim segment, x and y are the CENTRE of the graphic. A card can use top= instead of y= to be placed
by its top edge, the way overlay.json places cards.
"""
import contextlib, glob, os, subprocess, sys

import cv2
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit
import planlib
from planlib import W, H, FPS, PANEL_H, SHIFT, FACE_C, get
from timemap import NEW_DUR, N_FRAMES, cut_frames

SRC, HDR = planlib.P["source"]["path"], planlib.P["source"]["hdr"]
N = N_FRAMES
PUNCH, GRADE, FINISH, FADE_OUT = get("PUNCH", 0.07), get("GRADE", ""), get("FINISH", ""), get("FADE_OUT", 0.35)
SLIDE, SEAM = get("SLIDE", 0.30), get("SEAM", None)
# a caption font that is not installed (the rounded house font, 2026-10-19) is read from ./fonts when the edit has one
ASS = "ass=captions.ass" + (":fontsdir=fonts" if os.path.isdir("fonts") else "")
XF = 4 / FPS
SEG = planlib.segments()
SPLITS = [s for s in SEG if s["kind"] == "split"]
SPANS = planlib.split_spans()
CUT_F = cut_frames()
_cache = {}


def preflight(need_mix):
    """Refuse to build on anything that was made for an earlier cut or an earlier plan. A render made from
    last round's captions, audio or animation frames looks finished, passes a glance, and is wrong."""
    vkit.need_applied()
    st = vkit.stamps()
    if os.path.exists("captions.ass"):
        c = st.get("captions") or {}
        if c.get("id") != planlib.captions_id(c.get("none", False)):
            raise SystemExit("captions.ass is out of date (the cut, the plan, captions.json or the words changed since "
                             "it was built). Run `python vk.py captions` again.")
    if need_mix and os.path.exists("mix.wav") and (st.get("mix") or {}).get("cut") != vkit.cut_id():
        raise SystemExit("mix.wav was made for an earlier cut: the sound would drift against the picture. "
                         "Run `python vk.py mix ...` again.")
    for j in planlib.anim_jobs():
        d, key = f"anim_{j['name']}", planlib.anim_key(j)
        last = f"{d}/f{planlib.anim_frames(j) - 1:04d}.png"
        if not os.path.exists(f"{d}/.key") or open(f"{d}/.key").read() != key or not os.path.exists(last):
            raise SystemExit(f"the frames in {d}/ are missing, unfinished, or were rendered for other timing. "
                             "Run `python vk.py render_anim --plan` again.")


def ease(x):
    x = min(max(x, 0.0), 1.0)
    return x * x * (3 - 2 * x)


def back(x, s=1.4):
    x = min(max(x, 0.0), 1.0) - 1
    return 1 + (s + 1) * x ** 3 + s * x ** 2


def punch(n):
    """every other kept piece is punched in a little; counted in frames so the zoom changes ON the splice"""
    return 1.0 + PUNCH * (sum(1 for c in CUT_F if c <= n) % 2)


def zoom_about(img, z, cx, cy):
    if abs(z - 1) < 1e-4:
        return img.copy()
    M = np.float32([[z, 0, cx - z * cx], [0, z, cy - z * cy]])
    return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)


def blit(frame, rgba, cx, cy, scale=1.0, alpha=1.0):
    """straight-alpha BGRA onto the frame, centred at (cx, cy)"""
    if alpha <= 0.002:
        return
    if abs(scale - 1) > 1e-3:
        rgba = cv2.resize(rgba, None, fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)
    h, w = rgba.shape[:2]
    x0, y0 = int(round(cx - w / 2)), int(round(cy - h / 2))
    fx0, fy0, fx1, fy1 = max(x0, 0), max(y0, 0), min(x0 + w, W), min(y0 + h, H)
    if fx1 <= fx0 or fy1 <= fy0:
        return
    sub = rgba[fy0 - y0:fy1 - y0, fx0 - x0:fx1 - x0]
    a = (sub[..., 3:].astype(np.float32) / 255) * alpha
    dst = frame[fy0:fy1, fx0:fx1].astype(np.float32)
    frame[fy0:fy1, fx0:fx1] = (sub[..., :3] * a + dst * (1 - a)).astype(np.uint8)


def dim(frame, strength):
    """blur and darken what is behind a card so the card reads"""
    if strength <= 0.002:
        return frame
    small = cv2.GaussianBlur(cv2.resize(frame, (W // 8, H // 8), interpolation=cv2.INTER_AREA), (0, 0), 5)
    bg = cv2.convertScaleAbs(cv2.resize(small, (W, H), interpolation=cv2.INTER_CUBIC), alpha=0.30)
    return cv2.addWeighted(frame, 1 - strength, bg, strength, 0)


def framed(bgr, radius, shadow=22):
    """rounded corners and a soft drop shadow -> BGRA"""
    h, w = bgr.shape[:2]
    pad = shadow * 2
    mask = np.zeros((h, w), np.uint8)
    cv2.rectangle(mask, (radius, 0), (w - radius, h), 255, -1)
    cv2.rectangle(mask, (0, radius), (w, h - radius), 255, -1)
    for cx, cy in ((radius, radius), (w - radius, radius), (radius, h - radius), (w - radius, h - radius)):
        cv2.circle(mask, (cx, cy), radius, 255, -1, cv2.LINE_AA)
    out = np.zeros((h + 2 * pad, w + 2 * pad, 4), np.uint8)
    sh = np.zeros(out.shape[:2], np.uint8)
    sh[pad + 10:pad + 10 + h, pad:pad + w] = mask
    sh = (cv2.GaussianBlur(sh, (0, 0), shadow / 2).astype(np.float32) * 0.6).astype(np.uint8)
    m = np.zeros(out.shape[:2], np.uint8)
    m[pad:pad + h, pad:pad + w] = mask
    out[pad:pad + h, pad:pad + w, :3] = bgr
    out[..., 3] = np.maximum(sh, m)                 # shadow pixels: black colour, partial alpha
    return out


def card_image(seg):
    key = ("card", seg["png"], seg.get("maxw"), seg.get("maxh"), seg.get("round"), bool(seg.get("hard")))
    if key not in _cache:
        im = cv2.imread(seg["png"], cv2.IMREAD_UNCHANGED)
        if im is None:
            raise SystemExit(f"plan.py: cannot read {seg['png']}")
        if im.ndim == 2:
            im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
        if seg.get("round"):
            im = framed(im[..., :3], seg["round"])
        elif im.shape[2] == 3:
            im = np.dstack([im, np.full(im.shape[:2], 255, np.uint8)])
        s = min(seg.get("maxw", W - 80) / im.shape[1], seg.get("maxh", H * 0.6) / im.shape[0], 1.0 if seg.get("hard") else 9)
        if abs(s - 1) > 1e-3:
            im = cv2.resize(im, None, fx=s, fy=s, interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
        _cache[key] = im
    return _cache[key]


def anim_count(name):
    if ("n", name) not in _cache:
        n = len(glob.glob(f"anim_{name}/f*.png"))
        if not n:
            raise SystemExit(f"no frames in anim_{name}/ - run `python vk.py render_anim --plan` first")
        _cache[("n", name)] = n
    return _cache[("n", name)]


def anim_frame(seg, t, flags=cv2.IMREAD_COLOR):
    idx = min(max(int((t - seg["t0"]) * FPS + 1e-6), 0), anim_count(seg["name"]) - 1)
    return cv2.imread(f"anim_{seg['name']}/f{idx:04d}.png", flags)


def cover(im, z=1.0):
    """fill the frame with im, zoomed by z about its centre"""
    h, w = im.shape[:2]
    s = max(W / w, H / h) * z
    cw, ch = W / s, H / s
    x0, y0 = (w - cw) / 2, (h - ch) / 2
    M = np.float32([[s, 0, -x0 * s], [0, s, -y0 * s]])
    return cv2.warpAffine(im, M, (W, H), flags=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)


def sdr_copy(src):
    """An HLG or PQ b-roll clip read straight through OpenCV comes out flat and grey, so it is tonemapped once
    into _broll/ with the same chain as the main picture."""
    if vkit.probe(src)["hdr"] == "sdr":
        return src
    os.makedirs("_broll", exist_ok=True)
    out = f"_broll/{os.path.splitext(os.path.basename(src))[0]}_sdr.mp4"
    if not os.path.exists(out) or os.path.getmtime(out) < os.path.getmtime(src):
        print(f"  {src} is HDR: making an SDR copy for b-roll -> {out}", file=sys.stderr)
        vkit.run(["ffmpeg", "-v", "error", "-y", *vkit.DEC, "-i", src, "-an", "-vf",
                  f"{vkit.TONEMAP},format=yuv420p,setparams=color_primaries=bt709:color_trc=bt709:colorspace=bt709:range=tv",
                  "-c:v", "libx264", "-preset", "fast", "-crf", "16", *vkit.ENC, out], heavy=True)
    return out


def broll_frame(seg, t):
    src = seg["src"]
    p = (t - seg["t0"]) / max(seg["t1"] - seg["t0"], 1e-6)
    z0, z1 = seg.get("z", (1.04, 1.12))
    if src.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
        if ("img", src) not in _cache:
            im = cv2.imread(src, cv2.IMREAD_COLOR)
            if im is None:
                raise SystemExit(f"plan.py: cannot read {src}")
            _cache[("img", src)] = im
        return cover(_cache[("img", src)], z0 + (z1 - z0) * p)
    st = _cache.get(("vid", id(seg)))
    if st is None:
        cap = cv2.VideoCapture(sdr_copy(src))
        if not cap.isOpened():
            raise SystemExit(f"plan.py: cannot open {src}")
        fps = cap.get(cv2.CAP_PROP_FPS) or 30
        have = cap.get(cv2.CAP_PROP_FRAME_COUNT) / fps - seg.get("start", 0.0)
        need = seg["t1"] - seg["t0"]
        if have < need - 0.1:                        # it would freeze on its last frame for the rest
            raise SystemExit(f"plan.py: {src} has {max(have, 0):.1f} s left after start={seg.get('start', 0.0)} but the "
                             f"segment is {need:.1f} s long. Shorten the segment or start the clip earlier.")
        st = _cache[("vid", id(seg))] = {"cap": cap, "fps": fps, "pos": -1, "im": None}
    want = int((seg.get("start", 0.0) + (t - seg["t0"])) * st["fps"])
    if want != st["pos"] + 1 and want != st["pos"]:
        st["cap"].set(cv2.CAP_PROP_POS_FRAMES, want)
        st["pos"] = want - 1
    while st["pos"] < want:
        ok, im = st["cap"].read()
        st["pos"] += 1
        if ok:
            st["im"] = im
        else:
            break                                   # past the end of the clip: hold its last frame
    if st["im"] is None:
        raise SystemExit(f"plan.py: {src} has no frame at {seg.get('start', 0.0)} s")
    return cover(st["im"], seg.get("z", (1.0, 1.0))[0])


def window(t, s, e, fin, fout):
    return min(ease((t - s) / fin), ease((e - t) / fout))


def split_p(t):
    """0 = full frame, 1 = fully split"""
    for s, e in SPANS:
        if s <= t < e + SLIDE:
            p_in = 1.0 if s <= 0.05 else ease((t - s) / SLIDE)
            p_out = 1.0 if e >= NEW_DUR - 0.05 else ease((e + SLIDE - t) / SLIDE)
            return min(p_in, p_out)
    return 0.0


def panel(t):
    cur = max((i for i, s in enumerate(SPLITS) if s["t0"] <= t), default=0)
    im = anim_frame(SPLITS[cur], t)
    s0 = SPLITS[cur]["t0"]
    if cur and t - s0 < 0.14 and s0 - SPLITS[cur - 1]["t1"] < 0.05:      # quick dissolve between back-to-back panels
        a = ease((t - s0) / 0.14)
        im = cv2.addWeighted(im, a, anim_frame(SPLITS[cur - 1], t), 1 - a, 0)
    if im.shape[:2] != (PANEL_H, W):
        raise SystemExit(f"panel frames are {im.shape[1]}x{im.shape[0]}, the plan wants {W}x{PANEL_H}: re-render the anims")
    return im


def render(base, n):
    """frame n of the new timeline. Segment times sit exactly on frames (planlib), so t0 <= t < t1 is exact."""
    t = n / FPS
    frame = zoom_about(base, punch(n), *FACE_C)
    for s in SEG:
        if s["kind"] == "broll" and s["t0"] <= t < s["t1"]:
            a = 1.0 if s.get("hard") else window(t + 1 / FPS, s["t0"], s["t1"], XF, XF)   # 4-frame dissolve each way
            b = broll_frame(s, t)
            frame = b if a >= 0.999 else cv2.addWeighted(b, a, frame, 1 - a, 0)
    p = split_p(t) if SPLITS else 0.0
    if p > 0.001:
        dy, ph = int(round(SHIFT * p)), int(round(PANEL_H * p))
        frame = cv2.warpAffine(frame, np.float32([[1, 0, 0], [0, 1, dy]]), (W, H), borderMode=cv2.BORDER_REPLICATE)
        frame[0:ph] = panel(t)[PANEL_H - ph:PANEL_H]                       # the panel slides down from the top edge
        if SEAM:
            cv2.rectangle(frame, (0, ph - 3), (W, ph + 3), SEAM[::-1], -1)
    for s in SEG:
        if s["kind"] not in ("card", "anim"):
            continue
        hard = s.get("hard", False)
        if not (s["t0"] <= t < s["t1"] + (0 if hard else 0.13)):
            continue
        env = 1.0 if hard else window(t, s["t0"], s["t1"] + 0.12, 0.16, 0.12)
        if s.get("dim") and not hard:
            frame = dim(frame, env * s["dim"])
        # x, y are the CENTRE of the graphic. top= places a card by its top edge instead (as overlay.json does)
        cx = s.get("x", W / 2)
        if s["kind"] == "card":
            im = card_image(s)
            cy = s["top"] + im.shape[0] / 2 if "top" in s else s.get("y", H * 0.42)
            pop = 1.0 if hard else 0.93 + 0.07 * back((t - s["t0"]) / 0.30)
            blit(frame, im, cx, cy, pop, env)
        else:
            im = anim_frame(s, t, cv2.IMREAD_UNCHANGED)
            if im.shape[2] == 3:
                im = np.dstack([im, np.full(im.shape[:2], 255, np.uint8)])
            # a full-frame animation is centred on the frame; a smaller one sits upper-middle like a card
            cy = s.get("y", H / 2 if im.shape[0] >= H else H * 0.42)
            blit(frame, im, cx, cy, 1.0, env)
    return frame


def decoder():
    fc = open("video_cut.fc").read() if os.path.exists("video_cut.fc") else f"[0:v]fps={FPS}[vc]"
    chain = []
    if HDR != "sdr":
        chain += [vkit.TONEMAP, "format=yuv420p"]    # the same chain every sheet and still uses
    chain.append(f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}")
    if GRADE:
        chain.append(GRADE)
    chain += [f"fps={FPS}", "format=bgr24"]         # the rate is declared last, and frames are passed through
    open("video_cut_full.fc", "w").write(f"{fc};[vc]{','.join(chain)}[out]")    # untouched: exactly N come out
    # stderr goes to a file: stopping early (stills, --range) makes ffmpeg complain about a broken pipe, which
    # is not an error, while a real decode error must still be readable
    return subprocess.Popen(["ffmpeg", "-v", "error", *vkit.DEC, "-i", SRC, *vkit.FILT, "-/filter_complex",
                             "video_cut_full.fc", "-map", "[out]", "-fps_mode", "passthrough", "-f", "rawvideo",
                             "-pix_fmt", "bgr24", "-"],
                            stdout=subprocess.PIPE, stderr=open("_decode.log", "w"), creationflags=vkit.LOW)


def encoder(out, ta, tb):
    vf = [FINISH] if FINISH else []
    if os.path.exists("captions.ass"):
        vf += ([f"setpts=PTS+{ta}/TB"] if ta else []) + [ASS] + ([f"setpts=PTS-{ta}/TB"] if ta else [])
    else:
        print("no captions.ass here: rendering without captions or pop-ups", file=sys.stderr)
    if FADE_OUT and tb >= NEW_DUR - 1e-3:
        vf.append(f"fade=t=out:st={tb - ta - FADE_OUT:.3f}:d={FADE_OUT}")
    # setparams, not only the -color_* output options: ffmpeg 7 takes the tags from the frames, and raw BGR
    # frames have none, so without it the file is written with transfer and primaries "unknown"
    vf += ["scale=out_color_matrix=bt709:out_range=tv", "format=yuv420p",
           "setparams=color_primaries=bt709:color_trc=bt709:colorspace=bt709:range=tv"]
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"]
    audio = os.path.exists("mix.wav")
    if audio:
        cmd += ["-ss", f"{ta:.4f}", "-t", f"{tb - ta:.4f}", "-i", "mix.wav"]
    else:
        print("rendering SILENT (--silent): this is a picture check, not a deliverable", file=sys.stderr)
    cmd += [*vkit.FILT, "-filter_complex", f"[0:v]{','.join(vf)}[v]", "-map", "[v]"]
    if audio:
        cmd += ["-map", "1:a", "-c:a", "aac", "-b:a", "256k"]
    cmd += ["-c:v", "libx264", "-preset", "slow", "-crf", "17", "-profile:v", "high", "-pix_fmt", "yuv420p",
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
            *vkit.ENC, "-movflags", "+faststart", "-t", f"{tb - ta:.4f}", out]
    return subprocess.Popen(cmd, stdin=subprocess.PIPE, creationflags=vkit.LOW)


def frames(wanted, last):
    """yield (n, composited frame) for the frame numbers in `wanted` (a set, or None for all up to `last`)"""
    dec = decoder()
    fsz, prev = W * H * 3, None
    try:
        for n in range(last):
            buf = dec.stdout.read(fsz)
            if len(buf) < fsz:
                if prev is None or n < last - 3:        # nothing at all, or more than a few frames short
                    rc = dec.wait()
                    raise SystemExit(f"the decoder gave {n} frames where {last} were needed (ffmpeg exit code {rc}). "
                                     "Its log:\n" + (open("_decode.log").read()[-1500:] or "(empty)"))
                buf = prev                           # the source ran a frame or two short: hold the last one
            prev = buf
            if wanted is None or n in wanted:
                yield n, render(np.frombuffer(buf, np.uint8).reshape(H, W, 3), n)
    finally:
        dec.stdout.close()
        dec.kill()                                   # our own child, by handle
        dec.wait()


def stills(times):
    os.makedirs("stills", exist_ok=True)
    want = {min(max(int(round(t * FPS)), 0), N - 1): t for t in times}
    paths = []
    for n, frame in frames(set(want), max(want) + 1):
        t = n / FPS
        path = f"stills/c_{t:07.2f}.png"
        vf = [FINISH] if FINISH else []                  # the grade, then the captions at this frame's own time
        if os.path.exists("captions.ass"):
            vf += [f"setpts=PTS+{t}/TB", ASS]
        if vf:
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}",
                            "-r", str(FPS), "-i", "-", "-vf", ",".join(vf), "-frames:v", "1",
                            "-update", "1", path], input=frame.tobytes(), creationflags=vkit.LOW, check=True)
        else:
            cv2.imwrite(path, frame)
        paths.append((t, path))
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.truetype("C:/Windows/Fonts/consolab.ttf", 22)
    tw = 360
    th = tw * H // W
    cols = min(len(paths), 6)
    sheet = Image.new("RGB", (cols * tw, ((len(paths) + cols - 1) // cols) * th), (20, 20, 20))
    for i, (t, path) in enumerate(paths):
        im = Image.open(path).convert("RGB").resize((tw, th))
        d = ImageDraw.Draw(im)
        d.rectangle((0, 0, 104, 30), fill=(0, 0, 0))
        d.text((6, 4), f"{t:7.2f}", font=font, fill=(255, 230, 90))
        sheet.paste(im, ((i % cols) * tw, (i // cols) * th))
    sheet.save("stills/sheet.png")
    print(f"{len(paths)} stills -> stills/  (Read stills/sheet.png; open a single c_*.png for full size)")


def main():
    a = sys.argv[1:]
    if "--stills" in a:
        preflight(need_mix=False)
        with vkit.lane("compose stills"):
            stills([float(x) for x in a[a.index("--stills") + 1].split(",")])
        return
    if "-o" not in a:
        print(__doc__)
        sys.exit(1)
    out = a[a.index("-o") + 1]
    na, nb = 0, N
    if "--range" in a:
        i = a.index("--range")
        na, nb = max(int(round(float(a[i + 1]) * FPS)), 0), min(int(round(float(a[i + 2]) * FPS)), N)
        if nb <= na:
            raise SystemExit(f"--range is empty: the video is {NEW_DUR:.2f} s long")
    ta, tb = na / FPS, nb / FPS
    preflight(need_mix=True)
    if not os.path.exists("mix.wav") and "--silent" not in a:
        raise SystemExit("no mix.wav here. Run `python vk.py mix --voice` first (or pass --silent for a picture-only "
                         "check render, which qc will fail).")
    with vkit.lane(f"compose {out}"):
        enc = encoder(out, ta, tb)
        done = 0
        try:
            for n, frame in frames(None, nb):
                if n < na:
                    continue
                enc.stdin.write(frame.tobytes())
                done += 1
                if done % 300 == 0:
                    print(f"  {done}/{nb - na} frames", file=sys.stderr, flush=True)
            enc.stdin.close()
            if enc.wait():
                raise SystemExit("the encoder failed (see the ffmpeg error above)")
            if done != nb - na:
                raise SystemExit(f"only {done} of {nb - na} frames were written")
        except BaseException:
            # never leave a short file behind that looks like a finished render
            with contextlib.suppress(Exception):
                enc.stdin.close()
            enc.wait()
            with contextlib.suppress(OSError):
                os.remove(out)
            print(f"{out} was NOT written.", file=sys.stderr)
            raise
    # what this file was built from, so qc can tell a render of an earlier cut from a current one
    vkit.stamp("build:" + os.path.basename(out), {"cut": vkit.cut_id(), "sha256": vkit.sha256(out),
                                                 "excerpt": [ta, tb] if (na, nb) != (0, N) else None})
    print(f"{out}: {done} frames, {done / FPS:.2f} s ({W}x{H} at {FPS} fps). Now: python vk.py qc {out}")


if __name__ == "__main__":
    main()
