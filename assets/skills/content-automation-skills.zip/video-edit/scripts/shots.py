"""shots.py - real screenshots of real pages, with the exact sentence highlighted. Never a redrawn "quote card".

    python vk.py shots jobs.json [name ...]

jobs.json is a list of:
  {"name": "bbc_steroids",                 file stem under shots/
   "url":  "https://www.bbc.com/...",
   "rx":   "an estimated 500,000 people",  the sentence to highlight (a regex, matched case-insensitively)
   "mode": "crops" | "view",               crops (default): masthead strip, headline and highlighted paragraph as
                                           three phone-width crops for cards.py. view: one capture of the page
                                           around the highlight, for a card segment with round=30
   "click": "No, thank you",               a consent button to press first (the Guardian needs this)
   "soft": true, "wait": 4000, "lines": 1, "top_h": 700}

Output: shots/<name>_top.png, _h1.png, _para.png (crops) or shots/<name>.png (view).

It prints the headline and the paragraph it found. "NO MATCH" means the sentence is not on that page: fix the
regex or drop the source, do not ship a card whose highlight you did not see. A bot-check page is reported as
BOT WALL: pick another outlet, do not try to get around it.
"""
import json, os, sys

from playwright.sync_api import sync_playwright

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit  # noqa: F401  (utf-8 console)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/141.0.0.0 Safari/537.36")
WALL = ("just a moment", "access denied", "attention required", "are you a robot", "verify you are human",
        "pardon our interruption", "captcha", "security check")

CLEAN = """
(soft) => {
  for (const sel of ['[id^="sp_message_container"]', '#onetrust-consent-sdk', '.fc-consent-root', '[class*="cookie"]', '[id*="cookie"]'])
    for (const el of document.querySelectorAll(sel)) el.remove();
  for (const el of document.querySelectorAll('*')) {
    const cs = getComputedStyle(el);
    if ((cs.position === 'fixed' || cs.position === 'sticky') && el.getBoundingClientRect().height > 40) {
      const t = (el.innerText || '').toLowerCase();
      if (/cookie|consent|subscribe|sign up|newsletter|privacy|accept|advert/.test(t) || (!soft && el.getBoundingClientRect().height > 200))
        el.style.display = 'none';
    }
  }
  for (const el of [document.documentElement, document.body]) {
    el.style.overflow = 'auto'; el.style.position = 'static'; el.classList.remove('sp-message-open');
  }
}
"""

HL = """
(rx) => {
  const re = new RegExp(rx, 'i');
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n, hits = [];
  while ((n = w.nextNode())) {
    const p = n.parentElement;
    if (!p || /SCRIPT|STYLE|NOSCRIPT/.test(p.tagName)) continue;
    const m = re.exec(n.nodeValue);
    if (m) hits.push([n, m]);
  }
  if (!hits.length) return null;
  const body = hits.find(([n]) => n.parentElement.closest('p') && !n.parentElement.closest('figcaption'));
  const [node, m] = body || hits[0];
  const r = document.createRange();
  r.setStart(node, m.index); r.setEnd(node, m.index + m[0].length);
  const mark = document.createElement('mark');
  mark.id = 'srcmark';
  mark.style.cssText = 'background:#ffe45c;color:#111;padding:2px 0;box-decoration-break:clone;-webkit-box-decoration-break:clone';
  r.surroundContents(mark);
  const blk = mark.closest('p,figcaption,li,div');
  const b = mark.getBoundingClientRect(), pb = blk.getBoundingClientRect();
  const lh = parseFloat(getComputedStyle(blk).lineHeight) || 24;
  return {text: blk.innerText.slice(0, 500), top: b.top + scrollY, bottom: b.bottom + scrollY,
          ptop: pb.top + scrollY, pbottom: pb.bottom + scrollY, lh};
}
"""

H1 = """
() => { const h = document.querySelector('h1'); if (!h) return null; const b = h.getBoundingClientRect();
        return {text: h.innerText, top: b.top + scrollY, bottom: b.bottom + scrollY}; }
"""


def shoot(pw, j):
    name, view = j["name"], j.get("mode", "crops") == "view"
    for old in (f"shots/{name}.png", f"shots/{name}_top.png", f"shots/{name}_h1.png", f"shots/{name}_para.png",
                f"cards/{name}.png"):                  # a failed re-shoot must not leave last time's crops
        if os.path.exists(old):                       # (or the card built from them) to be mistaken for this page
            os.remove(old)
    w, h, dsf = (700, 1700, 2) if view else (430, 1200, 3)
    b = pw.chromium.launch(channel="chrome", headless=True, args=["--disable-blink-features=AutomationControlled"])
    try:
        pg = b.new_context(viewport={"width": w, "height": h}, device_scale_factor=dsf, user_agent=UA).new_page()
        pg.goto(j["url"], wait_until="domcontentloaded", timeout=60000)
        pg.wait_for_timeout(j.get("wait", 4000))
        title = pg.title()
        if any(x in title.lower() for x in WALL):
            print(f"BOT WALL {name} | {title} | use another outlet for this claim")
            return
        if j.get("click"):
            done = False
            for fr in pg.frames:
                try:
                    btn = fr.get_by_role("button", name=j["click"])
                    if btn.count():
                        btn.first.click(timeout=4000)
                        done = True
                        break
                except Exception:
                    pass
            print(f"  click '{j['click']}' -> {'done' if done else 'NOT FOUND'}")
            pg.wait_for_timeout(1500)
        else:                                        # no consent button named: hide banners and sticky bars instead
            pg.evaluate(CLEAN, bool(j.get("soft")))
        pg.wait_for_timeout(500)
        pg.evaluate("window.scrollTo(0,0)")

        def clip(out, y0, y1):
            y0 = max(y0, 0)
            pg.screenshot(path=out, full_page=True, clip={"x": 0, "y": y0, "width": w, "height": max(y1 - y0, 20)})

        head = pg.evaluate(H1)
        m = pg.evaluate(HL, j["rx"]) if j.get("rx") else None
        if view:
            if m:
                clip(f"shots/{name}.png", m["top"] - j.get("before", 260), m["bottom"] + j.get("after", 430))
            else:
                clip(f"shots/{name}.png", 0, j.get("h", 900))
        else:
            clip(f"shots/{name}_top.png", 0, j.get("top_h", 700))
            if head:
                clip(f"shots/{name}_h1.png", head["top"] - 14, head["bottom"] + 14)
            if m:
                pad = j.get("lines", 0) * m["lh"]
                clip(f"shots/{name}_para.png", max(m["top"] - 4 - pad, m["ptop"] - 10), min(m["bottom"] + 4 + pad, m["pbottom"] + 10))
        found = "-" if not j.get("rx") else ("NO MATCH" if not m else m["text"].replace("\n", " "))
        print(f"{'OK' if (m or not j.get('rx')) else 'NO MATCH'} {name} | h1: {(head or {}).get('text')} | para: {found}")
    finally:
        b.close()


def main():
    if len(sys.argv) < 2 or not os.path.exists(sys.argv[1]):
        print(__doc__)
        sys.exit(1)
    jobs = json.load(open(sys.argv[1], encoding="utf-8"))
    only = set(sys.argv[2:])
    os.makedirs("shots", exist_ok=True)
    with sync_playwright() as pw:
        for j in jobs:
            if only and j["name"] not in only:
                continue
            try:
                shoot(pw, j)
            except Exception as e:
                msg = str(e).splitlines()[0][:200]
                print(f"ERR {j['name']} | {msg} | the page did not load: check the URL, or use another outlet")


if __name__ == "__main__":
    main()
