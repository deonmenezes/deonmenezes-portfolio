"""Two-font title pairs in the Instagram Edits style (Deon, 2026-10-20: "use the combination of these two fonts
styles"). One huge display word plus a contrasting accent word, rendered as a transparent PNG that plan.py places
as a card. Styles and their free font matches (the IG Edits fonts themselves are not downloadable):

  magari   "sunflower" over "MAGARI": a small thin lowercase sans (Quicksand Light) sits above a giant condensed
           high-contrast serif in capitals (Bodoni Moda Black, squeezed). Both white.
  airone   "AIRONE" + "Charli": an ultra-wide heavy sans in capitals (Unbounded Black), white, with a thin handwritten
           script (Nothing You Could Do) in deep green crossing its lower half.
  tallica  "TALLICA" + "THINKER": a tall condensed sans in capitals (Antonio, stretched), white, with red scratchy pen
           capitals (Shadows Into Light) crossing its middle.

  python title_pair.py magari  "MAGARI"  "sunflower" titles/t1.png
  python title_pair.py airone  "AIRONE"  "Charli"    titles/t2.png [--accent-color 3B5E48]
  python title_pair.py tallica "TALLICA" "THINKER"   titles/t3.png [--preview frame.png]

BIG is the word he is stressing (upper-cased); ACCENT is the second word. Keep BIG to one short word (4-8 letters):
it is stretched to the frame width, so a long word gets thin and a short one gets tall.
In plan.py SEGMENTS:  dict(t=(a, b), kind="card", png="titles/t1.png", y=500, maxw=1080, maxh=1920)
(maxw=1080 matters: the card default of 1000 px would shrink a full-width title.)
--preview composites the title over a frame (or any 1080x1920 image) next to the PNG, to check it before a render.
"""
import argparse
import os

from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "..", "assets", "fonts", "title-pairs")
W = 1080


def font(name, size, **axes):
    f = ImageFont.truetype(os.path.join(FONTS, name), size)
    if axes:
        names = [a["name"].decode() if isinstance(a["name"], bytes) else a["name"] for a in f.get_variation_axes()]
        f.set_variation_by_axes([axes.get(n, a["default"]) for n, a in zip(names, f.get_variation_axes())])
    return f


def word(text, f, fill, stroke=0, tracking=0):
    """the word as a tight RGBA image (ink bounds only, so sizes are exact)"""
    pad = f.size
    if tracking:
        widths = [f.getlength(c) for c in text]
        total = int(sum(widths) + tracking * (len(text) - 1)) + 2 * pad
    else:
        total = int(f.getlength(text)) + 2 * pad
    im = Image.new("RGBA", (total, int(f.size * 2) + 2 * pad), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if tracking:
        x = pad
        for c, w in zip(text, widths):
            d.text((x, pad), c, font=f, fill=fill, stroke_width=stroke, stroke_fill=fill)
            x += w + tracking
    else:
        d.text((pad, pad), text, font=f, fill=fill, stroke_width=stroke, stroke_fill=fill)
    return im.crop(im.getbbox())


def fit(im, w=None, h=None):
    """scale to an exact width and/or height (non-uniform when both are given: that is how the condensing works)"""
    if w and h:
        return im.resize((int(w), int(h)), Image.LANCZOS)
    s = (w / im.width) if w else (h / im.height)
    return im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)


def shadow(im, alpha=0.30, blur=14, dy=6):
    """soft dark glow under the white type so it reads on light footage (the references sit on pale stone)"""
    a = im.split()[3].point(lambda v: int(v * alpha))
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    sh.putalpha(a)
    pad = blur * 3
    out = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad + dy), (0, 0, 0, 0))
    out.alpha_composite(sh, (pad, pad + dy))
    out = out.filter(ImageFilter.GaussianBlur(blur))     # blurred on the padded canvas so the glow is not clipped
    out.alpha_composite(im, (pad, pad))
    return out


def canvas(layers, height):
    """layers: (image, centre x, top y); returns a W-wide transparent canvas trimmed to the ink"""
    c = Image.new("RGBA", (W, height), (0, 0, 0, 0))
    for im, cx, top in layers:
        c.alpha_composite(im, (int(cx - im.width / 2), int(top)))
    return c


def magari(big, accent, color):
    # reference: accent ~31% of the frame wide, thin; big word ~92% wide with a cap height ~0.25 W (tall, condensed)
    acc = fit(word(accent.lower(), font("Quicksand.ttf", 200, Weight=300), "white"), w=W * 0.31)
    b = word(big.upper(), font("BodoniModa.ttf", 400, Weight=900, **{"Optical size": 6}), "white")
    b = fit(b, w=W * 0.92, h=W * 0.25)
    gap = W * 0.03
    return canvas([(acc, W / 2, 0), (b, W / 2, acc.height + gap)], int(acc.height + gap + b.height) + 2)


def airone(big, accent, color):
    # reference: big word ~92% wide, cap height ~0.15 W; script ~32% wide, deep green, its baseline just under the
    # big word and its body over the lower half, slightly left of centre
    b = fit(word(big.upper(), font("Unbounded.ttf", 300, Weight=900), "white"), w=W * 0.92)
    acc = word(accent, font("NothingYouCouldDo.ttf", 260), "#" + (color or "3B5E48"), stroke=5)
    acc = fit(acc, w=W * 0.38).rotate(4, resample=Image.BICUBIC, expand=True)
    top = b.height * 0.55
    return canvas([(b, W / 2, 0), (acc, W * 0.47, top)], int(max(b.height, top + acc.height)) + 2)


def tallica(big, accent, color):
    # reference: big word ~78% wide and very tall (cap height ~0.47 W); red pen caps ~70% wide across its middle,
    # a few degrees up to the right
    b = word(big.upper(), font("Antonio.ttf", 400, Weight=500), "white")
    b = fit(b, w=W * 0.78, h=W * 0.47)
    acc = word(accent.upper(), font("ShadowsIntoLight.ttf", 300), "#" + (color or "E3201B"), stroke=3)
    acc = fit(acc, w=W * 0.70).rotate(3, resample=Image.BICUBIC, expand=True)
    top = b.height * 0.5 - acc.height * 0.55
    return canvas([(b, W / 2, 0), (acc, W * 0.51, top)], int(b.height) + 2)


STYLES = {"magari": magari, "airone": airone, "tallica": tallica}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("style", choices=sorted(STYLES))
    ap.add_argument("big")
    ap.add_argument("accent")
    ap.add_argument("out")
    ap.add_argument("--accent-color", help="hex without #, e.g. E3201B")
    ap.add_argument("--no-shadow", action="store_true", help="plain type, as in the references (only on dark footage)")
    ap.add_argument("--preview", help="a 1080x1920 frame to composite onto; writes <out>.preview.png")
    ap.add_argument("--y", type=int, default=500, help="centre y used for --preview (the plan.py card y)")
    a = ap.parse_args()
    im = STYLES[a.style](a.big, a.accent, a.accent_color)
    if not a.no_shadow:
        im = shadow(im)
    # exactly W wide (centred), trimmed top and bottom: compose scales a card to maxw, so a full-width PNG at
    # maxw=1080 is drawn 1:1 and the title keeps the margins designed above
    l, t, r, b = im.getbbox()
    cx = im.width / 2
    im = im.crop((int(cx - W / 2), t, int(cx - W / 2) + W, b))
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    im.save(a.out)
    print(f"{a.out}: {im.width}x{im.height}")
    if a.preview:
        fr = Image.open(a.preview).convert("RGBA").resize((W, 1920))
        fr.alpha_composite(im, (int(W / 2 - im.width / 2), int(a.y - im.height / 2)))
        p = os.path.splitext(a.out)[0] + ".preview.png"
        fr.convert("RGB").save(p)
        print(f"preview: {p}")


if __name__ == "__main__":
    main()
