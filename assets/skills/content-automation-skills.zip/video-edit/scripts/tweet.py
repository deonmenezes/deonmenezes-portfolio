"""tweet.py - a real tweet as an image, without logging in (Twitter's public embed page).

    python vk.py tweet name_a=<tweet_id> name_b=<tweet_id> [--light]

Writes shots/<name>.png and prints the tweet's text so you can check it is the one you meant. Use the tweet that
says what HE is saying: a tweet by the right person about a neighbouring topic is the wrong reference.
(x.com itself needs a login; yt-dlp can still pull a tweet's video with x.com/<user>/status/<id>.)
"""
import os, sys

from playwright.sync_api import sync_playwright

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit  # noqa: F401  (utf-8 console)


def main():
    theme = "light" if "--light" in sys.argv else "dark"
    jobs = [a.split("=", 1) for a in sys.argv[1:] if "=" in a]
    if not jobs:
        print(__doc__)
        sys.exit(1)
    os.makedirs("shots", exist_ok=True)
    with sync_playwright() as pw:
        b = pw.chromium.launch(channel="chrome", headless=True)
        ctx = b.new_context(viewport={"width": 550, "height": 1400}, device_scale_factor=2.5, color_scheme=theme)
        for name, tid in jobs:
            pg = ctx.new_page()
            try:
                pg.goto(f"https://platform.twitter.com/embed/Tweet.html?id={tid}&theme={theme}&dnt=true&hideThread=false",
                        wait_until="networkidle", timeout=60000)
                pg.wait_for_timeout(2500)
                el = pg.query_selector("article")
                if el is None:
                    print(f"NOT FOUND {name} | tweet {tid} did not render (deleted, private, or a wrong id)")
                    continue
                el.screenshot(path=f"shots/{name}.png")
                text = el.inner_text()
                print("OK", name, "|", text[:300].replace("\n", " | "))
                if "Show more" in text:
                    print(f"   note: {name} is a long tweet and the embed cuts it at 'Show more'. If the words he quotes "
                          "are past the cut, they are not in this image.")
            except Exception as e:
                print("ERR", name, str(e)[:200])
            finally:
                pg.close()
        b.close()


if __name__ == "__main__":
    main()
