"""new_project.py - start an edit folder for one clip.

    python new_project.py "<source video>" <slug> [--root <your-folder>/]

Makes <your-folder>/<slug>-edit with:
  source.<ext>    hash-verified copy of the clip, keeping its extension (the original is never touched).
                  The tools find it through project.json, so commands never need its name.
  project.json    what the clip is (size, fps, HLG/SDR) and the output frame
  vo16.wav        16 kHz mono voice, for the envelope and the transcriber
  sheet.png       16 labelled frames: framing, face position, burned-in captions
  vk.py           runs any skill tool from here:  python vk.py <tool> ...
  plan.py, anim.html, captions.json, overlay.json, jobs.json, brief.md   templates to fill in
"""
import json, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import vkit

TEMPLATES = os.path.join(os.path.dirname(HERE), "templates")


def main():
    a = sys.argv[1:]
    root = "<your-folder>/"
    if "--root" in a:
        i = a.index("--root")
        root = a[i + 1]
        del a[i:i + 2]
    if len(a) != 2 or not os.path.exists(a[0]):
        print(__doc__)
        sys.exit(1)
    src, slug = a
    d = os.path.join(root, f"{slug}-edit").replace("\\", "/")
    if os.path.exists(os.path.join(d, "project.json")):
        raise SystemExit(f"{d} already holds a project. Pick another slug, or work in that folder.")
    os.makedirs(d, exist_ok=True)
    ext = os.path.splitext(src)[1].lower() or ".mp4"
    local = f"{d}/source{ext}"
    digest = vkit.copy_verified(src, local)
    info = vkit.probe(local)
    info["path"] = "source" + ext
    portrait = info["h"] >= info["w"]
    proj = {
        "slug": slug, "original": os.path.abspath(src).replace("\\", "/"), "sha256": digest, "source": info,
        "fps": 30 if info["fps"] >= 29.9 else max(int(round(info["fps"])), 1),
        "w": 1080 if portrait else 1920, "h": 1920 if portrait else 1080,
    }
    json.dump(proj, open(f"{d}/project.json", "w", encoding="utf-8"), indent=1)
    for name in os.listdir(TEMPLATES):
        if not os.path.exists(f"{d}/{name}"):
            shutil.copyfile(os.path.join(TEMPLATES, name), f"{d}/{name}")
    if info["audio"]:
        vkit.run(["ffmpeg", "-v", "error", "-y", "-i", local, "-vn", "-ac", "1", "-ar", "16000", f"{d}/vo16.wav"])
    n = 16
    vkit.sheet(local, f"{d}/sheet.png", [round((i + 0.5) * info["dur"] / n, 2) for i in range(n)], info["hdr"], cols=8)
    print(f"project: {d}")
    print(f"  source  {info['w']}x{info['h']} {info['fps']} fps {info['dur']} s  {info['hdr'].upper()}"
          f"{' + Dolby Vision' if info['dovi'] else ''}  audio: {'yes' if info['audio'] else 'NONE'}")
    print(f"  output  {proj['w']}x{proj['h']} at {proj['fps']} fps")
    if abs(info["w"] / info["h"] - proj["w"] / proj["h"]) > 0.02:
        print(f"  NOTE    the clip is {info['w']}x{info['h']}, not {'9:16' if portrait else '16:9'}: compose.py will "
              f"centre-crop it to fill {proj['w']}x{proj['h']}. Edit w/h in project.json if he wants another shape.")
    if info["audio"] and abs((info["a_start"] or 0) - info["v_start"]) > 0.02:
        print(f"  NOTE    sound and picture do not start together (video {info['v_start']} s, audio {info['a_start']} s). "
              "Remux the clip so both start at 0 before cutting, or the cut will shift them by that much.")
    if info["vfr"]:
        print("  NOTE    variable frame rate: in the overlay lane give card times in seconds, not frames.")
    print(f"  next    cd {d}  &&  python vk.py transcribe   then Read sheet.png and words.txt")


if __name__ == "__main__":
    main()
