"""transcribe.py - word-timed transcript with faster-whisper (CPU, int8, 4 threads: CUDA is broken on this PC).

    python vk.py transcribe                                   the project's source -> words.json, words.txt
    python transcribe.py <media> [-o words.json] [--model large-v3] [--lang en]

Writes words.json ([{"w","s","e"}, ...]) and a readable <name>.txt next to it, and prints the segments.

The words are right far more often than the TIMES are. A word that seems to last 1.5 s is a short word padded
across the silence after it, and word ends are often early. Cut points come from edl.py's envelope, never
from these numbers.
"""
import json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit


def transcribe(media, model="large-v3", lang="en"):
    from faster_whisper import WhisperModel
    m = WhisperModel(model, device="cpu", compute_type="int8", cpu_threads=4)
    # Two settings that were measured on his footage, not guessed:
    #   temperature 0, no fallback  -> the same audio always gives the same words, so a diff between two
    #                                  transcripts means the audio changed, not that the model rolled other dice
    #   condition_on_previous_text  -> keeps false starts verbatim ("if you want this, if you want the full...").
    #                                  With it off the model tidied that restart away and it could not be found.
    # No initial_prompt: a disfluent prompt made it invent words ("comment down below").
    segs, _ = m.transcribe(media, language=lang, word_timestamps=True, vad_filter=False,
                           condition_on_previous_text=True, temperature=0.0)
    words, lines = [], []
    for s in segs:
        lines.append(f"[{s.start:7.2f}-{s.end:7.2f}] {s.text.strip()}")
        for w in s.words:
            if w.word.strip():
                words.append({"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3)})
    return words, lines


def main():
    a = sys.argv[1:]
    opt = {}
    for k in ("-o", "--model", "--lang"):
        if k in a:
            i = a.index(k)
            opt[k] = a[i + 1]
            del a[i:i + 2]
    if not a and os.path.exists("project.json"):      # inside an edit folder: the project's own clip
        a = [vkit.project()["source"]["path"]]
    if not a or not os.path.exists(a[0]):
        print(__doc__)
        sys.exit(1)
    out = opt.get("-o", "words.json")
    with vkit.lane(f"transcribe {os.path.basename(a[0])}"):
        words, lines = transcribe(a[0], opt.get("--model", "large-v3"), opt.get("--lang", "en"))
    json.dump(words, open(out, "w", encoding="utf-8"), indent=0)
    txt = os.path.splitext(out)[0] + ".txt"
    with open(txt, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n\n" + " ".join(f"{w['w']}@{w['s']:.2f}" for w in words) + "\n")
    print("\n".join(lines))
    print(f"\n{len(words)} words -> {out}, readable copy -> {txt}")


if __name__ == "__main__":
    main()
