"""timemap - ORIGINAL (uncut) seconds -> NEW (cut) seconds, from cuts.json in the edit folder.

Everything a person or an agent writes down (plan.py segments, pop-ups, events, cuts) is in ORIGINAL seconds,
because that is what the transcript and the source file show. T() moves it onto the cut timeline at build time.
Without a cuts.json the map is the identity.

Cuts are made on whole frames, so anything that must line up with a splice is counted in frames: Tf() gives a
new-timeline time that sits exactly on a frame, and cut_frames() the frame numbers the splices fall on.
"""
import json, os

if os.path.exists("cuts.json"):
    _c = json.load(open("cuts.json"))
    FPS = _c.get("fps", 30)
    KEEP_F = [(round(a * FPS), round(b * FPS)) for a, b in _c["keep"]]      # kept pieces, in source frames
else:
    _p = json.load(open("project.json", encoding="utf-8"))
    FPS = _p.get("fps", 30)
    KEEP_F = [(0, round(_p["source"]["dur"] * FPS))]
KEEP = [(a / FPS, b / FPS) for a, b in KEEP_F]
CUTS, _t = [], 0
for _a, _b in KEEP_F:
    if _a > _t:
        CUTS.append((_t / FPS, _a / FPS))
    _t = _b
N_FRAMES = sum(b - a for a, b in KEEP_F)
NEW_DUR = N_FRAMES / FPS


def T(t):
    """original time -> new time; a time inside a removed stretch lands on the splice"""
    removed = 0.0
    for a, b in CUTS:
        if t >= b:
            removed += b - a
        elif t > a:
            return a - removed
    return t - removed


def Tf(t):
    """T(t) moved onto the frame it falls in: exactly k / FPS"""
    return min(max(round(T(t) * FPS), 0), N_FRAMES) / FPS


def cut_frames():
    """NEW-timeline frame numbers that are the first frame after a splice (not the head trim)"""
    out, n = [], 0
    for a, b in KEEP_F[:-1]:
        n += b - a
        out.append(n)
    return out
