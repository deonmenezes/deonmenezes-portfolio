"""cards.py - source cards from shots.py crops, and stroked-text cards.

    python vk.py cards                       build cards/<name>.png for every shots/<name>_h1.png (settings: cards.json)
    python vk.py cards bbc_steroids          only these
    python vk.py cards --text cta "COMMENT" "\u201cPROBLEM\u201d"     cards/cta.png: small line over big line, his text style

A source card = the outlet's masthead strip + the real headline + the highlighted sentence, stacked on a white
rounded card with a soft shadow, 940 px wide in a 1080 frame. Nothing on it is retyped: it is three crops of the
live page, so the outlet's own type and logo carry the credibility.

cards.json (optional), per name:
  {"bbc_steroids": {"mast": [0, 140],      rows of shots/<name>_top.png that hold the masthead (LOOK at the file:
                                           BBC is about 0-140, the Guardian 158-398, TechCrunch 250-455)
                    "h1": [0, 0],          pixels to trim off the top and bottom of the headline crop
                    "para": [6, 4]}}       the same for the paragraph crop
Sizes come out even on both sides, which the HLG overlay needs.
"""
import json, os, sys

from PIL import Image, ImageDraw, ImageFilter, ImageFont

S = "shots/"
W, R, PAD = 940, 30, 26          # card width in a 1080 frame, corner radius, transparent margin holding the shadow
FONT = "C:/Windows/Fonts/timesbd.ttf"


def fit(im):
    return im.resize((W, round(im.height * W / im.width)), Image.LANCZOS)


def card(name, c):
    parts = []
    if os.path.exists(f"{S}{name}_top.png"):
        top = Image.open(f"{S}{name}_top.png").convert("RGB")
        y0, y1 = c.get("mast", (0, 140))
        parts.append(fit(top.crop((0, y0, top.width, min(y1, top.height)))))
    h1 = Image.open(f"{S}{name}_h1.png").convert("RGB")
    a, b = c.get("h1", (0, 0))
    parts.append(fit(h1.crop((0, a, h1.width, h1.height - b))))
    if os.path.exists(f"{S}{name}_para.png"):
        p = Image.open(f"{S}{name}_para.png").convert("RGB")
        a, b = c.get("para", (0, 0))
        p = fit(p.crop((0, a, p.width, p.height - b)))
        parts += [p, Image.new("RGB", (W, 22), p.getpixel((4, p.height // 2)))]
    h = sum(p.height for p in parts)
    body = Image.new("RGB", (W, h), "white")
    y = 0
    for p in parts:
        body.paste(p, (0, y))
        y += p.height
    mask = Image.new("L", (W, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, W - 1, h - 1), R, fill=255)
    out = Image.new("RGBA", (W + 2 * PAD, h + 2 * PAD + h % 2), (0, 0, 0, 0))
    sh = Image.new("L", out.size, 0)
    ImageDraw.Draw(sh).rounded_rectangle((PAD, PAD + 8, PAD + W - 1, PAD + h + 7), R, fill=150)
    sh = sh.filter(ImageFilter.GaussianBlur(11))
    out.paste(Image.new("RGBA", out.size, (0, 0, 0, 255)), (0, 0), sh)
    out.paste(body, (PAD, PAD), mask)
    out.save(f"cards/{name}.png")
    print(f"cards/{name}.png  {out.size[0]}x{out.size[1]}   (Read it: masthead whole, headline uncut, highlight visible)")


def text_card(name, small, big):
    """small line over a big line: Times New Roman Bold, white, thick black stroke, soft shadow"""
    f1, f2 = ImageFont.truetype(FONT, 92), ImageFont.truetype(FONT, 150)
    while f2.getlength(big) > 1000 and f2.size > 60:
        f2 = ImageFont.truetype(FONT, f2.size - 6)
    im = Image.new("RGBA", (1080, 420), (0, 0, 0, 0))
    rows = ((small, f1, 96, 9), (big, f2, 250, 12))
    sh = Image.new("L", im.size, 0)
    ds = ImageDraw.Draw(sh)
    for txt, f, y, sw in rows:
        ds.text((540, y + 8), txt, font=f, anchor="mm", fill=170, stroke_width=sw, stroke_fill=170)
    sh = sh.filter(ImageFilter.GaussianBlur(9))
    im.paste(Image.new("RGBA", im.size, (0, 0, 0, 255)), (0, 0), sh)
    d = ImageDraw.Draw(im)
    for txt, f, y, sw in rows:
        d.text((540, y), txt, font=f, anchor="mm", fill="white", stroke_width=sw, stroke_fill="black")
    im.save(f"cards/{name}.png")
    print(f"cards/{name}.png  {im.size[0]}x{im.size[1]}")


def main():
    a = sys.argv[1:]
    os.makedirs("cards", exist_ok=True)
    if a[:1] == ["--text"]:
        if len(a) != 4:
            raise SystemExit('usage: cards --text <name> "SMALL LINE" "BIG LINE"')
        text_card(a[1], a[2], a[3])
        return
    cfg = json.load(open("cards.json", encoding="utf-8")) if os.path.exists("cards.json") else {}
    names = a or sorted(f[:-7] for f in os.listdir(S) if f.endswith("_h1.png")) if os.path.isdir(S) else []
    if not names:
        raise SystemExit("no shots/<name>_h1.png crops here: run `python vk.py shots jobs.json` first")
    jobs = {}
    if os.path.exists("jobs.json"):
        jobs = {j["name"]: j for j in json.load(open("jobs.json", encoding="utf-8"))}
    for n in names:
        if not os.path.exists(f"{S}{n}_h1.png"):
            print(f"SKIP {n}: no shots/{n}_h1.png (the page had no headline, or the shot failed)")
            continue
        if jobs.get(n, {}).get("rx") and not os.path.exists(f"{S}{n}_para.png"):
            print(f"SKIP {n}: jobs.json asks for a highlighted sentence and shots found none (NO MATCH). A card "
                  f"without the sentence would back the claim with a headline only. Fix the regex or drop the source.")
            continue
        card(n, cfg.get(n, {}))


if __name__ == "__main__":
    main()
