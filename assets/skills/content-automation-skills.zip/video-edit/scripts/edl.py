"""edl.py - the cut list for one edit. Run it from the edit folder.

    python vk.py edl pauses [--thr dB] [--min 0.14] [--keep 0.07] [--min-cut 0.12]   pauses on the envelope -> edl.txt
    python vk.py edl pauses --redo ...                              find them again, REPLACING the PAUSE rows
    python vk.py edl retakes [--keep 0.07]                          suggest fillers + restarted lines (prints only)
    python vk.py edl accept 1 2                                     take suggestions #1 and #2 into edl.txt
    python vk.py edl add 52.14 52.94 RETAKE said again in other words      add a row (or just edit edl.txt)
    python vk.py edl probe 54.44 54.82 [A B ...]                    what would it say if A-B were removed?
    python vk.py edl listen 49.70 51.20                             what is said in this window, heard on its own?
    python vk.py edl apply                                          edl.txt -> cuts.json, *.fc, vo16_cut.wav
    python vk.py edl verify                                         re-transcribe the cut, diff against the original

edl.txt is the one source of truth: one row per stretch to REMOVE, in ORIGINAL seconds, with the reason.
`pauses` writes only PAUSE rows and never touches the others. It refuses to run a second time without --redo,
because that puts back any PAUSE row you moved by hand. Rows are snapped inward to whole frames at `apply`.
`verify` also re-reads the cut for anything still said twice in a row, which is the real test of a retake cut.

Three rules this file exists to enforce:
  1. Cut points come from the RMS envelope, not from word timestamps or silencedetect. Unvoiced consonants
     (/s/ /t/ /k/ /h/) sit 20-30 dB under the vowels and look like silence to a gate, so every cut keeps a margin.
  2. When a line is said twice, the SECOND take stays.
  3. A cut is not done until the cut audio has been transcribed again and no word has gone missing.
"""
import json, math, os, re, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit

EDL = "edl.txt"
HEADER = ("# stretches to REMOVE, in ORIGINAL seconds:  start  end  KIND  why\n"
          "# KIND is free text; PAUSE rows are rewritten by `edl pauses`, everything else is kept as you wrote it.\n")
HOP = 0.005
FILLERS = {"um", "umm", "uh", "uhh", "uhm", "erm", "er", "ah", "hmm", "mm", "mhm"}
DOUBLES_OK = {"very", "really", "so", "no", "yeah", "that", "had", "bye", "ha", "go", "more", "many", "big", "long",
              "now", "is"}


NUMS = {w: str(i) for i, w in enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen "
    "seventeen eighteen nineteen twenty".split())}
NUMS.update(thirty="30", forty="40", fifty="50", sixty="60", seventy="70", eighty="80", ninety="90")


def norm(w):
    w = re.sub(r"[^a-z0-9]", "", w.lower())
    return NUMS.get(w, w)                         # "Eleven" and "11" are the same spoken word


def media():
    return "vo16.wav" if os.path.exists("vo16.wav") else vkit.project()["source"]["path"]


def load():
    rows = []
    if os.path.exists(EDL):
        for ln in open(EDL, encoding="utf-8"):
            s = ln.strip()
            if not s or s.startswith("#"):
                continue
            p = s.split(None, 3)
            try:
                rows.append((float(p[0]), float(p[1]), p[2].upper(), p[3] if len(p) > 3 else ""))
            except (ValueError, IndexError):
                raise SystemExit(f"{EDL}: cannot read the row {s!r}. A row is:  start  end  KIND  why")
    return sorted(rows)


def save(rows):
    with open(EDL, "w", encoding="utf-8") as f:
        f.write(HEADER)
        for a, b, k, why in sorted(rows):
            f.write(f"{a:9.3f} {b:9.3f}  {k:<7} {why}\n")


def quiet_runs(env, thr, min_len=0.0):
    """[(start_s, end_s)] of stretches under the threshold"""
    q = np.concatenate([[0], (env < thr).astype(np.int8), [0]])
    d = np.diff(q)
    out = []
    for i, j in zip(np.where(d == 1)[0], np.where(d == -1)[0]):
        a, b = i * HOP, j * HOP + 0.020
        if b - a >= min_len:
            out.append((a, b))
    return out


def opt(a, name, default):
    if name in a:
        i = a.index(name)
        v = float(a[i + 1])
        del a[i:i + 2]
        return v
    return default


# ---------- pauses ----------
def find_pauses(env, dur, thr, min_pause, keep, min_cut=0.12):
    merged = []
    for a, b in quiet_runs(env, thr, min_pause):  # only real pauses are joined: a 40 ms click or breath between
        if merged and a - merged[-1][1] < 0.06:   # two of them is still one pause, a consonant burst between two
            merged[-1] = (merged[-1][0], b)       # short dips is not
        else:
            merged.append((a, b))
    rows = []
    for a, b in merged:
        if a < 0.05:
            ca, cb, why = 0.0, b - keep, "lead-in"
        elif b > dur - 0.05:
            ca, cb, why = a + 0.30, dur, "tail"
        else:
            ca, cb, why = a + keep, b - keep, f"{b - a:.2f}s pause"
        if cb - ca >= (0.05 if why in ("lead-in", "tail") else min_cut):   # a 60 ms trim is a jump cut for nothing
            rows.append((round(ca, 3), round(cb, 3), "PAUSE", why))
    return rows


def cmd_pauses(a):
    redo = "--redo" in a
    if redo:
        a.remove("--redo")
    if any(r[2] == "PAUSE" for r in load()) and not redo:
        raise SystemExit(f"{EDL} already has PAUSE rows. `edl pauses --redo` finds them again from scratch and "
                         "REPLACES them: any PAUSE row you moved by hand goes back to where the tool puts it.")
    env, dur = vkit.envelope(media())
    auto, floor, peak = vkit.speech_threshold(env)
    thr, min_pause, keep = opt(a, "--thr", auto), opt(a, "--min", 0.14), opt(a, "--keep", 0.07)
    rows = find_pauses(env, dur, thr, min_pause, keep, opt(a, "--min-cut", 0.12))
    mine = [r for r in load() if r[2] != "PAUSE"]
    save(mine + rows)
    removed = sum(b - a_ for a_, b, *_ in rows)
    print(f"floor {floor:.1f} dB  speech {peak:.1f} dB  threshold {thr:.1f} dB  duration {dur:.2f} s")
    for a_, b, _, why in rows:
        print(f"  PAUSE {a_:8.2f} -> {b:8.2f}  {b - a_:5.2f}s  {why}")
    print(f"{len(rows)} pauses, {removed:.2f} s. {len(mine)} other rows kept. -> {EDL}")
    print("Each pause keeps %.2f s on both sides. Next: `edl retakes`, then `edl apply`, then `edl verify`." % keep)


# ---------- fillers and retakes ----------
def run_before(runs, t, back=0.30, fwd=0.08):
    """the pause that ends closest to a word onset at t"""
    c = [r for r in runs if t - back <= r[1] <= t + fwd]
    return min(c, key=lambda r: abs(r[1] - t)) if c else None


def run_after(runs, t, back=0.10, fwd=0.30):
    c = [r for r in runs if t - back <= r[0] <= t + fwd]
    return min(c, key=lambda r: abs(r[0] - t)) if c else None


def find_repeats(words):
    """[(i, j, n)]: the n words starting at i are said again starting at j (a restart), longest match first.
    n == 1 is a doubled word. Used on the original words to suggest cuts, and on the cut to prove they worked."""
    N = [norm(w["w"]) for w in words]
    out, i = [], 0
    while i < len(N):
        best = None
        for j in range(i + 1, min(i + 16, len(N))):
            if words[j]["s"] - words[i]["s"] > 15:
                break
            n = 0
            while i + n < j and j + n < len(N) and N[i + n] and N[i + n] == N[j + n]:
                n += 1
            if (n >= 3 or (n == 2 and j == i + 2)) and (best is None or n > best[1]):
                best = (j, n)
        if best is None and i + 1 < len(N) and N[i] and N[i] == N[i + 1] and N[i] not in DOUBLES_OK \
                and N[i] not in FILLERS:
            best = (i + 1, 1)
        if best:
            out.append((i, best[0], best[1]))
            i = best[0]
        else:
            i += 1
    return out


def onset_pause(runs, w):
    """The pause that sits in front of where word w is really spoken, or None.
    Two shapes are trusted, and a pause that only FOLLOWS the word is never taken:
      stretched  the pause lies inside the word's own span and ends where the span ends. The transcriber
                 stretches the first word of a phrase back over the silence before it (a "the" timed 24.64-26.40
                 that is really said at 26.4).
      plain      the pause ends where the word starts.
    """
    s, e = w["s"], w["e"]
    stretched = [r for r in runs if r[0] >= s - 0.05 and r[0] < e - 0.08 and abs(r[1] - e) <= 0.15]
    if stretched:
        return max(stretched, key=lambda r: r[1])
    plain = [r for r in runs if abs(r[1] - s) <= 0.12]
    return min(plain, key=lambda r: abs(r[1] - s)) if plain else None


def cmd_retakes(a):
    words = json.load(open("words.json", encoding="utf-8"))
    env, dur = vkit.envelope(media())
    thr, _, _ = vkit.speech_threshold(env)
    keep = opt(a, "--keep", 0.07)
    runs = quiet_runs(env, thr, 0.08)
    N = [norm(w["w"]) for w in words]
    found = []

    def ctx(i, j):
        return " ".join(w["w"] for w in words[max(i - 4, 0):min(j + 6, len(words))])

    def edge_in(i):          # start removing here: just inside the pause in front of the first take
        r = onset_pause(runs, words[i])
        return (round(r[0] + min(keep, (r[1] - r[0]) / 2), 3), r[1] - r[0]) if r else (words[i]["s"], 0.0)

    def edge_out(j):         # stop removing here: just before the kept take really starts
        r = onset_pause(runs, words[j])
        return (round(r[1] - min(keep, (r[1] - r[0]) / 2), 3), r[1] - r[0]) if r else (words[j]["s"], 0.0)

    for i, w in enumerate(words):
        if N[i] in FILLERS:
            s, e = w["s"], min(w["e"], w["s"] + 0.6)
            rb, ra = run_before(runs, s), run_after(runs, e)
            ca = round(rb[0] + min(keep, (rb[1] - rb[0]) / 2), 3) if rb else s
            cb = round(ra[1] - min(keep, (ra[1] - ra[0]) / 2), 3) if ra else e
            island = bool(rb and ra and rb[1] - rb[0] >= 0.2 and ra[1] - ra[0] >= 0.2)
            found.append(dict(kind="FILLER", a=ca, b=cb, why=f'"{w["w"]}"', ctx=ctx(i, i + 1),
                              note="island: silence on both sides" if island else
                              "IN FLOW (no silence on both sides): probably not a hanging filler, probe first"))
    for i, j, n in find_repeats(words):
        (ca, pa), (cb, pb) = edge_in(i), edge_out(j)
        phrase = " ".join(w["w"] for w in words[i:i + n])
        tight = [x for x, p in (("start", pa), ("end", pb)) if p == 0.0]
        found.append(dict(kind="RETAKE" if n > 1 else "STUTTER", a=ca, b=cb,
                          why=f'first take of "{phrase}" (second kept)', ctx=ctx(i, j + n),
                          note=("no clear pause at the " + " and ".join(tight) + ": that edge is a word time, which is "
                                "not safe to cut on. Find the pause by hand or probe it") if tight
                          else "both edges sit in a pause. `edl verify` will show whether the repeat is gone"))
    found.sort(key=lambda f: f["a"])
    unplaced = [f for f in found if f["b"] - f["a"] < 0.08]
    found = [f for f in found if f["b"] - f["a"] >= 0.08]
    json.dump(found, open("retakes.json", "w", encoding="utf-8"), indent=1)
    for f in unplaced:
        print(f"\n  {f['kind']} found but NOT placed: {f['why']}\n          heard: ... {f['ctx']} ...\n"
              f"          both edges fell in the same pause near {f['a']:.2f}. Find the first take in words.txt and "
              f"add the row by hand.")
    loud = env >= thr
    for w in words:                                  # a word that "lasts" over a second with speech inside it
        if w["e"] - w["s"] > 1.0:
            spoken = float(loud[int(w["s"] / HOP):int(w["e"] / HOP)].sum()) * HOP
            if spoken > 0.7:
                print(f"\n  HIDDEN? [{w['w']}] is timed {w['s']:.2f}-{w['e']:.2f} but {spoken:.2f} s of that is speech: the "
                      f"transcriber may have skipped a false start.\n          hear it alone:  python vk.py edl listen "
                      f"{w['s']:.2f} {w['e']:.2f}")
    if not found:
        print("no fillers or repeated openings found by word match.")
    for k, f in enumerate(found, 1):
        print(f"\n  #{k} {f['kind']:<7} {f['a']:8.3f} -> {f['b']:8.3f}  {f['b'] - f['a']:5.2f}s  {f['why']}")
        print(f"          heard: ... {f['ctx']} ...")
        print(f"          {f['note']}")
    print("\nThese are SUGGESTIONS from matching words. Nothing was added to edl.txt.")
    print("Take the ones that are right with:  python vk.py edl accept 1 2 ...")
    print("Still yours to find by reading words.txt: a line re-said in different words, a false start that")
    print("shares fewer than three words, and anything Deon said to drop. Probe every edge that is not in a pause.")


def cmd_add(a):
    if len(a) < 3:
        raise SystemExit("usage: edl add START END KIND why...")
    s, e = float(a[0]), float(a[1])
    if e <= s:
        raise SystemExit("END must be after START")
    rows = load() + [(round(s, 3), round(e, 3), a[2].upper(), " ".join(a[3:]))]
    save(rows)
    print(f"added {s} -> {e} {a[2].upper()}. {len(rows)} rows in {EDL}. Run `edl apply`.")


def cmd_accept(a):
    found = json.load(open("retakes.json", encoding="utf-8"))
    rows = load()
    for k in a:
        if not k.lstrip("#").isdigit() or not 1 <= int(k.lstrip("#")) <= len(found):
            raise SystemExit(f"no suggestion {k}: `edl retakes` listed #1 to #{len(found)}")
        f = found[int(k.lstrip("#")) - 1]
        row = (f["a"], f["b"], f["kind"], f["why"])
        if row not in rows:
            rows.append(row)
        print(f"  + {f['a']:8.3f} -> {f['b']:8.3f}  {f['kind']}  {f['why']}")
    save(rows)
    print(f"{len(rows)} rows in {EDL}. Run `edl apply`.")


# ---------- apply ----------
def cut_frames(rows, dur, fps):
    """rows -> merged [first, last+1] frame ranges to remove. Edges are rounded INWARD (a cut only ever gets
    shorter), so the margin each row left around speech is never eaten by the frame grid."""
    total = round(dur * fps)
    out = []
    for a, b, *_ in sorted(rows):
        fa = 0 if a <= 1e-3 else min(math.ceil(a * fps - 1e-6), total)
        fb = total if b >= dur - 1e-3 else max(math.floor(b * fps + 1e-6), 0)
        if fb <= fa:
            continue
        if out and fa <= out[-1][1]:
            out[-1][1] = max(fb, out[-1][1])
        else:
            out.append([fa, fb])
    return out, total


def keep_frames(cuts, total, min_keep):
    """the kept pieces between the cuts; a piece shorter than min_keep frames is a flash and is dropped"""
    keep, slivers, t = [], [], 0
    for fa, fb in cuts + [[total, total]]:
        if fa - t >= min_keep:
            keep.append((t, fa))
        elif fa > t:
            slivers.append((t, fa))
        t = max(t, fb)
    return keep, slivers


def cmd_apply(a):
    p = vkit.project()
    src, dur, fps = p["source"]["path"], p["source"]["dur"], p["fps"]
    if p["source"]["audio"] is None:
        raise SystemExit("the source has no audio: nothing to cut on")
    sr = p["source"]["audio"]["sr"]
    rows = load()
    cuts, total = cut_frames(rows, dur, fps)
    keep, slivers = keep_frames(cuts, total, max(round(0.1 * fps), 2))
    if not keep:
        raise SystemExit("the cut list removes everything")
    for fa, fb in slivers:
        print(f"  note: {(fb - fa) / fps:.3f} s left between two cuts at {fa / fps:.2f} was dropped (a flash, not a shot)")
    real, t = [], 0                                  # the cuts as they will really happen (slivers folded in)
    for ka, kb in keep:
        if ka > t:
            real.append((t, ka))
        t = kb
    if total > t:
        real.append((t, total))
    sec = lambda f: round(f / fps, 4)
    json.dump({"keep": [[sec(x), sec(y)] for x, y in keep], "cuts": [[sec(x), sec(y)] for x, y in real],
               "dur": dur, "fps": fps, "edl": vkit.file_id(EDL)}, open("cuts.json", "w"))

    n = len(keep)
    v = f"[0:v]fps={fps},split={n}" + "".join(f"[s{i}]" for i in range(n)) + ";"
    v += ";".join(f"[s{i}]trim=start_frame={ka}:end_frame={kb},setpts=PTS-STARTPTS[v{i}]" for i, (ka, kb) in enumerate(keep))
    # fps again after concat: concat leaves the frame rate undeclared, and an output that does not know its rate
    # falls back to 25 fps and silently drops one frame in six
    v += ";" + "".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0,fps={fps}[vc]"
    open("video_cut.fc", "w").write(v)
    parts = []
    for i, (ka, kb) in enumerate(keep):              # audio is cut on the samples that match those frames
        f = f"[0:a]atrim=start_sample={round(ka * sr / fps)}:end_sample={round(kb * sr / fps)},asetpts=N/SR/TB"
        if i:
            f += ",afade=t=in:d=0.008"
        if i < n - 1:
            f += f",afade=t=out:st={round((kb - ka) / fps - 0.008, 4)}:d=0.008"
        parts.append(f + f"[a{i}]")
    open("voice_cut.fc", "w").write(";".join(parts) + ";" + "".join(f"[a{i}]" for i in range(n)) +
                                    f"concat=n={n}:v=0:a=1[voc]")
    vkit.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-/filter_complex", "voice_cut.fc", "-map", "[voc]",
              "-ac", "1", "-ar", "16000", "vo16_cut.wav"])
    removed = sum(y - x for x, y in real) / fps
    kinds = {}
    for _, _, k, _ in rows:
        kinds[k] = kinds.get(k, 0) + 1
    print(f"{len(rows)} rows ({', '.join(f'{c} {k}' for k, c in sorted(kinds.items())) or 'none'}) -> "
          f"{len(real)} cuts, {n} kept pieces")
    print(f"{dur:.2f} s in, {removed:.2f} s removed, {dur - removed:.2f} s out ({removed / dur * 100:.1f}% shorter)")
    print("wrote cuts.json, video_cut.fc, voice_cut.fc, vo16_cut.wav. Next: `edl verify` (required).")
    print("Captions, the mix, animation frames and any render made before this are now out of date.")


# ---------- verify ----------
def classify(orig, rows):
    """keep / cut / edge for every original word. Only non-PAUSE rows are MEANT to remove words.
      cut   the word's span lies inside a removed take
      edge  half inside, or a stretched word (over 0.6 s) that touches a removed take: its times cannot say which
            side of the splice it is on, so it may be in the cut or not
      keep  everything else, including a normal-length word that only brushes a removed take: if that one goes
            missing, the cut clipped it
    When this guesses wrong it errs toward a visible EXTRA or LOST line, never toward silence."""
    out = []
    for w in orig:
        s, e = w["s"], max(w["e"], w["s"] + 0.02)
        f = 0.0
        for a, b, kind, _ in rows:
            if kind != "PAUSE":
                f += max(min(e, b) - max(s, a), 0.0) / (e - s)
        if f <= 0.1:
            out.append("keep")
        elif f >= 0.9:
            out.append("cut")
        else:
            out.append("edge" if f >= 0.5 or e - s > 0.6 else "keep")
    return out


def align(A, optional, B):
    """Edit-distance alignment where dropping an optional (edge) word is nearly free.
    Returns ops: ("eq"|"sub", i, j), ("del", i, None), ("ins", None, j)."""
    n, m = len(A), len(B)
    INF = 1e9
    cost = [[INF] * (m + 1) for _ in range(n + 1)]
    back = [[None] * (m + 1) for _ in range(n + 1)]
    cost[0][0] = 0.0
    for i in range(n + 1):
        ci = cost[i]
        for j in range(m + 1):
            c = ci[j]
            if c >= INF:
                continue
            if i < n:
                d = c + (0.01 if optional[i] else 1.0)
                if d < cost[i + 1][j]:
                    cost[i + 1][j], back[i + 1][j] = d, "del"
            if j < m:
                d = c + 1.0
                if d < ci[j + 1]:
                    ci[j + 1], back[i][j + 1] = d, "ins"
            if i < n and j < m:
                d = c + (0.0 if A[i] == B[j] else 1.0)
                if d < cost[i + 1][j + 1]:
                    cost[i + 1][j + 1], back[i + 1][j + 1] = d, "eq" if A[i] == B[j] else "sub"
    ops, i, j = [], n, m
    while i or j:
        op = back[i][j]
        if op == "del":
            i -= 1
            ops.append(("del", i, None))
        elif op == "ins":
            j -= 1
            ops.append(("ins", None, j))
        else:
            i, j = i - 1, j - 1
            ops.append((op, i, j))
    return ops[::-1]


def cmd_verify(a):
    from transcribe import transcribe
    if not os.path.exists("vo16_cut.wav") or not os.path.exists("cuts.json"):
        raise SystemExit("run `edl apply` first")
    vkit.need_applied()
    orig = json.load(open("words.json", encoding="utf-8"))
    if not orig:
        raise SystemExit("words.json is empty: there is no speech to verify against")
    cuts = [tuple(x) for x in json.load(open("cuts.json"))["cuts"]]
    fresh = os.path.exists("words_cut.json") and vkit.stamps().get("words_cut") == vkit.cut_id()
    if fresh and "--again" not in a:
        new = json.load(open("words_cut.json", encoding="utf-8"))      # this exact cut was already transcribed
    else:
        with vkit.lane("edl verify (transcribe the cut)"):
            new, lines = transcribe("vo16_cut.wav")
        json.dump(new, open("words_cut.json", "w", encoding="utf-8"), indent=0)
        open("words_cut.txt", "w", encoding="utf-8").write(
            "\n".join(lines) + "\n\n" + " ".join(f"{w['w']}@{w['s']:.2f}" for w in new) + "\n")
        vkit.stamp("words_cut", vkit.cut_id())

    rows = load()
    state = classify(orig, rows)
    exp = [(w, st) for w, st in zip(orig, state) if st != "cut"]
    A, B = [norm(w["w"]) for w, _ in exp], [norm(w["w"]) for w in new]
    edges = [x for cut in cuts for x in cut]

    def at_splice(w):
        """does any cut edge fall inside this word's span, or within 0.45 s of it?"""
        return any(w["s"] - 0.45 <= e <= w["e"] + 0.45 for e in edges)

    def where(w):
        return "AT A SPLICE: likely clipped" if at_splice(w) else "nowhere near a splice"

    def new_time(t):
        return t - sum(min(b, t) - a for a, b in cuts if a < t)

    print("What is heard across each removed take (|| is the splice). Read every line:")
    for a, b, kind, why in rows:
        if kind == "PAUSE":
            continue
        x = new_time(a)
        before = " ".join(w["w"] for w in [w for w in new if (w["s"] + w["e"]) / 2 < x][-5:])
        after = " ".join(w["w"] for w in [w for w in new if (w["s"] + w["e"]) / 2 >= x][:6])
        print(f"  {a:7.2f}-{b:7.2f} {kind:<7} ... {before} || {after} ...")
    print()

    issues, elsewhere, last = 0, 0, orig[0]
    for op, i, j in align(A, [st == "edge" for _, st in exp], B):
        if i is not None:
            last = exp[i][0]
        if op == "eq" or (op == "del" and exp[i][1] == "edge"):
            continue
        if op in ("del", "sub") and not at_splice(exp[i][0]):
            # A cut changes no sample away from its splices, so a different word here is the transcriber hearing
            # the same audio differently in a new context. Shown, not counted.
            elsewhere += 1
            now = f"heard as [{new[j]['w']}]" if op == "sub" else "not heard"
            print(f"  note    {exp[i][0]['s']:7.2f}  [{exp[i][0]['w']}] is {now} in the cut, nowhere near a splice: the "
                  f"audio there is untouched, so this is the transcriber")
            continue
        issues += 1
        if op == "del":
            print(f"  LOST    {exp[i][0]['s']:7.2f}  [{exp[i][0]['w']}] should be in the cut and is not.  {where(exp[i][0])}")
        elif op == "sub":
            print(f"  CHANGED {exp[i][0]['s']:7.2f}  [{exp[i][0]['w']}] is now heard as [{new[j]['w']}].  {where(exp[i][0])}")
        else:
            print(f"  EXTRA   {new[j]['s']:7.2f} (cut time)  [{new[j]['w']}] is in the cut and was not expected: a word "
                  f"from a removed take survived, or the transcriber made it up (after [{last['w']}] at {last['s']:.2f})")
    # The direct test of a retake cut: nothing may still be said twice in a row. This reads the cut itself, so it
    # holds even when the word times that placed the cut were wrong.
    for i, j, n in find_repeats(new):
        issues += 1
        phrase = " ".join(w["w"] for w in new[i:i + n])
        print(f"  REPEAT  {new[i]['s']:7.2f} (cut time)  [{phrase}] is still said twice in a row in the cut "
              f"(again at {new[j]['s']:.2f}): the first take was not removed, or he means the repeat")
    for w in new:
        if norm(w["w"]) in FILLERS:
            print(f"  note    {w['s']:7.2f} (cut time)  filler [{w['w']}] is still in the cut")
    print(f"\n{len(new)} words heard in the cut, {issues} problems at splices, {elsewhere} transcriber differences "
          f"elsewhere. -> words_cut.json, words_cut.txt")
    if issues:
        print("Fix each problem: move that edge outward into the pause, `edl apply`, verify again. If you think one is")
        print("the transcriber after all, show it with `edl probe`: a word that was never in the audio is not a loss.")
        sys.exit(1)
    print("OK: every word that should be in the cut is there, and nothing from a removed take is left.")
    if elsewhere:
        print("The notes above are mishearings: fix those words for the captions in captions.json (`fix`).")


# ---------- probe ----------
def cmd_probe(a):
    from transcribe import transcribe            # noqa: F401  (checks the import before the model loads)
    from faster_whisper import WhisperModel
    nums = [float(x) for x in a]
    if not nums or len(nums) % 2:
        raise SystemExit("usage: edl probe START END [START END ...]")
    src = media()
    _, dur = vkit.envelope(src)
    with vkit.lane("edl probe"):
        m = WhisperModel("large-v3", device="cpu", compute_type="int8", cpu_threads=4)
        for s, e in zip(nums[0::2], nums[1::2]):
            lo, hi = max(s - 4, 0), min(e + 4, dur)
            vkit.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-filter_complex",
                      f"[0:a]atrim={lo}:{s},asetpts=N/SR/TB[x];[0:a]atrim={e}:{hi},asetpts=N/SR/TB[y];"
                      f"[x][y]concat=n=2:v=0:a=1", "-ac", "1", "-ar", "16000", "_probe.wav"])
            segs, _ = m.transcribe("_probe.wav", language="en", condition_on_previous_text=False)
            print(f"  remove {s:.2f}-{e:.2f}  ->  {' '.join(x.text.strip() for x in segs)}")
    os.remove("_probe.wav")
    print("A short window can invent small connecting words. A word that survives every possible cut was never there.")


def cmd_listen(a):
    """transcribe one window of the ORIGINAL audio on its own"""
    from faster_whisper import WhisperModel
    if len(a) != 2:
        raise SystemExit("usage: edl listen START END")
    s, e = max(float(a[0]) - 0.3, 0), float(a[1]) + 0.3
    vkit.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{s}", "-t", f"{e - s}", "-i", media(), "-ac", "1", "-ar", "16000",
              "_listen.wav"])
    with vkit.lane("edl listen"):
        m = WhisperModel("large-v3", device="cpu", compute_type="int8", cpu_threads=4)
        segs, _ = m.transcribe("_listen.wav", language="en", word_timestamps=True, condition_on_previous_text=False,
                               temperature=0.0)
        print(f"  {s:.2f}-{e:.2f}: " + " ".join(f"{w.word.strip()}@{s + w.start:.2f}" for x in segs for w in x.words))
    os.remove("_listen.wav")
    print("A window this short can invent a small connecting word. Treat it as a hint and confirm with `edl probe`.")


def main():
    a = sys.argv[1:]
    cmds = {"pauses": cmd_pauses, "retakes": cmd_retakes, "add": cmd_add, "accept": cmd_accept, "listen": cmd_listen, "apply": cmd_apply, "verify": cmd_verify,
            "probe": cmd_probe}
    if not a or a[0] not in cmds:
        print(__doc__)
        sys.exit(1)
    cmds[a[0]](a[1:])


if __name__ == "__main__":
    main()
