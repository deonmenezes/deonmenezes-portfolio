"""captions.py - words -> captions.ass: 2-3 word pop-in captions plus the big keyword pop-ups from plan.py.

    python vk.py captions            reads words_cut.json (or words.json when nothing was cut) and captions.json
    python vk.py captions --none     pop-ups only (the source already has captions burned in)

The look Deon approved: Times New Roman Bold, white, thick black stroke, soft shadow, a quick spring-in.
Captions sit on his chest (y=1390 of 1920). While the screen is split they move up to just under the seam, and a
caption ends when the split opens or closes rather than hanging across it. Pop-ups go upper-middle (y=680), never
at the very top. The punctuation at the end of each caption is dropped.

It refuses to run on a stale cut: after `edl apply` it wants `edl verify` first, so the words match the audio.

captions.json (all optional):
  accent        words shown in the accent colour (lower case)
  accent_color  RRGGBB
  follow        true (yellow FFE600) or "RRGGBB": follow-along captions. The word he is saying takes this colour and
                the rest of the caption stays white; accent words are not coloured. Asked for on 2026-10-09.
  pairs        [["every","single"], ...] words that must stay in the same caption
  fix           {"bagged": "banger"} what the transcriber gets wrong -> what he said (matched on the bare word)
  join          [["11","labs","ElevenLabs"]] two heard words that are one written word
  skip          [[0, 1.87]] ORIGINAL-second spans with no captions (e.g. the hook, shown as a pop-up instead)
  retime        [[8.92, 8.74]] a word whose stamped start is wrong: [start as the caption list prints it, the second
                he really starts it], both on the CUT timeline. For what QC measures and the onset fix cannot see.
  y, y_split, size, pop_size, pop_y, max_words, max_chars
"""
import json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import ImageFont

import planlib
import vkit
from planlib import W, H
from timemap import T

FONT_FILE = "C:/Windows/Fonts/timesbd.ttf"
cfg = json.load(open("captions.json", encoding="utf-8")) if os.path.exists("captions.json") else {}
S = H / 1920                                   # everything below is written for a 1920-tall frame
Y_FULL = cfg.get("y", round(1390 * S))
Y_SPLIT = cfg.get("y_split", planlib.PANEL_H + round(85 * S))
SIZE, POP_SIZE = cfg.get("size", round(104 * S)), cfg.get("pop_size", round(112 * S))
POP_Y = cfg.get("pop_y", round(680 * S))
MAX_WORDS, MAX_CHARS = cfg.get("max_words", 3), cfg.get("max_chars", 14)
ACCENT = {a.lower() for a in cfg.get("accent", [])}
PAIRS = {(a.lower(), b.lower()) for a, b in cfg.get("pairs", [])}
FIX = {k.lower(): v for k, v in cfg.get("fix", {}).items()}
JOIN = [(a.lower(), b.lower(), c) for a, b, c in cfg.get("join", [])]
SKIP = [(T(a), T(b)) for a, b in cfg.get("skip", [])]
RETIME = [(float(a), float(b)) for a, b in cfg.get("retime", [])]
FIXED = set()                                  # starts set by hand: the onset fix leaves these alone
rgb = cfg.get("accent_color", "F26522")
ACC = r"{\c&H" + rgb[4:6] + rgb[2:4] + rgb[0:2] + "&}"
WHITE = r"{\c&HFFFFFF&}"
FOLLOW = cfg.get("follow")                     # follow-along: the word being spoken takes this colour
if FOLLOW is True:
    FOLLOW = "FFE600"
HI = (r"\c&H" + FOLLOW[4:6] + FOLLOW[2:4] + FOLLOW[0:2] + "&") if FOLLOW else ""
SPANS = planlib.split_spans()
EDGES = [x for a, b in SPANS for x in (a, b)]
MAXW = W - 180


def bare(w):
    return re.sub(r"^\W+|\W+$", "", w).lower()


def cap_y(t):
    return Y_SPLIT if any(a - 0.03 <= t < b - 0.03 for a, b in SPANS) else Y_FULL


def crosses(t0, t1):
    return any(t0 < x - 0.03 <= t1 for x in EDGES)


def ts(t):
    t = max(t, 0)
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"


def load_words():
    src = "words_cut.json" if os.path.exists("cuts.json") else "words.json"
    if src == "words_cut.json" and (not os.path.exists(src) or vkit.stamps().get("words_cut") != vkit.cut_id()):
        raise SystemExit("words_cut.json is missing or is from an earlier cut: run `python vk.py edl verify` first. "
                         "Captions are built from the words of the CUT audio as it is now, or words from removed "
                         "takes end up on screen and everything after a new cut is late.")
    if not os.path.exists(src):
        raise SystemExit("no words.json here: run `python vk.py transcribe <source>` first "
                         "(or `captions --none` for pop-ups only)")
    raw = json.load(open(src, encoding="utf-8"))
    out, i = [], 0
    while i < len(raw):
        w, s, e = raw[i]["w"].strip(), raw[i]["s"], raw[i]["e"]
        nxt = raw[i + 1] if i + 1 < len(raw) else None
        hit = next((c for a, b, c in JOIN if nxt and bare(w) == a and bare(nxt["w"]) == b), None)
        if hit:
            tail = re.search(r"\W+$", nxt["w"])
            w, e, i = hit + (tail.group(0) if tail else ""), nxt["e"], i + 1
        elif bare(w) in FIX:
            m = re.match(r"^(\W*)(.*?)(\W*)$", w)
            w = m.group(1) + FIX[bare(w)] + m.group(3)
        i += 1
        if any(a <= s < b for a, b in SKIP):
            continue
        new = next((b for a, b in RETIME if abs(s - a) < 0.03), None)
        if new is not None:
            s, e = new, max(e, new + 0.05)
            FIXED.add(s)
        out.append((w, s, e))
    return out


def chunk(words):
    font = ImageFont.truetype(FONT_FILE, SIZE)

    def width(c):
        return font.getlength(" ".join(x[0].rstrip(".,!?") for x in c)) + 30

    def paired(a, b):
        return (bare(a), bare(b)) in PAIRS

    chunks, cur = [], []
    for i, (w, s, e) in enumerate(words):
        cur.append((w, s, e))
        text = " ".join(x[0] for x in cur)
        nxt = words[i + 1] if i + 1 < len(words) else None
        stop = bool(re.search(r"[.,?!]$", w) or len(cur) >= MAX_WORDS or len(text) >= MAX_CHARS
                    or nxt is None or nxt[1] - e > 0.35)
        if nxt and paired(w, nxt[0]):
            stop = False
        # The first word after a pause is stamped from the end of the word before it, so its stamp can sit before a
        # split edge that the voice is already past; judge it by where it is really said (near its stamped end), or
        # "It" / "For" / "10" break off into 1-frame stubs at every split (QC 2026-10-16, <your-folder>/oct16-edit).
        if nxt and crosses(max(cur[0][1], cur[0][2] - 0.05), nxt[1]):
            stop = True
        if stop:
            chunks.append(cur)
            cur = []
    fixed = []
    for c in chunks:
        while width(c) > MAXW and len(c) > 1:
            cut = len(c) - 1
            while cut > 1 and width(c[:cut]) > MAXW:
                cut -= 1
            if cut > 1 and paired(c[cut - 1][0], c[cut][0]):
                cut -= 1                              # never orphan half of a pair
            fixed.append(c[:cut])
            c = c[cut:]
        fixed.append(c)
    return fixed


def speech():
    """Per 5 ms hop: is he audible? None when the voice track is not there (then nothing is moved)."""
    media = "vo16_cut.wav" if os.path.exists("cuts.json") else "vo16.wav"
    if not os.path.exists(media):
        return None
    env, _ = vkit.envelope(media)
    return env >= vkit.speech_threshold(env)[0]


def onset(loud, start, first_end, lead=0.04, gap=14):
    """Where a caption that starts at `start` should really appear.

    The transcriber stamps the first word after a pause from the END of the word before it (the stamped end of that
    first word is about where he actually starts it). A caption timed off the stamp shows in dead air, 0.2-0.4 s
    before he is heard. So: if there is a silence of `gap` hops (70 ms) or more between `start` and just past the
    first word's stamped end, and his voice comes back within 0.12 s of that stamped end, the caption waits for it
    and shows `lead` seconds ahead. The silence must be a pause, not a stop consonant inside a word: 100 ms or more,
    or beginning within 0.12 s of the stamp. Measured on his reels (2026-10-07): real pauses were 140-190 ms with the
    voice back 0.00-0.11 s before the stamped end; the closures inside "completely", "posts", "Instagram" were
    70-90 ms and nowhere near it. Anything else is left where the transcriber put it."""
    if loud is None:
        return start
    i, k = int(start / 0.005), min(int((first_end + 0.12) / 0.005), len(loud))
    run = 0
    for j in range(i, k):
        if not loud[j]:
            run += 1
            continue
        t = j * 0.005
        if run >= gap and abs(t - first_end) <= 0.12 and (run >= 20 or (j - run) * 0.005 - start <= 0.12):
            return max(start, t - lead)
        run = 0
    return start


def main():
    vkit.need_applied()
    none = "--none" in sys.argv
    lines = []
    if not none:
        chunks = chunk(load_words())
        loud = speech()
        starts = [c[0][1] if c[0][1] in FIXED else onset(loud, c[0][1], c[0][2]) for c in chunks]
        moved = [(c[0][1], s) for c, s in zip(chunks, starts) if s - c[0][1] >= 0.08]
        for i, c in enumerate(chunks):
            start, end = starts[i], c[-1][2] + 0.3
            if i + 1 < len(chunks):
                nstart = starts[i + 1]
                end = nstart - 0.02 if nstart - c[-1][2] < 0.6 else min(end, nstart - 0.02)
            for x in EDGES:                           # the split opens or closes: this caption goes with it,
                if start < x - 0.03 < end:            # or it is left hanging at the wrong height over his face
                    end = x - 0.03
            parts = []
            for k, (w, _s, _e) in enumerate(c):
                clean = w.rstrip(".,!?") if k == len(c) - 1 else w.rstrip(".")
                if FOLLOW:                            # white, HI from the moment he starts the word to the next word
                    a = max(int(round((_s - start) * 1000)), 0) if k else 0
                    tag = "{" + HI if a == 0 else r"{\c&HFFFFFF&\t(%d,%d,%s)" % (a, a + 1, HI)
                    if k + 1 < len(c):
                        b = max(int(round((c[k + 1][1] - start) * 1000)), a + 2)
                        tag += r"\t(%d,%d,\c&HFFFFFF&)" % (b, b + 1)
                    parts.append(tag + "}" + clean)
                    continue
                parts.append(ACC + clean + WHITE if bare(clean) in ACCENT else clean)
            fx = (r"{\an5\pos(%d,%d)\fad(50,60)\fscx72\fscy72\t(0,90,\fscx108\fscy108)\t(90,170,\fscx100\fscy100)}"
                  % (W // 2, cap_y(start)))
            fin = max(end, start + 0.12)              # a short word still gets 0.12 s on screen ...
            if i + 1 < len(chunks):                   # ... but never runs into the next caption: a one-word stub held
                fin = min(fin, starts[i + 1] - 0.02)  # for his voice overlapped it and printed two captions (QC 2026-10-16)
            lines.append(f"Dialogue: 0,{ts(start)},{ts(fin)},Cap,,0,0,0,,{fx}{' '.join(parts)}")
    for s, e, txt in planlib.pops():
        d = int((e - s) * 1000)
        fx = (r"{\an5\pos(%d,%d)\fscx60\fscy60\fad(0,110)\t(0,110,\fscx112\fscy112)\t(110,200,\fscx100\fscy100)"
              r"\t(%d,%d,\fscx86\fscy86)}" % (W // 2, POP_Y, max(d - 140, 210), d))
        lines.append(f"Dialogue: 1,{ts(s)},{ts(e)},Pop,,0,0,0,,{fx}{txt.replace('|', chr(92) + 'N')}")

    o1, s1, o2, s2 = round(7 * S), round(4 * S), round(9 * S), round(5 * S)
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Times New Roman,{SIZE},&H00FFFFFF,&H00FFFFFF,&H00000000,&H78000000,-1,0,0,0,100,100,1,0,1,{o1},{s1},5,40,40,0,1
Style: Pop,Times New Roman,{POP_SIZE},&H00FFFFFF,&H00FFFFFF,&H00000000,&H78000000,-1,0,0,0,100,100,2,0,1,{o2},{s2},5,40,40,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    open("captions.ass", "w", encoding="utf-8").write(head + "\n".join(lines) + "\n")
    vkit.stamp("captions", {"id": planlib.captions_id(none), "none": none})
    for ln in lines:
        p = ln.split(",", 9)
        print(p[1], p[2], p[3], re.sub(r"\{[^}]*\}", "", p[9]))
    if not none and moved:
        print(f"{len(moved)} captions were stamped in a pause and now wait for his voice: "
              + ", ".join(f"{a:.2f}->{b:.2f}" for a, b in moved))
    print(f"{len(lines)} lines -> captions.ass. Read the list above: every word must be what he SAID.")


if __name__ == "__main__":
    main()
