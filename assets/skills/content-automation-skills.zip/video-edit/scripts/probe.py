"""probe.py - what is this clip, and which lane does it belong in.

    python probe.py <video>                    facts + the lane it should take
    python probe.py <video> --sheet sheet.png  labelled contact sheet (16 frames) to LOOK at before planning
    python probe.py <video> --jumpcuts         frames where the picture jumps (his own cuts), for hard-cut cards
    python probe.py <video> --json
Inside an edit folder the video may be left out (`python vk.py probe --jumpcuts`): it means the project's source.

Read the sheet before planning: it shows the framing, where his face is (the punch-in anchor), and whether
captions are already burned into the picture.
"""
import json, os, subprocess, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit


def jumpcuts(path, info):
    """Frame numbers where consecutive frames differ far more than their neighbours do."""
    w, h = 64, 114 if info["h"] > info["w"] else 36
    with vkit.lane("probe --jumpcuts"):                # passthrough: count the clip's real frames, the same ones
        p = subprocess.Popen(["ffmpeg", "-v", "error", *vkit.DEC, "-i", path, "-vf", f"scale={w}:{h},format=gray",
                              "-fps_mode", "passthrough", "-f", "rawvideo", "-"],     # overlay.py numbers
                             stdout=subprocess.PIPE, creationflags=vkit.LOW)
        raw = np.frombuffer(p.stdout.read(), np.uint8)
        p.wait()
    f = raw[:len(raw) // (w * h) * w * h].reshape(-1, h, w).astype(np.int16)
    d = np.abs(np.diff(f, axis=0)).mean(axis=(1, 2))
    out = []
    for i in range(len(d)):
        lo, hi = max(0, i - 12), min(len(d), i + 13)
        near = np.delete(d[lo:hi], i - lo)
        if d[i] > 4.0 and d[i] > 3.5 * (np.median(near) + 0.4):
            out.append((i + 1, float(d[i])))           # the cut is ON frame i+1 (first frame of the new shot)
    return out


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--") and not a.lower().endswith(".png")]
    if not args and os.path.exists("project.json"):   # inside an edit folder the clip is the project's source
        args = [vkit.project()["source"]["path"]]
    if not args or not os.path.exists(args[0]):
        print(__doc__)
        sys.exit(1)
    src = args[0]
    info = vkit.probe(src)
    if "--json" in sys.argv:
        print(json.dumps(info, indent=1))
        return
    a = info["audio"]
    print(f"\n  {src}")
    print(f"  {info['w']}x{info['h']}  {info['fps']} fps{' (VARIABLE)' if info['vfr'] else ''}  {info['dur']} s  "
          f"{info['codec']} {info['pix_fmt']}  rotation {info['rotation']}")
    print(f"  colour: {info['hdr'].upper()}  trc={info['trc']} prim={info['primaries']} range={info['range']}"
          f"{'  Dolby Vision' if info['dovi'] else ''}")
    print(f"  audio: {'NONE' if a is None else str(a['sr']) + ' Hz ' + a['codec']}")
    print()
    if info["hdr"] == "hlg":
        print("  LANE: this is HLG. Two honest choices:")
        print("    keep-HDR   overlay.py   hard-cut cards only, no cuts/captions, picture untouched (HEVC main10 out)")
        print("    SDR        compose.py   anything animated, cut, split or captioned (tonemapped to bt709 H.264)")
    elif info["hdr"] == "pq":
        print("  LANE: PQ/HDR10. Only compose.py (tonemapped to SDR) handles it; overlay.py refuses.")
    else:
        print("  LANE: SDR. compose.py for cuts/captions/graphics; overlay.py for plain hard-cut cards.")
    if a is None:
        print("  NO AUDIO: there is nothing to cut on or caption. Ask Deon for the right file.")
    if info["vfr"]:
        print("  Variable frame rate. compose.py resamples to a fixed rate first, so nothing changes there. In the")
        print("  overlay lane give card times in seconds (\"t\"), not frame numbers.")
    if a is not None and abs((info["a_start"] or 0) - info["v_start"]) > 0.02:
        print(f"  Sound and picture do not start together (video {info['v_start']} s, audio {info['a_start']} s): a cut made")
        print("  by these tools would shift them by that much. Remux the clip so both start at 0 first.")

    if "--sheet" in sys.argv:
        out = sys.argv[sys.argv.index("--sheet") + 1]
        n = 16
        times = [round((i + 0.5) * info["dur"] / n, 2) for i in range(n)]
        vkit.sheet(src, out, times, info["hdr"], cols=8)
        print(f"  sheet -> {out}  (Read it)")
    if "--jumpcuts" in sys.argv:
        cuts = jumpcuts(src, info)
        print(f"  {len(cuts)} jump cuts (frame, seconds, strength):")
        for n, s in cuts:
            print(f"    {n:6d}  {n / info['fps']:8.3f}  {s:5.1f}")
    print()


if __name__ == "__main__":
    main()
