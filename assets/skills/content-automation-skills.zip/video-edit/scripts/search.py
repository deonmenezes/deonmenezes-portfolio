"""search.py - web search through the local Chrome (DuckDuckGo HTML). Prints title | url | snippet.

    python vk.py search "site:bbc.com anabolic steroids UK users" "site:theguardian.com food waste UN report"
    python vk.py search queries.txt          one query per line

Use this when WebSearch/WebFetch cannot reach an outlet from this network (bbc.com and theguardian.com often).
A search result is a lead, not a source: open the page with shots.py and see the sentence before using it.
"""
import os, sys, urllib.parse

from playwright.sync_api import sync_playwright

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit  # noqa: F401  (utf-8 console)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/141.0.0.0 Safari/537.36")


def main():
    a = sys.argv[1:]
    if not a:
        print(__doc__)
        sys.exit(1)
    qs = [ln.strip() for ln in open(a[0], encoding="utf-8") if ln.strip()] if len(a) == 1 and os.path.exists(a[0]) else a
    with sync_playwright() as pw:
        b = pw.chromium.launch(channel="chrome", headless=True, args=["--disable-blink-features=AutomationControlled"])
        pg = b.new_context(user_agent=UA).new_page()
        for q in qs:
            print("##", q)
            try:
                pg.goto("https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(q), wait_until="domcontentloaded", timeout=45000)
                pg.wait_for_timeout(1200)
                rows = pg.evaluate("""() => [...document.querySelectorAll('.result')].slice(0, 7).map(r => {
                    const a = r.querySelector('.result__a'); const s = r.querySelector('.result__snippet');
                    let u = a ? a.href : ''; const m = /uddg=([^&]+)/.exec(u); if (m) u = decodeURIComponent(m[1]);
                    return (a ? a.innerText : '') + ' | ' + u + ' | ' + (s ? s.innerText.slice(0, 160) : ''); })""")
                for r in rows:
                    print("  ", r)
                if not rows:
                    print("   (no results)", pg.title())
            except Exception as e:
                print("   ERR", str(e)[:160])
        b.close()


if __name__ == "__main__":
    main()
