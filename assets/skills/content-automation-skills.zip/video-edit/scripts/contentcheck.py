"""contentcheck.py - the content checker's tools: background noise, and where each talking cut should start.

    python contentcheck.py noise <media> [--from S --to S]            noise floor, speech level, SNR, hum, wind
    python contentcheck.py denoise <media> <out.wav> [--limit 18]     DeepFilterNet speech denoise (keeps 18 dB max cut)
    python contentcheck.py heads <media> [--from S --to S]            every phrase: mouth opens / voice starts / ends
                                                                      -> the in-point (0.10 s before the mouth opens)
                                                                      and out-point (0.25 s after the last sound)
    python contentcheck.py check <media> --keep "a-b,c-d"             judge kept ranges (ORIGINAL seconds) against heads
    python contentcheck.py check <media> --edl edl.txt                same, from the cut list (kept = not removed)

Deon, 2026-10-15: "make sure that there is no noise in the background, and if there is, the noise is removed, and
... 0.1 second before me opening my mouth, that's when you should actually start the cut, instead of like 5 seconds
or 2 seconds me adjusting the camera then opening my mouth."

Rules this file enforces (numbers are the defaults; the agent brief says when to bend them):
  - A talking segment starts 0.10 s before his mouth opens. Mouth opening is read off the face (68-point landmarks,
    inner-lip gap); if no face is found it is taken as 0.12 s before the voice starts, which is where the lips part
    for most onsets. A start more than 0.30 s before that, or after the voice has started, FAILS.
  - A talking segment ends about 0.06 s after his last sound (0.04-0.12 s). Longer holds dead air and FAILS
    (Deon 2026-10-16, Roadster reel: the old 0.15-0.40 s tails read as pauses to him).
  - Background noise: floor under -55 dBFS, or speech at least 30 dB above it, is CLEAN. Otherwise NOISY: denoise
    the dialogue. Ambient/nature clips with no speech are reported, never denoised (waves are wanted).
Light work: one clip at a time, 4 threads; the face pass reads only the 0.8 s before each onset.
"""
import argparse, os, subprocess, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit  # noqa: E402

HOP = 0.005
LEAD, LEAD_MAX, TAIL_MIN, TAIL_MAX = 0.10, 0.30, 0.04, 0.12   # tails tightened 2026-10-17 (his 10-16 Roadster rule: ~0.06 s after)
MODELS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "models")


# ---------- audio ----------
def window(env, a, b):
    a = a or 0.0
    i0, i1 = int(max(a, 0) / HOP), int(b / HOP) if b else len(env)
    return env[i0:i1], i0 * HOP


def words(media):
    """Whisper word stamps [(start, end, word)], or None without faster-whisper. Footsteps, doors and waves
    cross the envelope threshold too; only stretches that hold words count as him talking."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None
    wav = "_cc_words.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", media, "-vn", "-ac", "1", "-ar", "16000", wav], check=True)
    with vkit.lane(f"contentcheck words {os.path.basename(media)}"):
        m = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=4)
        segs, _ = m.transcribe(wav, language="en", word_timestamps=True, vad_filter=False)
        out = [(w.start, w.end, w.word) for s in segs if s.no_speech_prob < 0.6 for w in (s.words or [])]
    os.remove(wav)
    return out


def phrases(env, t0=0.0, gap=0.30, min_len=0.12):
    """Voiced stretches: (start, end) in media seconds, split on quiet of `gap` s or more."""
    thr, floor, peak = vkit.speech_threshold(env)
    on = env > thr
    out, i, n = [], 0, len(on)
    while i < n:
        if not on[i]:
            i += 1
            continue
        j = i
        quiet = 0
        while j < n and quiet < gap / HOP:
            quiet = 0 if on[j] else quiet + 1
            j += 1
        end = j - quiet
        if (end - i) * HOP >= min_len:
            # walk the start back to where the envelope leaves the floor (soft consonants: /h/ /f/ /s/)
            k = i
            soft = floor + 0.12 * (peak - floor)
            while k > 0 and env[k - 1] > soft and (i - k) * HOP < 0.15:
                k -= 1
            out.append((t0 + k * HOP, t0 + end * HOP + 0.02))
        i = j
    return out


def speech_present(media, a=0.0, b=None):
    """Whisper decides whether there are words at all (an envelope cannot tell a voice from waves)."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None
    wav = "_cc_tmp.wav"
    cmd = ["ffmpeg", "-v", "error", "-y", "-ss", str(a), "-i", media]
    if b:
        cmd += ["-t", str(b - a)]
    subprocess.run(cmd + ["-vn", "-ac", "1", "-ar", "16000", wav], check=True)
    m = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=4)
    segs, _ = m.transcribe(wav, language="en", vad_filter=True)
    text = " ".join(s.text.strip() for s in segs if s.no_speech_prob < 0.6)
    os.remove(wav)
    return text


def cmd_noise(a):
    env, dur = vkit.envelope(a.media)
    w, t0 = window(env, a.frm, a.to)
    thr, floor, peak = vkit.speech_threshold(w)
    quiet = w[w < thr]
    loud = w[w >= thr]
    nf = float(np.median(quiet)) if len(quiet) else float(floor)
    sp = float(np.percentile(loud, 90)) if len(loud) else float(peak)
    words = speech_present(a.media, a.frm or 0, a.to)
    # hum and wind from the quiet frames' spectrum
    raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(a.frm or 0), "-i", a.media, *(["-t", str(a.to - (a.frm or 0))] if a.to else []),
                          "-vn", "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.float32)
    spec = np.abs(np.fft.rfft(x[: 16000 * 20] * np.hanning(min(len(x), 16000 * 20)))) + 1e-9
    f = np.fft.rfftfreq(min(len(x), 16000 * 20), 1 / 16000)
    tot = spec[(f > 20)].sum()
    wind = spec[(f > 20) & (f < 150)].sum() / tot
    hum = max(spec[(f > b - 1) & (f < b + 1)].max() / np.median(spec[(f > b - 15) & (f < b + 15)]) for b in (50, 60, 100, 120))
    snr = sp - nf
    print(f"{a.media}: floor {nf:.1f} dBFS, speech {sp:.1f} dBFS, SNR {snr:.1f} dB, low-band share {wind:.0%}, "
          f"hum peak x{hum:.0f}")
    print(f"  words heard: {words!r}" if words is not None else "  words heard: (faster-whisper missing)")
    if not words:
        print("  AMBIENT: no speech. Do not denoise; this is the natural sound of the clip.")
        return
    verdict = "CLEAN" if (nf < -55 or snr >= 30) and wind < 0.35 and hum < 30 else "NOISY"
    why = []
    if not (nf < -55 or snr >= 30):
        why.append(f"floor {nf:.0f} dBFS with only {snr:.0f} dB to the voice")
    if wind >= 0.35:
        why.append("wind / rumble under 150 Hz")
    if hum >= 30:
        why.append("mains hum")
    print(f"  {verdict}" + (": " + "; ".join(why) + " -> run `denoise` on this clip's dialogue" if why else ""))


def cmd_denoise(a):
    import torch
    torch.set_num_threads(4)
    from df.enhance import enhance, init_df, load_audio, save_audio
    with vkit.lane(f"denoise {os.path.basename(a.media)}"):
        model, st, _ = init_df()
        tmp = "_cc_in.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", a.media, "-vn", "-ac", "1", "-ar", str(st.sr()), tmp], check=True)
        audio, _ = load_audio(tmp, sr=st.sr())
        out = enhance(model, st, audio, atten_lim_db=a.limit)
        save_audio(a.out, out, st.sr())
        os.remove(tmp)
    print(f"denoised -> {a.out} (at most {a.limit} dB taken off the noise; run `noise` on it to confirm)")


# ---------- face ----------
_fm = {}


def _facemark():
    if not _fm:
        import cv2
        det = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        fm = cv2.face.createFacemarkLBF()
        fm.loadModel(os.path.join(MODELS, "lbfmodel.yaml"))
        _fm.update(det=det, fm=fm, cv2=cv2)
    return _fm


def mouth_gaps(media, a, b, fps=60):
    """Inner-lip gap / mouth width per frame over [a, b] (media seconds). None where no face is found."""
    F = _facemark()
    cv2 = F["cv2"]
    raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(a, 0):.3f}", "-i", media, "-t", f"{b - max(a, 0):.3f}",
                          "-vf", f"fps={fps},{vkit.TONEMAP},scale=540:-2,format=gray", "-f", "rawvideo", "-"],
                         capture_output=True).stdout
    # frame size after scale=540:-2 with rotation applied: derive it from the byte count
    n_px = None
    for h in range(300, 1300, 2):
        if len(raw) % (540 * h) == 0 and len(raw) // (540 * h) in range(int((b - a) * fps) - 3, int((b - a) * fps) + 4):
            n_px = (540, h)
            break
    if n_px is None:
        return []
    w, h = n_px
    frames = np.frombuffer(raw, np.uint8).reshape(-1, h, w)
    out = []
    for k, g in enumerate(frames):
        faces = F["det"].detectMultiScale(g, 1.1, 5, minSize=(60, 60))
        t = max(a, 0) + k / fps
        if len(faces) == 0:
            out.append((t, None))
            continue
        faces = np.array([max(faces, key=lambda r: r[2] * r[3])])
        ok, lm = F["fm"].fit(g, faces)
        if not ok:
            out.append((t, None))
            continue
        p = lm[0][0]
        width = np.linalg.norm(p[54] - p[48]) + 1e-6
        gap = np.mean([np.linalg.norm(p[i] - p[j]) for i, j in ((61, 67), (62, 66), (63, 65))])
        out.append((t, gap / width))
    return out


def mouth_open_before(media, onset):
    """When the lips part for the phrase that is heard at `onset`: the first frame, walking back from the onset,
    whose gap is still above the closed level. None if no face is tracked there."""
    g = mouth_gaps(media, onset - 0.8, onset + 0.15)
    vals = [(t, v) for t, v in g if v is not None]
    if len(vals) < 10:
        return None
    pre = [v for t, v in vals if t < onset - 0.35]
    closed = np.percentile(pre, 30) if pre else min(v for _, v in vals)
    at = [v for t, v in vals if abs(t - onset) < 0.06]
    if not at or max(at) < closed + 0.04:
        return None                                   # mouth does not visibly open at this onset (or bad track)
    level = closed + 0.35 * (max(at) - closed)
    t_open = onset
    for t, v in sorted(vals, reverse=True):
        if t > onset + 0.05:
            continue
        if v < level:
            break
        t_open = t
    return t_open


def hf_envelope(media, sr=16000):
    """Envelope (dB, 5 ms hop) of the audio above 4 kHz. A word-final /s/ /sh/ /t/ is 25-35 dB under the vowels and
    vanishes from the broadband envelope; above 4 kHz it stands clear of room tone. (2026-10-18: the check passed a
    cut that removed the end of "millimetres" because the broadband envelope called the trailing "s" silence.)"""
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", media, "-vn", "-af", "highpass=f=4000:poles=2",
                          "-f", "f32le", "-ac", "1", "-ar", str(sr), "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.float32).astype(np.float64)
    hop, win = int(sr * HOP), int(sr * 0.020)
    c = np.concatenate([[0.0], np.cumsum(x * x)])
    idx = np.arange(max((len(x) - win) // hop, 0)) * hop
    return 20 * np.log10(np.sqrt(np.maximum((c[idx + win] - c[idx]) / win, 0)) + 1e-9)


def extend_sibilant(e, hf, max_ext=0.30):
    """Walk the phrase end forward while the >4 kHz energy stays well above its own floor (a trailing consonant)."""
    if hf is None or not len(hf):
        return e
    floor = float(np.percentile(hf, 20))
    i = int(e / HOP)
    end, gap, k = i, 0, i
    # follow the hiss forward, bridging dips up to 0.16 s (the "tr" before the final "s" in "millimetres" dips)
    while k < len(hf) - 1 and (k - i) * HOP < max_ext + 0.2:
        if hf[k] > floor + 12:
            end, gap = k, 0
        else:
            gap += 1
            if gap * HOP > 0.16:
                break
        k += 1
    return max(e, (end + 1) * HOP)


def heads(media, a=0.0, b=None):
    env, dur = vkit.envelope(media)
    w, t0 = window(env, a, b)
    rows = []
    ws = words(media)
    try:
        hf = hf_envelope(media)
    except Exception:
        hf = None
    for s, e in phrases(w, t0):
        if ws is not None:
            inside = [x for x in ws if x[1] > s - 0.1 and x[0] < e + 0.1]
            if not inside:
                continue                              # loud, but no words: footsteps, wind, a door
            e = min(e, max(x[1] for x in inside) + 0.12)   # the envelope can run on into noise after the last word
        e = extend_sibilant(e, hf)                    # but never end a phrase inside its final /s/
        try:
            mo = mouth_open_before(media, s)
        except Exception as ex:                       # no contrib module, no model, unreadable frames
            mo, why = None, str(ex)[:60]
        src = "face" if mo is not None else "voice-0.12"
        if mo is None:
            mo = s - 0.12
        mo = min(mo, s)
        rows.append({"voice": round(s, 3), "end": round(e, 3), "mouth": round(mo, 3), "src": src,
                     "in": round(max(mo - LEAD, 0), 3), "out": round(min(e + 0.06, dur), 3)})
    return rows, dur


def cmd_heads(a):
    rows, dur = heads(a.media, a.frm or 0.0, a.to)
    print(f"{a.media}: {len(rows)} phrases")
    for r in rows:
        print(f"  mouth {r['mouth']:7.3f} ({r['src']:10s}) voice {r['voice']:7.3f}-{r['end']:7.3f}   "
              f"IN {r['in']:7.3f}  OUT {r['out']:7.3f}")


def cmd_check(a):
    rows, dur = heads(a.media)
    if a.edl:
        cuts = []
        for line in open(a.edl, encoding="utf-8"):
            if line.strip() and not line.startswith("#"):
                p = line.split()
                cuts.append((float(p[0]), float(p[1])))
        keep, t = [], 0.0
        for s, e in sorted(cuts):
            if s > t:
                keep.append((t, s))
            t = max(t, e)
        if t < dur:
            keep.append((t, dur))
    else:
        keep = [tuple(float(x) for x in r.split("-")) for r in a.keep.split(",")]
    bad = 0
    for k0, k1 in keep:
        inside = [r for r in rows if r["voice"] < k1 and r["end"] > k0]
        if not inside:
            print(f"  keep {k0:.3f}-{k1:.3f}: no speech (ambient / b-roll) - not judged")
            continue
        first, last = inside[0], inside[-1]
        notes = []
        lead = first["mouth"] - k0
        if k0 > first["voice"] + 0.01:
            notes.append(f"FAIL starts {k0 - first['voice']:.2f} s AFTER his voice starts (clipped word)")
        elif lead > LEAD_MAX:
            notes.append(f"FAIL starts {lead:.2f} s before his mouth opens (should be {LEAD:.2f}): set IN {first['in']:.3f}")
        tail = k1 - last["end"]
        if last["end"] <= k1 and tail > TAIL_MAX:
            notes.append(f"FAIL holds {tail:.2f} s after his last sound: set OUT {last['out']:.3f}")
        elif last["end"] > k1 + 0.02 and last["voice"] < k1:
            notes.append(f"FAIL ends inside a word ({last['end'] - k1:.2f} s cut off)")
        bad += any(n.startswith("FAIL") for n in notes)
        print(f"  keep {k0:.3f}-{k1:.3f}: " + ("; ".join(notes) if notes else
              f"ok (lead {lead:+.2f} s before mouth [{first['src']}], tail {tail:.2f} s)"))
    print("PASS" if not bad else f"FAIL: {bad} segment(s)")
    sys.exit(1 if bad else 0)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = p.add_subparsers(dest="cmd", required=True)
    for name in ("noise", "heads", "check"):
        q = sp.add_parser(name)
        q.add_argument("media")
        q.add_argument("--from", dest="frm", type=float, default=None)
        q.add_argument("--to", type=float, default=None)
        if name == "check":
            q.add_argument("--keep", default=None)
            q.add_argument("--edl", default=None)
    q = sp.add_parser("denoise")
    q.add_argument("media")
    q.add_argument("out")
    q.add_argument("--limit", type=float, default=18.0)
    a = p.parse_args()
    {"noise": cmd_noise, "denoise": cmd_denoise, "heads": cmd_heads, "check": cmd_check}[a.cmd](a)


if __name__ == "__main__":
    main()
