"""qc.py - check a finished render before anyone calls it done.

    python vk.py qc <final.mp4>             fast checks + qc_sheet.png (24 labelled frames to LOOK at)
    python vk.py qc <final.mp4> --asr       also transcribe the final and compare it with the words of the cut
    python vk.py qc <final.mp4> --sheet 40  more frames on the sheet
    python vk.py qc <final.mp4> --frame 12.5,13.0     just save those frames full size (tonemapped if HDR), no checks
    python vk.py qc <part.mp4> --expect-dur 5         check a --range excerpt (it can pass, it cannot be delivered)

What it measures (FAIL stops delivery, WARN wants a look):
  streams      video + audio present, frame size and rate as the project says, hvc1 tag on HEVC, colour tags set,
               an overlay-lane file still in the source's HDR format, and the render not older than the cut list
  length       video and audio the same length; matches the cut timeline (or the source, for overlay.py output)
  loudness     about -14 LUFS and under -1 dBTP for a mixed track
  picture      no black frames, no frozen stretch (a stalled overlay input freezes the picture)
  sound        no dead-silent hole
  ending       the last word is not clipped by the end of the file
  words        (--asr) every word of the cut is still heard in the final file

It cannot judge taste. The sheet is for that: read it frame by frame against the brief and references/house-style.md.
A pass is written to qc.json with the file's hash; deliver.py refuses a file that has not passed.
"""
import json, os, subprocess, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vkit

RES = []


def note(level, what, detail):
    RES.append((level, what, detail))
    print(f"  {level:<4} {what:<10} {detail}")


def loudness(path):
    r = vkit.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"],
                 heavy=True, check=False)
    tail = r.stderr[r.stderr.rfind("Summary:"):]
    val = lambda k: next((float(ln.split()[1]) for ln in tail.splitlines() if ln.strip().startswith(k)), None)
    return val("I:"), val("Peak:")


def silences(path):
    r = vkit.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vn", "-af", "silencedetect=noise=-60dB:d=1.2",
                  "-f", "null", "-"], heavy=True, check=False)
    out, start = [], None
    for ln in r.stderr.splitlines():
        if "silence_start:" in ln:
            start = float(ln.split("silence_start:")[1].split()[0])
        elif "silence_end:" in ln and start is not None:
            out.append((start, float(ln.split("silence_end:")[1].split()[0])))
            start = None
    return out


def walk(path, info):
    """mean brightness and frame-to-frame change of every frame, at thumbnail size"""
    w, h = (72, 128) if info["h"] >= info["w"] else (128, 72)
    vf = (f"{vkit.TONEMAP}," if info["hdr"] != "sdr" else "") + f"scale={w}:{h},format=gray"
    p = subprocess.Popen(["ffmpeg", "-v", "error", *vkit.DEC, "-i", path, "-vf", vf, "-fps_mode", "passthrough",
                          "-f", "rawvideo", "-"], stdout=subprocess.PIPE, creationflags=vkit.LOW)   # real frames only
    raw = np.frombuffer(p.stdout.read(), np.uint8)
    p.wait()
    f = raw[:len(raw) // (w * h) * w * h].reshape(-1, h, w).astype(np.int16)
    d = np.abs(np.diff(f, axis=0))
    return f.mean(axis=(1, 2)), d.mean(axis=(1, 2)), d[:, h // 2:].mean(axis=(1, 2))


def runs(mask, fps, min_s):
    """[(start_s, end_s)] of stretches where mask stays true for at least min_s"""
    out, i = [], 0
    while i < len(mask):
        if mask[i]:
            j = i
            while j < len(mask) and mask[j]:
                j += 1
            if (j - i) / fps >= min_s:
                out.append((i / fps, j / fps))
            i = j
        else:
            i += 1
    return out


def main():
    a = sys.argv[1:]
    files = [x for x in a if not x.startswith("--") and os.path.exists(x)]
    if not files:
        print(__doc__)
        sys.exit(1)
    path = files[0]
    n_sheet = int(a[a.index("--sheet") + 1]) if "--sheet" in a else 24
    info = vkit.probe(path)
    if "--frame" in a:                               # full-size frames to look at, tonemapped if the file is HDR
        for t in a[a.index("--frame") + 1].split(","):
            im = vkit.grab(path, float(t), info["hdr"])
            if im is None:
                raise SystemExit(f"no frame at {t} s (the file is {info['dur']} s long)")
            im.save(f"qc_frame_{float(t):07.2f}.png")
            print(f"qc_frame_{float(t):07.2f}.png")
        return
    proj = json.load(open("project.json", encoding="utf-8")) if os.path.exists("project.json") else None
    fps, dur = info["fps"], info["dur"]
    excerpt = "--expect-dur" in a
    copied = False                                   # is this overlay.py output (uncut clip, source audio copied)?
    if os.path.exists("overlay.json"):
        ov = json.load(open("overlay.json", encoding="utf-8"))
        copied = os.path.basename(ov.get("out", "overlay.mp4")) == os.path.basename(path)
    print(f"\n  {path}: {info['w']}x{info['h']} {fps} fps {dur} s {info['codec']} {info['hdr'].upper()}"
          f"{'  (overlay lane)' if copied else ''}\n")

    with vkit.lane(f"qc {os.path.basename(path)}"):
        # streams
        if info["audio"] is None:
            note("FAIL", "streams", "no audio stream")
        if info["codec"] == "hevc" and info["tag"] != "hvc1":
            note("FAIL", "streams", f"HEVC tagged {info['tag']}: iPhone and QuickTime need hvc1 (-tag:v hvc1)")
        if "unknown" in (info["trc"], info["primaries"], info["matrix"]):
            note("FAIL", "streams", f"colour tags missing (trc={info['trc']} prim={info['primaries']} matrix={info['matrix']}): "
                                    "players will guess, and HLG goes washed out")
        if info["vfr"]:
            note("WARN", "streams", f"variable frame rate ({info['fps']} vs {info['avg_fps']} average)")
        if proj:
            src = proj["source"]
            ww, hh, ff = (src["w"], src["h"], src["fps"]) if copied else (proj["w"], proj["h"], proj["fps"])
            if (info["w"], info["h"]) != (ww, hh):
                note("FAIL", "streams", f"frame is {info['w']}x{info['h']}, this edit should be {ww}x{hh}")
            if abs(fps - ff) > 0.01:
                note("FAIL", "streams", f"{fps} fps, this edit should be {ff} fps")
            if copied and info["hdr"] != src["hdr"]:
                note("FAIL", "streams", f"the source is {src['hdr'].upper()} and this file is {info['hdr'].upper()}: "
                                        "the overlay lane must keep the picture as shot")
            built = vkit.stamps().get("build:" + os.path.basename(path))
            if built and built.get("sha256") == vkit.sha256(path):
                if built["cut"] != vkit.cut_id() or vkit.edl_pending():
                    note("FAIL", "streams", "this file was rendered from an earlier cut: the cut list has changed since. "
                                            "Rebuild (edl apply, edl verify, captions, mix, render_anim, compose).")
                excerpt = excerpt or bool(built.get("excerpt"))
        if not [r for r in RES if r[1] == "streams"]:
            note("ok", "streams", f"video + audio, {info['w']}x{info['h']} at {fps} fps, colour "
                                  f"{info['primaries']}/{info['trc']}, tag {info['tag']}")

        # length
        if info["audio"] and abs(info["audio"]["dur"] - dur) > 0.12 and info["audio"]["dur"]:
            note("FAIL", "length", f"audio is {info['audio']['dur']} s, the file {dur} s")
        want = {}
        if proj and (copied or not os.path.exists("cuts.json")):
            want["the source"] = proj["source"]["dur"]
        elif proj:
            c = json.load(open("cuts.json"))
            want["the cut timeline"] = round(sum(y - x for x, y in c["keep"]), 3)
        hit = [k for k, v in want.items() if abs(v - dur) <= 0.15]
        if "--expect-dur" in a:
            e = float(a[a.index("--expect-dur") + 1])
            note("ok" if abs(e - dur) <= 0.15 else "FAIL", "length", f"{dur} s, expected {e} s (an excerpt: not deliverable)")
        elif excerpt:
            note("ok", "length", f"{dur} s, a --range excerpt (not deliverable)")
        elif want and not hit:
            note("FAIL", "length", f"{dur} s is not " + " or ".join(f"{k} ({v} s)" for k, v in want.items()) +
                 ". For an excerpt on purpose pass --expect-dur <seconds>; an excerpt can pass qc but cannot be delivered")
        elif hit:
            note("ok", "length", f"{dur} s = {hit[-1]}")

        # loudness
        if info["audio"]:
            lufs, peak = loudness(path)
            mixed = not copied                       # overlay.py copies the source audio: nothing was mixed to a target
            if lufs is None:
                note("WARN", "loudness", "could not be measured")
            elif mixed and not -16.0 <= lufs <= -12.5:
                note("FAIL", "loudness", f"{lufs} LUFS (target -14)")
            elif peak is not None and peak > -0.9:
                note("FAIL" if mixed else "WARN", "loudness", f"true peak {peak} dBTP (ceiling -1)")
            else:
                note("ok", "loudness", f"{lufs} LUFS, true peak {peak} dBTP" + ("" if mixed else " (source audio, copied)"))
            for s, e in silences(path):
                if s > 0.3 and e < dur - 0.3:
                    note("WARN", "sound", f"dead silence {s:.2f}-{e:.2f} s")

        # picture
        bright, diff, low = walk(path, info)
        n = len(bright)
        if abs(n - round(dur * fps)) > max(3, 0.01 * n):
            note("WARN", "picture", f"decoded {n} frames, the header says {round(dur * fps)}")
        fade = int(fps * 0.7)
        dark = [i for i in np.where(bright < 12)[0] if fps * 0.2 < i < n - fade]
        if dark:
            note("FAIL", "picture", f"{len(dark)} black frames, first at {dark[0] / fps:.2f} s")
        whole = runs(diff < 0.04, fps, 1.0)
        for s, e in whole:
            note("FAIL" if e - s >= 2.0 else "WARN", "picture",
                 f"frozen {s:.2f}-{e:.2f} s (a still card is fine; a stalled input is not)")
        # He is in the lower half in every layout (full frame and split). If only that half stops moving while a
        # panel above keeps animating, the picture has run out under the graphics.
        half = [r for r in runs(low < 0.04, fps, 1.5) if not any(s <= r[0] and r[1] <= e for s, e in whole)]
        for s, e in half:
            note("FAIL", "picture", f"the lower half is frozen {s:.2f}-{e:.2f} s: he has stopped moving under the graphics "
                                    "(fine only if a still photo fills the frame there)")
        if not dark and not whole and not half:
            note("ok", "picture", f"{n} frames, none black, none frozen")

        # ending
        wj = "words.json" if copied or not os.path.exists("cuts.json") else "words_cut.json"
        words = json.load(open(wj, encoding="utf-8")) if os.path.exists(wj) else []
        if words and hit:
            gap = dur - words[-1]["e"]
            note("WARN" if gap < 0.12 else "ok", "ending", f"last word [{words[-1]['w']}] ends {gap:.2f} s before the end")

        # words
        if "--asr" in a and words:
            import edl
            from transcribe import transcribe
            got, _ = transcribe(path)
            A, B = [edl.norm(w["w"]) for w in words], [edl.norm(w["w"]) for w in got]
            bad = [(op, i, j) for op, i, j in edl.align(A, [False] * len(A), B) if op != "eq"]
            for op, i, j in bad[:12]:
                was = words[i]["w"] if i is not None else ""
                now = got[j]["w"] if j is not None else ""
                t = words[i]["s"] if i is not None else got[j]["s"]
                note("WARN", "words", f"at {t:.2f} s: expected [{was}] heard [{now}]")
            if len(bad) > max(3, 0.03 * len(A)):
                note("FAIL", "words", f"{len(bad)} of {len(A)} words differ from {wj}: wrong audio, or the end was cut off")
            elif not bad:
                note("ok", "words", f"all {len(A)} words of {wj} are heard in the file")

    times = [round((k + 0.5) * dur / n_sheet, 2) for k in range(n_sheet)]
    vkit.sheet(path, "qc_sheet.png", times, info["hdr"], cols=8)
    fails = [r for r in RES if r[0] == "FAIL"]
    warns = [r for r in RES if r[0] == "WARN"]
    verdict = "FAIL" if fails else "PASS"
    json.dump({"file": os.path.abspath(path).replace("\\", "/"), "sha256": vkit.sha256(path), "verdict": verdict,
               "excerpt": excerpt, "asr": "--asr" in a, "results": RES}, open("qc.json", "w", encoding="utf-8"), indent=1)
    print(f"\n  {verdict}{' (excerpt, not deliverable)' if excerpt and not fails else ''}: {len(fails)} fail, "
          f"{len(warns)} warn. Sheet -> qc_sheet.png (Read it: this script cannot see taste).")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
