"""plan.py - the whole edit on one page.

Every time in this file is in ORIGINAL (uncut) seconds, read straight off words.txt. The tools move them onto the
cut timeline; never do that by hand. Check the result with:  python vk.py compose --stills <new-time seconds>
"""

# ---- the talking head ----
# FACE_C = (540, 940)    # the point punch-ins zoom about: between his eyes, in OUTPUT pixels. Left out, it is the
#                        # centre of the frame, 49% down, which fits his usual framing. Read it off sheet.png.
PUNCH = 0.07             # 7% punch-in on every other jump cut, so a splice reads as a camera move. 0 = off
GRADE = "eq=contrast=1.05:saturation=0.96:gamma=0.98"    # his picture only, graphics stay ungraded. "" = untouched
FINISH = ""              # whole frame, under the captions. The cinematic chain is in references/looks.md
FADE_OUT = 0.35          # seconds of fade at the very end. 0 = hard end

# ---- split screen (defaults follow the frame; set these only to change them) ----
# PANEL_H = 960          # height of the animation panel at the top. Default: half the frame
# SHIFT = 540            # how far he slides down so his face sits in the lower part. Default: 9/32 of the height
SLIDE = 0.30             # seconds for the split to open and close
SEAM = (0xF2, 0x65, 0x22)   # RGB line between panel and face. None = no line

# ---- what goes on screen, and when ----
# kind="split"  animation panel on the top half, him on the bottom half (anim = a scene name in anim.html)
# kind="card"   a PNG over the full frame. hard=True: appears and disappears on the frame, no motion, no dimming.
#               x, y = the card's CENTRE.  top=254 instead of y= places it by its top edge.
#               maxw / maxh shrink it to fit, round=30 gives a raw screenshot rounded corners and a shadow,
#               dim=0.6 blurs and darkens what is behind it.
# kind="anim"   a transparent animation over the frame. size=(w, h) of the scene; x, y = its centre.
#               With no size it is the whole frame.
# kind="broll"  a photo (slow push, z=(from, to)) or a video clip (start= seconds into it) replaces him; his voice
#               carries on. The clip must be at least as long as the segment. hard=True: no dissolve.
# ev = moments inside the segment the animation reacts to: the second he SAYS the word
SEGMENTS = [
    # dict(t=(2.86, 8.10),  kind="split", anim="what_is_claude", ev=[3.66, 4.18, 6.08]),
    # dict(t=(12.0, 15.2),  kind="card",  png="cards/bbc.png", top=254, hard=True),
    # dict(t=(16.0, 19.5),  kind="card",  png="shots/cnbc.png", y=800, maxw=1000, dim=0.6, round=30),
    # dict(t=(20.0, 24.0),  kind="anim",  anim="todo", ev=[21.2], size=(1080, 1200), y=800, dim=0.5),
    # dict(t=(30.0, 33.0),  kind="broll", src="broll/goa.jpg", z=(1.05, 1.15)),
    # dict(t=(33.0, 36.0),  kind="broll", src="broll/clip.mp4", start=4.0),
]

# ---- big keyword pop-ups (upper-middle of the frame, pop in, hold on the words, shrink away) ----
POPS = [
    # (0.15, 1.86, "CLAUDE JUST|KILLED YOUTUBE"),     # "|" starts a second line; two lines is the limit
]
