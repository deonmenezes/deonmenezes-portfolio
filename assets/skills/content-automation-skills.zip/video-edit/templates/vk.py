"""Run a video-edit skill tool from this edit folder:  python vk.py <tool> [args]   (python vk.py <tool> --help)"""
import ast, os, runpy, sys

S = os.path.expanduser("~/.claude/skills/video-edit/scripts").replace("\\", "/")
tools = sorted(f[:-3] for f in os.listdir(S) if f.endswith(".py") and f not in ("vkit.py", "timemap.py", "planlib.py"))
if len(sys.argv) < 2 or sys.argv[1] not in tools:
    print("usage: python vk.py <tool> [args]     python vk.py <tool> --help\ntools: " + ", ".join(tools))
    sys.exit(1)
tool = sys.argv.pop(1)
sys.argv[0] = f"{S}/{tool}.py"
if "--help" in sys.argv or "-h" in sys.argv:      # every tool's usage is its docstring; nothing is run
    print(ast.get_docstring(ast.parse(open(sys.argv[0], encoding="utf-8").read())))
    sys.exit(0)
sys.path[:0] = [os.getcwd(), S]
runpy.run_path(sys.argv[0], run_name="__main__")
