# Edit brief

The lead fills this in before any agent starts. Every agent reads it first and works from it, not from memory of
the conversation. If something here is wrong or missing, say so in your report: do not guess around it.

## What Deon asked for

> paste his exact words here, typos and all

What that means, in one or two plain sentences:

## The clip

- Source (original path):
- What he says, in one line:
- Call to action in the clip (the word he asks people to comment, if any):
- Captions already burned into the picture? (look at sheet.png):
- Lane: `compose` (SDR, cut + captions + graphics) / `overlay` (untouched picture, hard-cut cards)
- Look (references/looks.md):

## Decisions already made

- Cut pauses, fillers and repeated takes: yes / no
- Captions: ours / already burned in / none
- Graphics: on every spoken claim / only where he asked
- Music: none (default) / track + start second
- Sound effects: none (default)

## Facts that may go on screen

Only things he says in this clip, things in references/house-style.md, or things a researcher has SEEN on a
source page. One line each, with where it comes from.

-

## Who does what

| lane | owner | writes | done when |
| --- | --- | --- | --- |
| cut | | edl.txt, cuts.json, words_cut.json | `edl verify` prints OK |
| sources | | jobs.json, shots/, cards/, sources.md | every card read back as an image |
| graphics | | anim.html, plan.py SEGMENTS | every scene previewed as stills |
| captions | | captions.json, plan.py POPS | caption list read against the audio |
| package | | package.md | caption + title + hashtags, nothing invented |
| qc | (never an agent that built any of it) | qc-report.md | PASS, or a list of what to fix |

## Open questions for Deon

Things that would change the edit and cannot be worked out. Keep going on everything else.

-
