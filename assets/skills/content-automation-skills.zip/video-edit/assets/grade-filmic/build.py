"""build.py - writes the two cubes of the final grade for Deon's talking-head reels.

  python cand_final/build.py             build filmic_look.cube and filmic_key.cube next to this file, print checks
  python cand_final/build.py --colours   only print what the look does to known colours of the footage

filmic_look.cube  (65 points)  the look: display-referred BT.709 picture after the pipeline's tonemap -> graded picture.
                                  It is the judges' winner (cand_lut/make_lut.py) with these changes:
                                    - no lightness tilt between cool and warm colours any more (that tilt is what left a
                                      pale rim where his face meets the wall); the wall is darkened by the key instead
                                    - skin gets a little more contrast and its own soft shoulder, so a shiny forehead
                                      rolls off as warm skin instead of a pale patch
                                    - the wall's hue and saturation are pulled onto one teal, so the two clips match
                                    - shadow teal kept off skin, the cool mid tint kept off the cream cabinets
filmic_key.cube   (33 points)  the wall key: the same input picture -> a grey "gain" picture, white (1.0) everywhere
                                  except on pale cool surfaces (the glass wall), which come out at 1 - KEY["depth"].
                                  The chain runs it at quarter size, softens it and multiplies the graded picture by it.

THE ONE BRIGHTNESS KNOB is P["ev"] (stops, linear light). -0.90 is the delivered value; -0.80 is a little brighter,
-1.00 a little darker. Rebuild with this script and copy both cubes next to the edit; nothing else has to move.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
N = 65
NAME = "filmic_look.cube"
KEY_N = 33
KEY_NAME = "filmic_key.cube"

P = dict(
    # ---- 1. palette: skin
    skin_c=50.0, skin_lo=20.0, skin_hi=20.0,   # Oklab hue window of skin (centre, sigma below, sigma above), degrees
    skin_to=62.0, skin_pull=0.50,              # pull hues in the window toward skin_to by this fraction
    skin_sat=1.06,                             # chroma gain inside the window
    skin_c0=0.025, skin_c1=0.085,              # chroma range over which the skin tools fade in
    # ---- 1. palette: cools
    cool_on=150.0, cool_full=235.0, cool_end=280.0,     # cool family: fades in over cool_on..+30, out over full..end
    cool_to=190.0, cool_pull=0.60, cool_soft=10.0,      # hues bluer than cool_to are pulled toward it (teal)
    cool_pull_pale=0.90, cool_pale_c=0.045,    # pale cools (the wall) are pulled harder, so both clips land on one hue
    cool_gain=1.50, cool_cmax=0.040,           # pale cools: chroma = cmax*tanh(gain*C/cmax): more colour, but levelled
    cool_lim0=0.05, cool_lim1=0.09,            # ...fading back to the untouched chroma over this range (shirt, ink)
    green_c=138.0, green_w=28.0,
    green_sat=0.92, green_shift=5.0,
    chroma_gate=0.015,                         # hue tools fade in over this chroma (keeps the grey axis smooth)
    # ---- 2. tone
    ev=-0.90,            # exposure in stops, linear light  <<< the brightness knob
    pivot=0.20,          # linear luminance that the contrast turns around (after exposure)
    c_lo=1.15,           # log contrast below the pivot
    c_hi=1.50,           # log contrast above the pivot
    c_w=0.6,             # width in stops of the blend between the two
    sh_knee=0.42,        # linear luminance where the shoulder starts
    sh_white=0.86,       # linear luminance the shoulder levels off toward; pure white lands near 222/255
    follow=1.0,          # chroma follows (L'/L)^follow
    # ---- 3. skin and warm tones (worked on the grey-equivalent code value, 0..1)
    warm_lift=0.03, warm_slope=4.0, warm_axis=197.0,   # warm colours a little lighter (as in the winner)
    sk_pivot=131.0 / 255, sk_lo=0.12, sk_hi=0.20, sk_w=0.03,   # extra contrast inside skin around its own mean
    wsh_knee=150.0 / 255, wsh_top=182.0 / 255,          # shoulder for warm tones: nothing warm goes above wsh_top
    wsh_c0=0.012, wsh_c1=0.030,                         # ...fading in over this chroma (pure whites are left alone)
    fill=0.30, fill_from=0.875, fill_to=0.93,           # colour put back into the very brightest pale skin (source L)
    # ---- 4. saturation
    sat=1.00,
    hi_from=0.80, hi_to=1.00, hi_desat=0.50,
    lo_to=0.25, lo_desat=0.30,
    # ---- 5. split tone (Oklab a/b offsets)
    sh_tint=0.007, sh_hue=205.0, sh_peak=0.28, sh_width=0.22,     # teal, strongest at this lightness
    sh_skin_protect=0.85,                                          # share of the shadow tint kept off skin
    mid_tint=0.005, mid_hue=215.0, mid_peak=0.60, mid_width=0.22,  # near-neutral mids, a cooler white
    mid_protect=0.045,                                             # fades out as chroma approaches this
    mid_warm0=-0.010, mid_warm1=0.004,                             # ...and toward the warm side (cream cabinets)
    # ---- 6. gamut
    gamut_knee=0.70,
    # ---- 7. toe
    lift=(0.022, 0.028, 0.031), lift_pow=6.0,
)

KEY = dict(
    axis=218.0,                 # Oklab hue of the wall
    c0=0.004, c1=0.012,         # how far toward that hue a colour must sit before it counts as wall
    l0=0.60, l1=0.68,           # lightness window: starts above the navy shirt, full on the pale wall
    depth=0.18,                 # the wall comes out at (1 - depth) of its graded value
)


# ------------------------------------------------------------------ colour space
def to_lin(v):
    v = np.clip(v, 0, 1)
    return np.where(v <= 0.04045, v / 12.92, ((v + 0.055) / 1.055) ** 2.4)


def to_enc(v):
    v = np.clip(v, 0, None)
    return np.where(v <= 0.0031308, v * 12.92, 1.055 * v ** (1 / 2.4) - 0.055)


M1 = np.array([[0.4122214708, 0.5363325363, 0.0514459929],
               [0.2119034982, 0.6806995451, 0.1073969566],
               [0.0883024619, 0.2817188376, 0.6299787005]])
M2 = np.array([[0.2104542553, 0.7936177850, -0.0040720468],
               [1.9779984951, -2.4285922050, 0.4505937099],
               [0.0259040371, 0.7827717662, -0.8086757660]])
M1I, M2I = np.linalg.inv(M1), np.linalg.inv(M2)


def lin_to_oklab(rgb):
    return np.cbrt(rgb @ M1.T) @ M2.T


def oklab_to_lin(lab):
    return ((lab @ M2I.T) ** 3) @ M1I.T


# ------------------------------------------------------------------ small smooth helpers
def smoothstep(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def bump(x, peak, width):
    return np.exp(-((x - peak) / width) ** 2)


def softplus(u, w):
    return w * np.logaddexp(0, u / w)


def tone(x, p):
    """linear luminance in -> linear luminance out"""
    x1 = np.maximum(x, 1e-9) * 2.0 ** p["ev"]
    u = np.log2(x1 / p["pivot"])
    w = p["c_w"]
    sp = w * np.logaddexp(0, u / w) - w * np.log(2.0)             # softplus, zero at u = 0
    x2 = p["pivot"] * 2.0 ** (p["c_lo"] * u + (p["c_hi"] - p["c_lo"]) * sp)
    t, wp = p["sh_knee"], p["sh_white"]
    return np.where(x2 <= t, x2, t + (wp - t) * np.tanh((x2 - t) / (wp - t)))


# ------------------------------------------------------------------ the look
def grade(enc, p=P):
    """enc: (..., 3) encoded RGB 0..1  ->  graded encoded RGB 0..1"""
    lab = lin_to_oklab(to_lin(enc.reshape(-1, 3).astype(np.float64)))
    L, a, b = lab[:, 0], lab[:, 1], lab[:, 2]
    C = np.hypot(a, b)
    h = np.degrees(np.arctan2(b, a)) % 360
    gate = 1 - np.exp(-(C / p["chroma_gate"]) ** 2)

    # 1. palette -------------------------------------------------------------
    d = (h - p["skin_c"] + 180) % 360 - 180
    w_skin = np.exp(-(d / np.where(d < 0, p["skin_lo"], p["skin_hi"])) ** 2)
    hs = (h - p["skin_to"] + 180) % 360 - 180
    g_skin = smoothstep(p["skin_c0"], p["skin_c1"], C)      # skin tools fade out for pale colours: eye whites and
    dh = -p["skin_pull"] * w_skin * hs * g_skin             # teeth are warm but pale, and must stay as they are
    w_end = smoothstep(p["cool_end"], p["cool_full"], h)             # 1 up to cool_full, 0 from cool_end (purples)
    w_cool = smoothstep(p["cool_on"], p["cool_on"] + 30, h) * w_end   # gains: the whole teal..blue family
    dc = np.maximum(h - p["cool_to"], 0.0)                            # hue pull: only hues bluer than the target,
    pull = p["cool_pull"] + (p["cool_pull_pale"] - p["cool_pull"]) * np.exp(-(C / p["cool_pale_c"]) ** 2)
    dh += -pull * w_end * dc * dc / (dc + p["cool_soft"]) * gate     # easing in, slope always < 1 (no fold)
    w_green = np.exp(-(((h - p["green_c"] + 180) % 360 - 180) / p["green_w"]) ** 2)
    dh += p["green_shift"] * w_green * gate
    h2 = np.radians(h + dh)
    C2 = C * (1 + (p["skin_sat"] - 1) * w_skin * g_skin)
    # pale cools: more colour, but levelled off, so a wall that is bluer in one clip does not come out more saturated
    lim = p["cool_cmax"] * np.tanh(p["cool_gain"] * C / p["cool_cmax"])
    keep = smoothstep(p["cool_lim0"], p["cool_lim1"], C)
    C2 = C2 + w_cool * ((1 - keep) * lim + keep * C - C)
    C2 = C2 * (1 + (p["green_sat"] - 1) * w_green * gate)

    # 2. tone on lightness ---------------------------------------------------
    L2 = np.cbrt(tone(L ** 3, p))
    ratio = L2 / np.maximum(L, 1e-6)
    C2 = C2 * np.minimum(ratio, 4.0) ** p["follow"]

    # 3. skin and warm tones -------------------------------------------------
    # a) warm colours a little lighter. Cool colours are NOT darkened here: the key does that with a soft edge.
    proj = a * np.cos(np.radians(p["warm_axis"])) + b * np.sin(np.radians(p["warm_axis"]))
    lift = np.where(proj < 0, p["warm_lift"] * np.tanh(-p["warm_slope"] * proj / p["warm_lift"]), 0.0)
    L2 = L2 * (1 + lift)
    E = to_enc(L2 ** 3)                                     # grey-equivalent code value, 0..1
    # b) a little more contrast inside skin, around the level skin sits at
    wk = w_skin * g_skin
    dE = E - p["sk_pivot"]
    Es = E + p["sk_lo"] * dE + (p["sk_hi"] - p["sk_lo"]) * (softplus(dE, p["sk_w"]) - softplus(0.0, p["sk_w"]))
    E1 = E + wk * (Es - E)
    # c) soft shoulder for warm tones, pale ones included (a shiny forehead is pale skin)
    ww = w_skin * smoothstep(p["wsh_c0"], p["wsh_c1"], C)
    k, top = p["wsh_knee"], p["wsh_top"]
    Esh = np.where(E1 <= k, E1, k + (top - k) * np.tanh((E1 - k) / (top - k)))
    E2 = E1 + ww * (Esh - E1)
    L3 = np.cbrt(to_lin(E2))
    r1 = np.cbrt(to_lin(E1)) / np.maximum(L2, 1e-6)         # chroma follows the contrast step, not the shoulder,
    C2 = C2 * np.clip(r1, 0.25, 4.0)                        # so highlights keep their colour as they are held down
    C2 = C2 * (1 + p["fill"] * ww * smoothstep(p["fill_from"], p["fill_to"], L))
    L2 = L3

    # 4. saturation by lightness --------------------------------------------
    s = p["sat"] * (1 - p["hi_desat"] * smoothstep(p["hi_from"], p["hi_to"], L2)) \
        * (1 - p["lo_desat"] * (1 - smoothstep(0.0, p["lo_to"], L2)))
    a2, b2 = C2 * s * np.cos(h2), C2 * s * np.sin(h2)

    # 5. split tone ----------------------------------------------------------
    sh = p["sh_tint"] * bump(L2, p["sh_peak"], p["sh_width"]) * (1 - p["sh_skin_protect"] * wk)
    a2 += sh * np.cos(np.radians(p["sh_hue"]))
    b2 += sh * np.sin(np.radians(p["sh_hue"]))
    md = p["mid_tint"] * bump(L2, p["mid_peak"], p["mid_width"]) * np.exp(-(C / p["mid_protect"]) ** 2) \
        * smoothstep(p["mid_warm0"], p["mid_warm1"], proj)
    a2 += md * np.cos(np.radians(p["mid_hue"]))
    b2 += md * np.sin(np.radians(p["mid_hue"]))

    # 6. back to RGB; ease colours that sit near or beyond the sRGB edge back in ---------------------------------
    rgb = oklab_to_lin(np.stack([L2, a2, b2], 1))
    Y = np.clip(rgb @ np.array([0.2126, 0.7152, 0.0722]), 1e-6, 1 - 1e-6)[:, None]
    dlt = rgb - Y
    reach = np.where(dlt < 0, -dlt / Y, dlt / (1 - Y))        # per channel: 1 means it touches 0 or 1
    x = reach.max(axis=1)
    kn = p["gamut_knee"]
    soft = np.where(x <= kn, x, kn + (1 - kn) * np.tanh((x - kn) / (1 - kn)))
    kk = np.where(x <= kn, 1.0, soft / np.maximum(x, 1e-9))
    inside = x <= kn
    rgb = Y + dlt * kk[:, None]
    out = to_enc(np.clip(rgb, 0, 1))

    # 7. toe -----------------------------------------------------------------
    out = out + np.array(p["lift"]) * (1 - out) ** p["lift_pow"]
    return np.clip(out, 0, 1).reshape(enc.shape), float((~inside).mean())


# ------------------------------------------------------------------ the wall key
def key_gain(enc, k=KEY):
    """enc: (..., 3) encoded RGB 0..1 -> gain 0..1 (grey), 1 = leave alone, 1 - depth = pale cool wall"""
    lab = lin_to_oklab(to_lin(enc.reshape(-1, 3).astype(np.float64)))
    L, a, b = lab[:, 0], lab[:, 1], lab[:, 2]
    proj = a * np.cos(np.radians(k["axis"])) + b * np.sin(np.radians(k["axis"]))
    K = smoothstep(k["c0"], k["c1"], proj) * smoothstep(k["l0"], k["l1"], L)
    g = 1 - k["depth"] * K
    return np.repeat(g[:, None], 3, axis=1).reshape(enc.shape)


# ------------------------------------------------------------------ known colours of the footage
KNOWN = [
    ("forehead hot", 253, 220, 204), ("forehead hi", 252, 207, 190), ("ear rim", 244, 184, 151),
    ("cheek lit", 239, 166, 127), ("skin mid", 229, 156, 125), ("skin mean", 218, 152, 124),
    ("skin shadow", 154, 100, 78), ("eye white", 206, 174, 169), ("eye whitest", 200, 190, 188),
    ("teeth", 227, 182, 164), ("teeth bright", 240, 198, 176), ("lips", 212, 119, 119),
    ("hair mid", 67, 61, 64), ("hair grey", 139, 134, 136), ("hair deep", 26, 20, 24),
    ("wall clip1", 165, 185, 190), ("wall clip2", 167, 190, 199), ("wall dark", 148, 166, 169),
    ("wall bright", 177, 200, 211), ("edge mix", 183, 184, 188), ("cabinet", 171, 166, 153),
    ("cabinet dk", 156, 151, 141), ("shirt", 84, 94, 134), ("shirt lit", 98, 107, 149), ("bead", 213, 165, 111),
    ("grey 40", 40, 40, 40), ("grey 128", 128, 128, 128), ("grey 180", 180, 180, 180), ("grey 215", 215, 215, 215),
    ("white", 255, 255, 255),
]


def describe(rgb):
    import colorsys
    r, g, b = [float(v) for v in rgb]
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    hh, s, _ = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    return f"{r:5.1f} {g:5.1f} {b:5.1f}  Y{y:5.1f} h{hh * 360:5.1f} s{s * 100:4.1f}"


def colours():
    src = np.array([k[1:] for k in KNOWN], float) / 255
    out, _ = grade(src)
    gain = key_gain(src)[:, 0]
    for (name, *_), s_, o_, g_ in zip(KNOWN, src * 255, out * 255, gain):
        print(f"  {name:12s} {describe(s_)}   ->   {describe(o_)}   key x{g_:4.2f} -> Y"
              f"{(o_ * g_) @ np.array([0.2126, 0.7152, 0.0722]):5.1f}")


def checks(cube, n):
    """cube[b, g, r, 3]"""
    grey = np.array([cube[i, i, i] for i in range(n)])
    print("grey axis (in -> out, 8-bit):",
          "  ".join(f"{round(i * 255 / (n - 1)):d}>{'/'.join(str(int(round(v * 255))) for v in grey[i])}"
                    for i in range(0, n, 8)))
    luma = grey @ np.array([0.2126, 0.7152, 0.0722])
    print("grey axis monotonic:", bool(np.all(np.diff(luma) > 0)),
          "| largest step %.2f codes per node" % (np.diff(luma).max() * 255))
    g = np.linspace(0, 1, n)
    bb, gg, rr = np.meshgrid(g, g, g, indexing="ij")
    mx, mn = np.maximum(np.maximum(rr, gg), bb), np.minimum(np.minimum(rr, gg), bb)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-9), 0)
    zones = {"whole cube": np.ones_like(sat, bool),
             "footage zone (HSV sat < 65%, max > 6%)": (sat < 0.65) & (mx > 0.06)}
    names = "bgr"
    for zname, zone in zones.items():
        worst, where, back, backmax = 0.0, None, 0, 0.0
        for ax in range(3):                               # kinks: second difference along each axis, in 8-bit codes
            d2 = np.abs(np.diff(cube, n=2, axis=ax)).max(axis=-1)
            sl = [slice(None)] * 3
            sl[ax] = slice(1, -1)
            d2 = np.where(zone[tuple(sl)], d2, 0)
            if d2.max() > worst:
                worst = d2.max()
                i = np.unravel_index(d2.argmax(), d2.shape)
                i = list(i)
                i[ax] += 1
                where = (names[ax], tuple(int(round(v * 255 / (n - 1))) for v in (i[2], i[1], i[0])))
            ch = 2 - ax                                   # folds: a channel going down while its own input goes up
            d1 = np.diff(cube[..., ch], axis=ax)
            sl[ax] = slice(0, -1)
            d1 = np.where(zone[tuple(sl)], d1, 0)
            back += int((d1 < -1e-6).sum())
            backmax = min(backmax, d1.min())
        print(f"{zname}: largest second difference {worst * 255:.2f} codes at rgb {where[1]} along {where[0]}"
              f" | own-channel reversals {back} (deepest {backmax * 255:.2f} codes)")


def write_cube(path, title, cube, n):
    with open(path, "w", encoding="ascii", newline="\n") as f:
        f.write(f'TITLE "{title}"\n')
        f.write(f"LUT_3D_SIZE {n}\nDOMAIN_MIN 0.0 0.0 0.0\nDOMAIN_MAX 1.0 1.0 1.0\n")
        np.savetxt(f, cube.reshape(-1, 3), fmt="%.6f")


def grid(n):
    g = np.linspace(0, 1, n)
    bb, gg, rr = np.meshgrid(g, g, g, indexing="ij")       # blue slowest, red fastest: the .cube order
    return np.stack([rr, gg, bb], -1)


def main():
    if "--colours" in sys.argv:
        colours()
        return
    cube, outside = grade(grid(N))
    write_cube(os.path.join(HERE, NAME), "filmic look", cube, N)
    print(f"wrote {NAME}  ({N}^3 nodes, {outside * 100:.1f}% of them past the gamut knee: the saturated outer cube)")
    checks(cube, N)
    kc = key_gain(grid(KEY_N))
    write_cube(os.path.join(HERE, KEY_NAME), "filmic wall key", kc, KEY_N)
    print(f"wrote {KEY_NAME}  ({KEY_N}^3 nodes, gain {kc.min():.3f}..{kc.max():.3f})")
    colours()


if __name__ == "__main__":
    main()
