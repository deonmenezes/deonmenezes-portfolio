"""sfx.py - a few quiet sound effects under the voice. Deon asked for "sound effects a little bit" (2026-10-10).

    python sfx.py            reads sfx.json + mix_voice.wav (a copy of the voice-only mix), writes mix.wav
    python sfx.py --solo     also writes sfx_only.wav, the effects without the voice, to check them

sfx.json is a list of {"t": ORIGINAL seconds, "kind": "whip" | "land" | "tick" | "type" | "count", "note": ...}.
Times go through timemap.T, like everything else in the edit. Two "count" entries in a row are the start and the
end of a counter: soft ticks run between them. Every sound is synthesised here (no sample files), deterministic,
and peaks about 18 dB or more under the voice's peaks. Run it from the edit folder, after `python vk.py mix --voice`.
"""
import json, os, shutil, sys

sys.path.insert(0, "~/.claude/skills/video-edit/scripts")
import numpy as np
import soundfile as sf
from timemap import T

SR = 48000
LEVEL = {"whip": -21.0, "land": -19.0, "tick": -26.0, "type": -27.0, "count": -31.0}   # peak dBFS per kind
rng = np.random.default_rng(7)


def db(x):
    return 10 ** (x / 20)


def bandpass(x, f0, q=1.2):
    """one resonant band-pass per sample block; f0 may be an array the length of x (a sweep)"""
    f0 = np.broadcast_to(np.asarray(f0, float), x.shape)
    y = np.zeros_like(x)
    lp = bp = 0.0
    for i in range(len(x)):                       # state-variable filter, cheap and stable at these lengths
        f = 2 * np.sin(np.pi * min(f0[i], SR / 6.5) / SR)
        hp = x[i] - lp - bp / q
        bp += f * hp
        lp += f * bp
        y[i] = bp
    return y


def norm(x, peak_db):
    m = np.abs(x).max()
    return x / m * db(peak_db) if m else x


def whip(n=int(0.24 * SR)):
    t = np.linspace(0, 1, n)
    x = bandpass(rng.standard_normal(n), 500 + 3200 * t ** 1.6, q=1.6)
    return norm(x * np.sin(np.pi * t) ** 2.2, LEVEL["whip"])


def land(n=int(0.16 * SR)):
    t = np.arange(n) / SR
    f = 150 * np.exp(-t * 9) + 62                      # a soft thud that drops in pitch...
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 26)
    tap = bandpass(rng.standard_normal(n), 700, q=1.4) * np.exp(-t * 70)      # ...and a paper tap a phone speaker
    x = x + 0.55 * tap / (np.abs(tap).max() + 1e-9)                           # can actually reproduce
    return norm(x * np.minimum(1, t / 0.002), LEVEL["land"])


def tick(freq=2100, level="tick", n=int(0.03 * SR)):
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * freq * t) * np.exp(-t * 190)
    return norm(x * np.minimum(1, t / 0.0008), LEVEL[level])


def key(n=int(0.045 * SR)):
    t = np.arange(n) / SR
    click = bandpass(rng.standard_normal(n), 2600 + rng.uniform(-400, 400), q=2.0) * np.exp(-t * 260)
    body = np.sin(2 * np.pi * (210 + rng.uniform(-20, 20)) * t) * np.exp(-t * 120) * 0.5
    return norm(click + body, LEVEL["type"] + rng.uniform(-1.5, 0.5))


def main():
    if not os.path.exists("mix_voice.wav"):
        shutil.copyfile("mix.wav", "mix_voice.wav")       # first run: keep the voice-only mix
    voice, sr = sf.read("mix_voice.wav", always_2d=True)
    assert sr == SR, sr
    cues = sorted(json.load(open("sfx.json", encoding="utf-8")), key=lambda c: c["t"])
    bed = np.zeros(len(voice))

    def put(x, t_new, pan=None):
        i = int(round(t_new * SR))
        if 0 <= i < len(bed):
            x = x[: len(bed) - i]
            bed[i:i + len(x)] += x

    pending = None
    used = {}
    for c in cues:
        k, t = c["kind"], T(float(c["t"]))
        used[k] = used.get(k, 0) + 1
        if k == "whip":
            put(whip(), t - 0.10)                          # the body of the whoosh sits on the move itself
        elif k == "land":
            put(land(), t)
        elif k == "type":
            put(key(), t)
        elif k == "count":
            if pending is None:
                pending = t
            else:                                          # ticks from the start to the end, speeding up a little
                a, b, n = pending, t, max(4, int((t - pending) * 16))
                for j in range(n):
                    u = j / (n - 1)
                    put(tick(freq=1500 + 900 * u, level="count"), a + (b - a) * u ** 0.85)
                put(tick(freq=2600, level="tick"), b)      # the last one is a touch brighter: it has arrived
                pending = None
        else:
            put(tick(), t)
    out = voice + bed[:, None]
    peak = np.abs(out).max()
    if peak > db(-1.5):
        out *= db(-1.5) / peak
    sf.write("mix.wav", out, SR, subtype="PCM_16")
    if "--solo" in sys.argv:
        sf.write("sfx_only.wav", np.repeat(bed[:, None], 2, axis=1), SR, subtype="PCM_16")
    print(f"{len(cues)} cues {used} -> mix.wav  (effects peak {20 * np.log10(np.abs(bed).max() + 1e-12):.1f} dBFS, "
          f"mix peak {20 * np.log10(np.abs(out).max()):.1f} dBFS)")


if __name__ == "__main__":
    main()
