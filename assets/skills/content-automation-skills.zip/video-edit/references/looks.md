# Looks: what he asks for, and how each one is built

Pick the look from his words, then the lane follows. Two lanes exist because one clip cannot be both untouched
and re-composited:

- **compose lane** (`compose.py`): cut, captioned, split, animated. Output 1080x1920 H.264 SDR. An HLG clip is
  tonemapped. This is the lane for almost everything.
- **overlay lane** (`overlay.py`): the clip exactly as shot, HLG kept, audio copied, with PNG cards switched on
  and off on his own jump cuts. No cutting, no captions, no motion.

Each look names the folder it was last built in. Those folders are the living reference: open them to see a
finished example. If one is gone, the tools in this skill are enough.

## 1. Clean cut

*"cut the silences", "tighten this", "remove the fillers", "add captions".*

Compose lane, empty `SEGMENTS`. `edl pauses` -> `edl retakes` -> `edl apply` -> `edl verify` -> `captions` ->
`mix --voice` -> `compose`. A 7% punch-in on every other splice hides the jump. This is also the base of looks 3-5.

## 2. Sources on hard cuts

*"add sources on what I'm saying", "from major outlets, BBC etc", "don't over edit", "just plain screenshots".*

Overlay lane. Last built: `<your-folder>/sources-edit` (2026-10-04).

1. `python vk.py probe --jumpcuts` gives the frames where he cut. A card lives from one jump cut to the next.
2. Researcher: one real article per claim -> `jobs.json` -> `shots` -> `cards`.
3. `overlay.json`: `{"png": "cards/x.png", "f": [224, 270], "y": 254}` per card, then `overlay preview`.
4. `overlay render`, `qc`.

No animation, no sound, no captions, no titles of our own. The one exception he asked for is the call to action:
`cards --text cta "COMMENT" "“PROBLEM”"` at about y=325.
`npl` 700 keeps card white just under his burned-in captions; at 203 the cards look grey beside them.
A recorded-webpage panel that slides in (he asked for that once, for "I made a website") is in
`<your-folder>/sources-edit/web_anim.py` + `build.py`; it is not part of `overlay.py`.

## 3. Split-screen explainers

*"split screen when showing animations", "don't put it in overlay", "explain things".*

Compose lane, `kind="split"`. Last built: `<your-folder>/split-edit` (2026-10-03).

The talking head slides down 540 px and an opaque 1080x960 panel slides in from the top over 0.3 s. Nothing is
scaled: the visible part of him shrinks by exactly the panel height. Back-to-back panels stay split and dissolve
into each other. Captions move up to y=1045, just under the seam.

Each panel is a scene in `anim.html`, and each one says what its term means in one plain sentence: a `term`
scene is nothing but that, a `list` carries it as a strip along the bottom, a `stat` says what the number counts
and where it is from. `ev` times are the seconds he says the words, so the panel reacts to him.

## 4. A graphic on every line

*"show graphics for everything I say", "even when I talk about myself".*

Compose lane, `kind="card"` and `kind="anim"` over the full frame, with `dim` so the card reads over him.
Last built: `<your-folder>/latest-edit` (2026-10-02), before that `<your-folder>/yc-edit`.

Cards are real screenshots (`shots` in `"mode": "view"`, then `round=30` in the plan) or real tweets (`tweet`).
In `plan.py` a card's `x`, `y` are its centre (`top=` places it by its top edge instead).
`<your-folder>/latest-edit/build.py` also has a phone mock that scrolls a page and a picture-in-picture clip; copy those
functions out if he asks for them again.

## 5. Cinematic B-roll

*"add B-roll", "cinematic filter", "put music low".*

Compose lane, `kind="broll"`. Last built: `<your-folder>/dedg-edit` (2026-09-28).

Photos get a slow push (`z=(1.05, 1.15)`), video clips play from `start=`. His voice carries on underneath.
The grade, in `plan.py` (one line):

    FINISH = "eq=contrast=1.06:saturation=0.92:gamma=0.97,colorbalance=rs=-0.05:gs=-0.01:bs=0.07:rm=0.02:bm=-0.02:rh=0.07:gh=0.02:bh=-0.06,curves=all='0/0.02 0.25/0.22 0.75/0.79 1/0.97',vignette=angle=PI/4.5,noise=c0s=5:c0f=t+u"

Teal shadows, warm highlights, a soft vignette and fine grain. It is applied under the captions so grain never
touches the text, and `compose --stills` shows it. Music: `mix --music <file> --start <s>` (levelled 12 dB under
his voice; `--under 15` for quieter). This is the only look with music by default, and only because he asked for
it by name that day.

**Choosing the song: `<your-folder>/reference-library` (2026-10-20).** He asked for a reference library of songs by vibe (after
@maxcreates.mp4's "My most used viral songs based on vibe" reel), downloaded ahead of time. Pick from its README
table by what the reel is about (motivational, storytelling, hopeful, happy, dramatic, dreamy, dark, cinematic,
nostalgic, sport) and start at the song's "Best 15 s from" in `CATALOG.md`, or line a visual hit up with "Lands at".
Only the Pixabay sport tracks are licensed for posting; for the commercial songs, say in the delivery note that he
should pick the same song in Instagram's music library when posting, or the reel may be muted.

B-roll must be about the thing he is saying. His Google Photos are family pictures and not promo material; for an
event, use the organiser's own images or clip.

## 6. Real tweets and a cut-in clip

*"show the tweet", "show him saying it".*

`tweet name=<id>` for the card. For a clip of someone actually saying the line, `yt-dlp` the public video, crop to
the speaker over a blurred fill, add a source label, splice it after his sentence. Worked example:
`<your-folder>/trump-edit/insert.sh` (2026-09-30). That reel also inpainted old burned-in captions
(`build.py strip_old_captions`) because he wanted new ones on top.

## 7. The filmic grade on his picture (the one he asked to keep)

*"the filter is too bright, I want it like a professional", "use the same colour grading as that reel", "the grade".*

His words on 2026-10-11, after one reel's v2: "ok remeber the gradeint and coloring and whatever is done". Use
this as the default grade on his talking-head picture unless he asks for another. Everything is in
`~/.claude/skills/video-edit/assets/grade-filmic/` (cubes, `build.py`, his `reference.png`, `before-after.png`).

Copy both cubes into the edit folder (ffmpeg resolves the bare names from there), then in `plan.py`:

    GRADE = ("format=gbrp16le,split[fl_a][fl_k];"
             "[fl_k]scale=iw/2:ih/2:flags=area,lut3d=file=filmic_key.cube:interp=tetrahedral,erosion,erosion,"
             "gblur=sigma=2,scale=iw*2:ih*2:flags=bilinear[fl_g];"
             "[fl_a]lut3d=file=filmic_look.cube:interp=tetrahedral[fl_l];"
             "[fl_l][fl_g]blend=all_mode=multiply")

What it does, measured on the test clip (iPhone HLG, tonemapped by compose): exposure down 0.9 stop with filmic
contrast and a soft shoulder (nothing clips, white lands near 222), skin luma about 130 instead of the 170 he called
too bright, skin a natural warm brown (hue 22), a slight teal in the shadows, blacks lifted to about 9. The key cube
finds the pale blue glass wall of his room and darkens it 18%, so his face is the brightest thing in frame.

- `filmic_look.cube` works on any footage. `filmic_key.cube` is tuned to THAT wall (pale, cool). On another
  background it selects little or nothing, which is harmless; if it grabs something wrong, drop the key and use
  only `GRADE = "lut3d=file=filmic_look.cube:interp=tetrahedral"`.
- The key must stay half-size + two erosions + sigma 2. Quarter-size with a wider blur left a pale glow round his ears.
- Brighter or darker: `P["ev"]` in `build.py` (-0.90 delivered, -0.80 brighter), run it, copy the cubes again.
  If he says "flat", raise saturation (`P["sat"]`), not exposure: his reference is more saturated, not darker.
- Check with `compose --stills` at a light panel and a dark panel before the full render.
- The older Sony-style chain (curves + colorbalance + unsharp) is the one he called too bright. Do not reuse it.

The sound effects that went with it: `assets/sfx.py` (copy into the edit folder, cue list `sfx.json`, example in
`assets/sfx.example.json`). Quiet synthesised whips, landings, ticks, typing and counters, peaks -19 dBFS or lower.

## Not this skill

| he says | use |
| --- | --- |
| "edit it like the reference", "copy this reel" | `reference-reel-edit` |
| "write the script", a narrated long-form YouTube video | `youtube-script`, then the pipeline in `<your-folder>/religion-video` |
| "post it", "upload to insta/tiktok/youtube/x" | `post-video`, after he has said to ship |
| "will it go viral" | `viral-project` |
