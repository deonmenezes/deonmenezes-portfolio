# House style: how Deon wants his videos edited

Every agent reads this before touching an edit. It is to this skill what `voice.md` is to a writing skill: the
rules that are his, learned from his own corrections. Each rule carries the date he said it, because later
instructions beat earlier ones and his ask for THIS video beats all of them.

When a rule here and his words today disagree, do what he said today, and tell the lead so this file gets updated.

## Defaults when he has not said otherwise

| thing | default | where it comes from |
| --- | --- | --- |
| Music | **None. Voice only.** | He had the music taken back out of the Trump reel (2026-09-30) and the startup reel (2026-10-02). |
| Sound effects | **None.** No whooshes, pops or clicks. | "NO sound effects" (2026-09-29), "dont put any sound effects or transitions" (2026-10-04). |
| Transitions | **Hard cuts.** No light leaks, wipes or zoom blurs. | Same two messages. |
| Pauses, fillers, repeated takes | Cut them. | "remove any silences or fillers or if it doesn't make the script or is repeated" (2026-10-03). |
| A line said twice | **Keep the second take.** | "the second one will sound better" (2026-10-03). |
| How much editing | Less. Leave room for him. | "don't over edit it" (2026-10-04); "keep everything else simplistic, he edits the rest himself" (2026-09-14). |
| Finished file | `<your-folder>/<Title> - edited.mp4` and Drive "Video edits of myself" | "it should be in video edits of myself" (2026-10-03). `deliver.py` does both. |

**Tight heads, clean sound, every time.** "0.1 second before me opening my mouth, that's when you should actually
start the cut, instead of like 5 seconds or 2 seconds me adjusting the camera then opening my mouth ... not like the
last video we have posted, because it was bad in cutting ... That's why the attention span also reduced
drastically", and "make sure that there is no noise in the background, and if there is, the noise is removed"
(2026-10-15). A talking segment starts 0.10 s before his lips part and ends 0.15-0.40 s after his last sound; his
dialogue is denoised when the floor is above -55 dBFS. The content checker (`agents/content-check.md`) enforces it.
**Then tighter than that between his sentences.** On the Roadster reel (2026-10-16) the 0.15-0.40 s tails read as
dead air to him: "How it works then pause remove that too / 2 times pause remove that / Downforce pause remove that
too / Ever pause remove thqt too / Walls pause remove that / Gravity pause rmeive that / Bigs ups then the pause
remove that too". What he accepted: about 0.06 s kept after the last voiced frame and 0.08-0.10 s before the next
word, every pause of 0.3 s or more, mid-sentence ones included (`TIGHT` rows in <your-folder>/oct16-edit/edl.txt). Use that as
the default join; the 0.10 s head before his first word after a camera restart still stands.

**Montage music: properly aesthetic.** He sent M83 "Outro" back on the life-after-AI montage: "find a new music, man.
It's time you find like something aesthetic" (2026-10-15). Used instead: øneheart x reidenshi "snowfall" (the drop
at 19.63 s timed onto the first reveal). A lifestyle montage keeps its clips' natural sound (waves, wind) under it.

**Footage shot landscape stays landscape.** "Us should keep the video horizontal" (2026-10-13, on the Goa
local-businesses reel, whose selfie takes and interviews were filmed horizontally; the first delivery cropped them
to 9:16 and he sent it back). Read the orientation of the talking clips off the scout, not off the folder name
("Intro reel") or the platform: horizontal talking clips mean a 1920x1080 edit, with vertical B-roll cropped to fit.

**Louder than -14, voices in front.** "Also voice is low keep it loud" (2026-10-13, Goa local-businesses reel,
about a `mix --voice` track at -14.5 LUFS with peaks at -4.4 dBTP). Then, after a -10.6 LUFS version with M83
10 dB under the voice: "Volume high", and when asked which volume: "Voices". What was delivered: music mixed
15 dB under the voice (`mix --music ... --under 15`), then `<your-folder>/local-biz-h-edit/loud.py` (a 2 dB presence lift
at 3.2 kHz, gain, limiter just under -1 dBTP) to about -9.7 LUFS. That is the practical ceiling on a cleaned-up
noisy room: more compression or gain lifted the room in the pauses as much as the voice. `qc.py` still fails
anything louder than -12.5 LUFS: that one FAIL line is then expected, say so, and deliver with a hash-checked
copy instead of `deliver.py`. He said it about one reel; treating it as his default is the lead's reading.

If he does ask for music: low, about 12 dB under his voice, ducked while he speaks, faded at both ends. He has
picked M83 "Outro", Zimmer "Time" and Soap&Skin "Me and the Devil" (`<your-folder>/muse-carousel/music/track.wav`, used 2026-10-09 at 12 dB under) before. Then expect "reduce the music a little".

## What goes on screen

**Real beats designed.** He called designed quote cards "so vibe coded" (2026-09-29). A claim is backed by a real
screenshot of a real article with the exact sentence highlighted, or a real tweet, never by a card we typed up.
Designed panels are for explaining a term or showing how something works, where no screenshot exists.

**How much graphic depends on what he asked for. Read his words, do not average them:**

- "add sources on whatever I'm saying ... don't over edit ... no titles should pop up by your own thing"
  (2026-10-04) -> plain source cards on his own jump cuts, nothing else, one pop-up at the call to action.
- "make sure all graphics information is displayed even when I say things about myself" (2026-10-02) -> when he
  wants graphics, EVERY spoken claim gets one, including the intro about himself, not only the "tips".
- "split screen when showing animations, dont put it in overlay, and explain things" (2026-10-03) -> animations
  get their own half of the screen instead of covering him, and each panel says what the term means. (He had not
  reviewed that result when this was written, so treat it as his instruction, not yet as his approval.)

- "u should [make] some better graphics and quality like instagram comments actually being automated instead of
  the skill command only, show like actual animations" (2026-10-07, on the Instagram reel) -> a panel SHOWS the
  thing happening in the product's own interface: a comment being typed and landing under a post, replies
  appearing down a thread, a calendar filling with posts, a DM arriving. A slash command in a box with a
  definition under it reads as a slide to him. The command can stay as a small label; the animation is the panel.

- "https://youtu.be/yJBETduh0WM animations liek this would be better ... and the automation of muse website"
  (2026-10-07, on the Muse reel) -> the panels are CARTOON animation in the style of Agent Flappy's "Napoleonic
  Wars" explainer: thick black outlines, flat-colour round-headed characters with stick limbs and big expressions,
  painted backgrounds, heavy rounded white lettering with a dark outline, speech bubbles, a recurring mascot that
  does the work. The product's own interface still appears inside the cartoon, doing the task. Built in
  `<your-folder>/oct07b-edit/anim.html` (character rig `muse()`, a `FACTS` block for every claim on screen; reference frames
  in `ref/`). He had not reviewed that result when this was written: his instruction, not yet his approval.

- "edit the ideo nicely and authentically" then "keep the animations clean nice smooth like apple" (2026-10-09, on
  the "It's time to build your company" talk) -> a few split panels only (four on a 92 s talk), restyled away from
  the house palette: flat black, Segoe UI Variable sans, one blue accent (#2997FF), green only for a done state,
  hairline borders, slow ease-out motion with no bounce, `SEAM = None`. The hook, the emotional lines and the ending
  stay bare; no pop-ups of our own. Apple-style scene helpers are in `<your-folder>/honest-edit/anim.html`. He had not reviewed
  that result when this was written: his instruction, not yet his approval.

- "/clean-explainer-style can u edit the latest video ... with the style" then "add like a good color grading like it
  looks its shot from a sony a7 camera" (2026-10-10, on one reel) -> split screen from first frame to last with
  the panels built from the `clean-explainer-style` kit at 1080x960, the style's own captions drawn inside the panel
  (word times passed through each segment's `ev`, `captions --none`), `SEAM = None`, and a Sony-style GRADE (curves
  with a soft shoulder, warm skin, cool shadows, light unsharp). Built in `<your-folder>/<project>`. He had not reviewed that
  result when this was written: his instruction, not yet his approval.

- "the captions or on the top not on the center or where it is readivble so please fix that ... look at the reference
  video man it just loook amazing 3 dcards proper light mechanics paper style explainere videos sounde ffects al ittle
  bit" (2026-10-10, on the first render) -> in a split-screen build of the clean-explainer look, captions go in
  the BOTTOM band of the panel (centre of the finished frame), never at the top of the panel; cards and objects are
  staged in 3D with one light direction, moving shadows and sheen, glow on dark, paper grain and sheets on light; and
  a FEW quiet sound effects are wanted with this look (whips, landings, typing, counters: `<your-folder>/<project>/sfx.py`).
  This overrides "no sound effects" for this look only.

- "also the filter it is too brigh i want it be like professional like a professiona lway" with a LOG / REC 709 /
  GRADE reference image (2026-10-10), then after v2 "ok remeber the gradeint and coloring and whatever is done"
  (2026-10-11) -> the grade on his picture is the filmic LUT in `assets/grade-filmic/` (looks.md section 7): darker,
  filmic contrast, natural brown skin, the wall pulled down to a darker teal. It replaces the Sony-style chain.
  Together with the centre-band captions, 3D lit panels and quiet effects above, this is the v2 recipe to repeat.
  He said to remember it right after v2 was delivered; that he had watched v2 first is my assumption.

- "use the voice over folder but only for audio dont include talkjng head ... a short compilation of hi i am ... coffee
  shop owner should show coffee shop etc from goa maybe get an image and make it amazing", then a Huckberry DIRT
  episode as the theme and "artistic documentary captions style like netflix documentaries", "short form video"
  (2026-10-13/14, Goa local-businesses video) -> a documentary cut: voice-over as sound only under B-roll, a run of
  "My name is ..." with big name supers, a distressed bold-caps title card, category supers from his own voice-over
  words, name + role lower-thirds on the speaker's side of the frame, free-licence stills for the businesses, a
  cooler flatter grade, and phrase subtitles (clean sans, soft shadow, 110 ms fade, the key word in italic serif)
  in place of the yellow follow-along captions. Built in `<your-folder>/<project>` (`layout.py`). He had not reviewed that
  result when this was written: his instruction, not yet his approval. QC lesson from it: a `kind="card"` segment
  fades out for 0.12 s AFTER its end time, so end every card 0.14 s before the cut or it lands on the next person.

- "let them complete their sentences of interviewers before cutting to next scene", then, when the lines were run on
  to their full sentences: "No dont run it through the pause stop it on the pause. Lets keep the video short"
  (2026-10-14, same video) -> an interview line ends at the end of its clause and the out-point sits about 0.3 s
  INTO the speaker's own pause after it: the cut lands on the pause, not on the last syllable, and not after the
  next sentence. Keep `edl pauses` from trimming those holds. Do not answer "complete their sentences" by making
  the bites longer.

- "u need to shorten the video more u need to start i nam stressed [the giveaway line] as
  the title and the captiosn need to be bigger under the video and one owrd at a tiem" (2026-10-15, a documentary
  short, v6) -> on that video the phrase subtitles became ONE word per caption, big (Segoe UI Black 120 of 1080, key words
  in Georgia italic), bottom centre, each word shown from its start to the next word's start; a cold open on the
  strongest problem line, then the title card; 89.6 s cut to 60.6 s. Built in `<your-folder>/<project>/layout.py`. Word
  stamps stretched over a stutter put words up to 0.7 s early: hand-time those (`CUT_STARTS`) from audio onsets.

- "re edit the documentary to be shorter and better understanding in a short form", "like 25 seconds", "start with a
  problem", "flash all founders", "make it awesome" (2026-10-20, the same documentary v7, for
  LinkedIn) -> a 25 s story in five beats: problem lines on the owners' own picture under a small "THE PROBLEM" super,
  the title over the giveaway line, a thank-you card over the partners' logos, every founder's
  face on the music's beat (faster each bar, one shutter click each) ending in a grid with one line of text, and the
  close. Every spoken line captioned (sound-off viewers). The music is cut to the beat and ends on the song's own last
  hit, not a fade (`<your-folder>/<project>/_v7_run/plan_beats.py`, `music_edit.py`). He had not reviewed it when this was written.
  His feedback the same day: "it should have the we are giving away" (present tense on the title, not WE GAVE AWAY) and
  "and have the riser suspense music in the beginning" -> a riser under the problem lines that lands on a hit as the
  title appears, then the music bed. Built without samples in `<your-folder>/<project>/riser.py` (licence-free), added after
  `mix`, kept 12-24 dB under the voices. This overrides "no sound effects" for this kind of short. Not yet reviewed.

- "Crop half way show the flying car first shot etc.." (2026-10-16, Tesla Roadster explainer) -> news-event footage
  goes in a SPLIT SCREEN, the real event clip playing in the top 1080x960 panel and him in the bottom half, the most
  striking shot (the car flying) from frame 0; between panels he is full frame. Real clips, not designed panels: the
  frames are cut by `<your-folder>/oct16-edit/broll/frame.py` into `broll/panels/<name>/` and drawn by a `clip` scene in
  `anim.html` (copy both for the next one). He had not reviewed that result when this was written.

**He is the highlight.** Cards sit over his hair and forehead (top edge around y=250-280 of 1920) and his eyes stay
visible. Never park a graphic over his face for a whole sentence unless the screen is split.

**Text.**
- **Default caption/text font since 2026-10-19: the heavy rounded sans from his reference** ("What is this font style
  i like it, put it for all of our editing in future", with a screenshot of white lowercase "indie music is" over
  footage; `assets/fonts/rounded-caption-reference.jpg`). It is an Arial Rounded MT Bold-style geometric rounded
  sans. Free match on this PC: **Varela Round** (`assets/fonts/VarelaRound-Regular.ttf`) drawn with a white stroke of
  about 4% of the font size to reach the heavy weight (80 px -> 3 px), or **Fredoka** at wght 700
  (`assets/fonts/Fredoka.ttf`, variable: axes [Weight 300-700, Width 75-125]). Side-by-side: `rounded-caption-match.png`.
  Look: white fill, lowercase as spoken, tight letter spacing, NO black outline, a soft dark drop shadow/glow
  (blurred, ~35-50% black) so it reads on light footage, centred in the middle band of the frame. This replaces the
  Times New Roman Bold default below for captions, pop-ups and titles unless a look (e.g. paper-scrap, a reference
  reel) brings its own type. The follow-along highlight still applies (spoken word yellow) unless he says otherwise.
- **Two-font title pairs, Instagram Edits style (2026-10-20).** He sent three @trainwithcharan reel screenshots and
  said "Use the combination of these two fonts styles in skill file of creating video with fonts". Each is one huge
  display word plus a contrasting accent word, sitting upper-middle over the footage (references:
  `assets/fonts/title-pairs/ref-*.jpg`). Built by `scripts/title_pair.py` as a transparent PNG, placed in plan.py as
  `dict(t=(a, b), kind="card", png="titles/t1.png", y=500, maxw=1080, maxh=1920)` (keep `maxw=1080`).
  - `magari`: small thin lowercase word ("sunflower", Quicksand Light) over a giant condensed high-contrast serif in
    capitals ("MAGARI", Bodoni Moda Black at optical size 6, squeezed to 92% of the width). Both white. Elegant.
  - `airone`: ultra-wide heavy sans in capitals ("AIRONE", Unbounded Black, white) with a handwritten script word
    ("Charli", Nothing You Could Do) in deep green #3B5E48 crossing its lower half. On dark footage pass a lighter
    accent, e.g. `--accent-color 9FD3A8`, or it disappears.
  - `tallica`: very tall condensed sans in capitals ("TALLICA", Antonio stretched) with red scratchy pen capitals
    ("THINKER", Shadows Into Light, #E3201B) crossing its middle at a slight upward angle. Loud.
  The IG Edits fonts are not downloadable; these free matches were picked by eye against the screenshots (side-by-side
  check 2026-10-20). Use a pair for the hook or a section title, one word per side (BIG is the word he stresses, ACCENT
  the second word or the topic); not for running captions, which stay the rounded default. Check every title with
  `--preview <still> --y <y>` before a render: it must sit over his hair/forehead, never his eyes. He had not seen a
  finished edit with them when this was written.
- Older default (2026-09-14 to 2026-10-18): Times New Roman Bold. White fill, thick black stroke, soft shadow.
- Captions: 2-3 words at a time, on his chest (y=1390 of 1920), a quick spring-in.
- **Follow-along yellow, not orange keywords.** "keep like a yellow follow along caption which wordi say turns yellow
  instead of oragne things" (2026-10-09, on the browser-games reel). The word he is saying is yellow, the rest of the
  caption white, and no accent words. Set `"follow": true` in `captions.json` (yellow FFE600). He said it about that
  reel; "keep" reads as "from now on" to the lead, so use it by default until he says otherwise.
- Big pop-ups: upper-middle (y about 680), over hair and forehead. **Never at the very top**: "people don't tend
  to see it" there. Pop in, hold on the spoken words, shrink away. Two lines is the limit ("TOP 3" over "FEATURES").
- Captions say exactly what he said. Fix what the transcriber misheard; never tidy his wording.
- If the clip already has captions burned in (look at `sheet.png`), do not add a second set.
- Matching someone else's reel uses that reel's fonts instead: that is the `reference-reel-edit` skill.

## Facts

Nothing on screen may claim more than he said or a source shows. No invented numbers, ever.

Keep a short list here of facts about you that you have confirmed and that may be shown as written. Nothing else
about you goes on screen.

When his script says more than the source supports, keep the graphics to what is true and tell him plainly. It has
happened: he said Claude "can run the entire YouTube account" about a repo whose README says it does not publish.

A tweet or article must be about the thing he is saying, not about a neighbouring topic by the right person. He
rejected a real Elon Musk tweet for exactly that (2026-09-30).

## Things the transcriber gets wrong in his voice

| he says | it writes |
| --- | --- |
| banger | bagged, bagger, banged |
| Claude Code | your core |
| Claude | flawed (seen 2026-10-09) |
| a line after pauses were cut | extra words with zero-length stamps ("But I'm... I'm glad", "Then... You will be better than"): check with `edl listen` on the original, repair `words_cut.json` by hand, keep the raw copy |
| ElevenLabs | 11 labs, Eleven labs |
| DMs | podiums (seen once) |
| Claude just killed (clip starts on the word) | Not just skill, You all just kill |
| 11,000 | "11" and ",000" as two words: join them (`["11", "000", "11,000"]`) |
| a closing question | the same question written twice with zero-length stamps (2026-10-09): he says it once; repair `words_cut.json` by hand and run `qc` without `--asr` |

Put these in `captions.json` under `fix` / `join`. Add new ones here when you meet them.

## The call to action

His reels end on "comment <word>". The word gets a pop-up or a panel. The comment-to-DM automation behind it is set
up when the reel is posted, not here: put the word in your report so the lead can pass it on.

## Long-form YouTube (channel "Deon Does Research")

- Every technical term is defined out loud the moment it appears, and shown as a definition card.
- One voice from start to finish. Narration scripts go through the `youtube-script` skill and its linter first.
- Fact-check before any voice is generated: re-voicing costs a full pass of credits.
- Flat motion graphics read as "vibe coded" to him. Real footage, real screenshots and real quotes first.

## When he says something that is not so

Say what is true, kindly, with the evidence. "Remove the filter in the video" (2026-10-04): there was none, the
untouched frames were bit-identical to the source, and he took it back a few minutes later.

**Rounded captions, how they are built (2026-10-19).** `captions.py` still writes Times New Roman; `<project>/restyle.py` turns captions.ass into the rounded look (Varela Round, 4% white stroke, follow colour on fill and stroke, blurred shadow on its own layer). The font is not installed on this PC (a per-user install is not seen by libass's DirectWrite provider), so copy `assets/fonts/VarelaRound-Regular.ttf` into `<edit>/fonts/`: compose passes `fontsdir=fonts` when that folder exists. A close selfie (face filling the frame) needs `SHIFT = 280` in plan.py for split screen, or the default slide pushes his mouth off the bottom.

**Interviews: no punch-ins, and the guest's fillers go too (2026-10-20, a sit-down interview).** "dont zoom into [the guest's]
face keep it like overall video" -> a sit-down interview stays on the wide two-shot the whole way; no 1.5x punch-ins on
the speaker (the skill's PUNCH default does not apply to interviews). "remove all the eehhh aahhh by [the guest] too" ->
the guest's hesitations are cut like his. Whisper will not write them, even with a filler prompt, and most of what
sounds like "eehh" is a held vowel at the end of a word ("aaand", "AI~", "source~", "parties~"): cutting the whole
sound clips the word (probes turned "security" into "safety"). What worked: find steady voiced runs (low spectral
flux, >= 0.2 s) in kept speech, `edl probe` the middle of each, and remove only the middle (keep ~0.10 s at the
front and ~0.08 s at the end of the vowel) as a DRAG row; a real standalone "uh" goes whole. 

**Sources move; no static highlight cards (2026-10-22, PHP-hacked reel).** "the news archive highlights aren't it, you
need to make something better like /match-cut or liquid glass graph or push crop animations". Real sources still, but
in motion, landing on the spoken word: match-cut (the real page text full frame, the key word in a red box at one fixed
spot, hard cuts between pages that share the word, punch-in on the word, out in 4 frames), push/crop (the real page as
a card over his hair pushes in over 7 frames and crops to the key phrase on the word; everything else on the page fades
to the page colour), shutter-strike stacks for a run of names, and frosted liquid-glass panels for numbers and version
lists (bars fill on the words). Capture the pages clean, no <mark>: <your-folder>/php-edit/fx_grab.py takes the phrase boxes from
Range.getClientRects() and retries wider viewports until the phrase is one line. The effects are <your-folder>/php-edit/fx.py,
drawn on every frame by compose_fx.py (compose with a render hook; captions still burn on top). Plain highlight cards
only as a fallback.
