# This machine, and the traps already paid for

## The render lane

This PC corrupts memory (blue screens, flipped bits in files; 19 unclean shutdowns between 2026-09-09 and
2026-10-05, BIOS still the 2022 launch version). Two rules follow, and the tools enforce both:

1. **One heavy job at a time, on a few threads, at below-normal priority.** Transcribing (`transcribe`,
   `edl verify/probe/listen`, `qc --asr`), rendering animation frames, `compose`, `overlay`, `mix`, `qc` and
   `probe --jumpcuts` all take `~/.claude/video-edit-lane.lock` first. A second caller, in any agent or any
   session, prints `[lane] waiting: pid ...` and waits. So agents may work in parallel; their heavy steps queue by
   themselves. Never start a raw `ffmpeg` encode or a whisper run outside the tools.
   Not queued, because they are light or short: `new_project`, `edl pauses/retakes/apply`, `captions`, `cards`,
   and the browser tools (`shots`, `tweet`, `search`), which is why there is only ever one researcher.
2. **A copy only counts when its hash matches.** `new_project.py` and `deliver.py` read every copy back.

If the lane seems stuck: `cat ~/.claude/video-edit-lane.lock` shows the pid and the job. A lock left by a dead
process is taken over automatically. Do not delete it while that pid is alive, and never kill by process name
(`taskkill /IM python.exe` would take down CrossPost, the inbox hub and the MCP servers): kill your own job by its
exact pid.

Tell Deon before starting anything that will load the machine for more than a few minutes. A 45 s reel is about a
minute of transcription and two to three minutes of rendering in total.

## Source footage

- iPhone reels: 1080x1920, HEVC, 30 or 60 fps, often **HLG / BT.2020 with a Dolby Vision layer**. Some are plain
  SDR bt709. `probe.py` says which. Re-encoding always drops the Dolby Vision layer.
- An HLG file re-encoded without its tags plays washed out. Kept-HDR output must carry
  `-color_primaries bt2020 -color_trc arib-std-b67 -colorspace bt2020nc` and `-tag:v hvc1`, or iPhone and
  QuickTime will not play it properly. `overlay.py` does this; `qc.py` fails an overlay-lane file that is no
  longer in the source's HDR format, has no colour tags, or is HEVC without `hvc1`.
- Raw clips arrive in Downloads, `<your-folder>/`, or the Drive (`<your-folder>/My Drive/...`). A scan of the whole Drive mount hangs
  for 20 minutes: look in the specific folder, or fetch by id with `rclone backend copyid`.

## Cutting

- `silencedetect` and word timestamps both put edges inside consonants. `edl.py` cuts on a 5 ms RMS envelope and
  keeps 70 ms on each side.
- Video and audio are cut from one frame-snapped list (`trim` on frame numbers, `atrim` on the matching samples,
  each with `concat`), with 8 ms audio fades at each splice. `-ss` segment concat drifts. Cut edges are rounded
  inward to whole frames, so a cut never eats into the margin left around speech.
- The picture is cut inside `compose`, the sound inside `mix`. They only stay together if both are rebuilt after
  every `edl apply`; `compose` refuses a `mix.wav` or `captions.ass` made for an earlier cut.
- A cut graph that ends in `concat` must be followed by `fps=`. Without it a raw-video output falls back to
  25 fps and silently drops one frame in six. And output colour tags must be set with `setparams` in the filter
  chain: ffmpeg 7 ignores `-color_trc`/`-color_primaries` for raw piped frames and writes "unknown".
- Captions timed straight off those stamps appear in dead air: on the Instagram reel (2026-10-07) the first caption
  of 11 sentences showed 0.16-0.37 s before he was heard, and QC failed the render for it. `captions.py` now holds
  such a caption until his voice returns (it prints which ones it moved; read that line). It only acts on the
  measured pattern, a real silence with the voice back at the first word's stamped end, so a first word that
  Whisper stamped early for another reason is left alone. Animation `ev` times read off `words.txt` drift the same
  way for the first two or three words after a pause: add about 0.2 s to those by hand.
- The transcriber pads the first word of a phrase back across the pause before it (a "the" timed 24.64-26.40 that
  is really said at 26.4), tidies false starts away under some settings, and invents small connecting words when
  given a very short window. `transcribe.py` uses the settings that were measured to keep restarts verbatim and
  to give the same words on every run. `edl verify` is the proof a cut is clean; `edl probe` settles a doubt.

## Compositing and encoding

- ffmpeg 7.1 here. Filter graphs are passed as files with `-/filter_complex <file>`.
- Card PNGs must have even width and height (zscale and 4:2:0 both fail on odd sizes). `cards.py` and
  `overlay.py` pad them.
- Long-form builds that overlay timed graphics on concatenated clips need `-reinit_filter 0` before the base
  input, and each overlay decoded only for its own window (`-itsoffset t0 -loop 1 -t n`). Without them ffmpeg
  rebuilds the graph when colour tags change mid-stream: looped inputs stall forever and single frames vanish.
  That bug cost a day on `<your-folder>/religion-video`.
- Stale caches have bitten twice. `render_anim.py` re-renders when timing or `anim.html` changes, but it cannot
  see a swapped image: pass `--force` after changing an asset.

## Tools on this box

- Python is `C:/Python312/python` (`python` on PATH). faster-whisper runs on CPU int8; CUDA is broken here, do
  not spend time on it.
- **Never write backslashes through a Bash heredoc or `python - <<EOF`**: the tool eats them (a `\N` becomes a
  newline, `\t` a tab). Use the Write and Edit tools, forward slashes in paths, and `|` for the line break in a
  pop-up.
- Headless Chrome through Playwright (`channel="chrome"`) reaches outlets that WebSearch and WebFetch cannot.
- `yt-dlp` pulls public X and Instagram video without a login. x.com pages themselves need one: use `tweet.py`.
- Bot-check walls (Inc.com, Forbes): use another outlet. Do not try to get around them.
