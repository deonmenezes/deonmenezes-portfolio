# video-edit

A Claude Code skill by Deon Menezes (@deon_tech on Instagram, @DeonMen on X).

Edits your own talking video end to end: cuts the pauses, fillers and repeated takes, adds word-timed captions, real source cards, split-screen graphics and B-roll, then checks it and delivers it.

This is a copy of the skill he uses every day, shared from his talk on automating content with Claude Code.
More: https://deonmenezes.com/resources/content-automation

## Install

1. Unzip this file into `~/.claude/skills/`, so you end up with `~/.claude/skills/video-edit/SKILL.md`.
2. Open Claude Code and ask for it by name, for example: "use the video-edit skill".
3. Read SKILL.md once and change the parts that are about his setup to yours.

## Before you use it

- It was written for one person's machine and accounts. Paths, ids and account names are placeholders now:
  `<your-home>`, `<your-folder>`, `YOUR_..._ID`, `YOUR_..._TOKEN` and so on. Put your own in.
- No keys, tokens, passwords or private ids are included. Keep yours in your own `.env` or credentials file.
- Only text and code are included. Fonts, images, videos, sound files, model files and logs were left out,
  so anything that points at them needs your own copy (most fonts it names are free on Google Fonts).
- It mentions other skills, tools and project folders that are not in this zip. Treat those as examples of how
  he works, or skip those steps.
- "Deon", "he" and "his rules" in the text are the original owner. Read them as you.

## Files

  SKILL.md
  agents/captioner.md
  agents/content-check.md
  agents/cutter.md
  agents/graphics.md
  agents/packager.md
  agents/qc.md
  agents/researcher.md
  assets/grade-filmic/build.py
  assets/sfx.example.json
  assets/sfx.py
  references/house-style.md
  references/looks.md
  references/machine.md
  scripts/captions.py
  scripts/cards.py
  scripts/compose.py
  scripts/contentcheck.py
  scripts/deliver.py
  scripts/edl.py
  scripts/mix.py
  scripts/new_project.py
  scripts/overlay.py
  scripts/planlib.py
  scripts/probe.py
  scripts/qc.py
  scripts/render_anim.py
  scripts/search.py
  scripts/shots.py
  scripts/timemap.py
  scripts/title_pair.py
  scripts/transcribe.py
  scripts/tweet.py
  scripts/vkit.py
  templates/anim.html
  templates/brief.md
  templates/captions.json
  templates/jobs.json
  templates/overlay.json
  templates/plan.py
  templates/vk.py
