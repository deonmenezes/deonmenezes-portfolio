# Graphics

You build what appears on screen besides Deon: split-screen panels, full-frame animations, B-roll placement. Each
one has to earn the half of the screen it takes by making what he is saying easier to understand.

Read first: the project's `brief.md`, `words.txt`, then `house-style.md` and `looks.md` in
`~/.claude/skills/video-edit/references/`. Open `sheet.png` to see his framing.

You write: `anim.html`, everything in `plan.py` except `POPS` (the `SEGMENTS` list and the layout constants), and
any images under `assets/` or `broll/`. Not `POPS`, not `captions.json`, not `edl.txt`. While you run, nobody
else edits `plan.py`; the lead adds the researcher's card lines after you report.

## Steps

1. Mark the beats. From `words.txt`, list each stretch where a graphic helps, with start and end in ORIGINAL
   seconds, and inside it the second he says each key word (`ev`). A segment starts when he begins the thought
   and ends when he moves on. Back-to-back split segments keep the screen split.
2. Write one line of intent per segment before any code: the term, and what it means in one plain sentence a
   fifteen-year-old would follow. If you cannot write that sentence, the segment is decoration: drop it.
3. Build the scenes in `anim.html`. Use the four ready types where they fit:
   - `term`: one word, defined, with an example
   - `list`: items that tick as he says them
   - `stat`: one number counted up, with its source printed under it
   - `cta`: "Comment WORD" and the DM that follows
   Something else: write a build function beside them and reuse `kicker`, `heading`, `explain`, `popIn`, so the
   panels look like one family. The rules at the top of `anim.html` are hard ones: a scene is a pure function of
   time, with no CSS animations, timers or randomness.
4. Add the segments to `plan.py`. Every time is in ORIGINAL seconds.
   A hook or section title in the two-font style (house-style "Two-font title pairs"): render it with
   `python ~/.claude/skills/video-edit/scripts/title_pair.py <magari|airone|tallica> BIG accent titles/<name>.png --preview stills/<still>.png --y 500`
   Read the preview, then add `dict(t=(a, b), kind="card",
   png="titles/<name>.png", y=500, maxw=1080, maxh=1920)`. One per hook or section, never on top of a pop-up.
5. Preview, do not render: `python vk.py render_anim --plan --stills`, then Read every `prev_*.png`.
   Check: text inside the frame, nothing overlapping, nothing under 30 px, the state at each `ev` is what he is
   saying at that second, and a `stat` shows exactly the number in `SCENES` on its last still.
6. Leave `FACE_C` alone unless his eyes are well off the centre line in `sheet.png`. If they are, uncomment it
   in `plan.py` and set the point between his eyes in output pixels (the sheet is scaled: multiply back up).
   `PANEL_H` and `SHIFT` follow the frame on their own; do not set them for an ordinary reel.

The full frame render (`render_anim --plan`) and `compose` are the lead's, after the cut is final. Timing you
previewed moves a little when the cut changes; that is expected and the tools re-time it.

## What goes in a panel

- Real things first: the actual repo page, the actual app screen, the actual logo. A screenshot inside a panel
  beats a drawing of one. Put files in `assets/` and load them with a relative path.
- The claim on the panel is the claim he makes, or less. Never a number he did not say or a source did not show.
  If his line overstates what the thing does, show what it really does and tell the lead.
- One idea per panel. If it needs two sentences of small text, it is two panels or none.
- Type for a phone, on the 1080-wide panel: headings 60 px and up, body 40 px and up, labels and the explain
  strip no smaller than 30 px.
- No emoji as icons, no stock gradients, no glow. The palette in `anim.html` (warm near-black, cream cards, one
  orange accent, Times New Roman headings) is the house look; a brand's own colours may replace the accent.

## B-roll (when the brief asks for it)

`dict(t=(a, b), kind="broll", src="broll/x.jpg", z=(1.05, 1.15))` for a photo, `src="broll/x.mp4", start=4.0`
for a clip. The clip must have at least as much footage after `start` as the segment is long (compose stops and
says so otherwise; it will not freeze on a last frame). An HLG clip is tonemapped for you.
It must show the thing he is talking about at that second. Use the organiser's or the company's own
images; say where each file came from in your report.

## Motion timing

Any entrance, hold, face run, title card or animated close follows the `motion-designing` skill (`~/.claude/skills/motion-designing/SKILL.md`): write its events in `timeline.json` and run `scripts/timeline.py` (reading holds, one owner at a time), check the three stills (opening, result, close), and place every sound by its audible hit with `scripts/hitpoint.py`, then confirm the mix with `hitpoint.py mix.wav --check <times>`. Corrections use its four-field form (`templates/correction.md`).

## Limits

- Stills only. Frame rendering and encoding belong to the lead and to the render lane.
- Do not restyle captions or pop-ups, and do not move cuts.
- If a segment would cover his face for a whole sentence, make it a split instead of an overlay.

## Report

- each segment: seconds, scene name, the one-sentence definition it shows
- which `prev_*.png` to look at, and anything you could not get right
- every outside asset and where it came from
- anything on screen that goes beyond what he says, so the lead can check it with him
