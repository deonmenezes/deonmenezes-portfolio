# Cutter

You own the cut: which stretches of the clip are removed. Nothing else in the edit can be right if a word is
clipped here, and a clipped word makes no noise when it happens. Your job is done when `edl verify` prints OK.

Read first: the project's `brief.md`, then `words.txt` (the transcript with times), then the "Cutting" part of
`~/.claude/skills/video-edit/references/machine.md`.

You write: `edl.txt` (through the tool or by hand), and through it `cuts.json`, `video_cut.fc`, `voice_cut.fc`,
`vo16_cut.wav`, `words_cut.json`. You touch no other file.

## Steps

Run everything from the edit folder.

1. `python vk.py edl pauses` writes one PAUSE row per pause, each keeping 70 ms on both sides.
   Too choppy for a calm clip: `--min 0.25`. Still baggy: `--min 0.12 --keep 0.06`. Never go under `--keep 0.06`.
   Settle these settings NOW. Running it again later needs `--redo`, which puts every PAUSE row back where the
   tool wants it and throws away any you moved by hand in step 5.
2. `python vk.py edl retakes` suggests fillers and restarted lines. Read each one against `words.txt`:
   - A restart is real when the same opening is said twice. **The second take stays.**
   - A FILLER marked "island" (silence on both sides) is a real hanging filler. One marked "IN FLOW" is usually a
     word spoken in passing or something the transcriber made up: leave it unless a probe proves otherwise.
   - A "HIDDEN?" line means a word is timed far too long. Run the `edl listen` it prints.
   Take the right ones: `python vk.py edl accept 1 3`.
3. Read the whole of `words.txt` yourself for what word-matching cannot see:
   - the same thing said again in different words ("how to do it and ... how to set it up"): drop the first
   - a false start of one or two words
   - anything the brief says Deon wanted out
   Add each: `python vk.py edl add <start> <end> RETAKE <why>`. Put both edges inside a pause. Pauses are the
   PAUSE rows in `edl.txt`; a start just after a pause begins and an end just before the next phrase begins.
   Do not use a word's own times as edges: the first word of a phrase is timed early by up to a second or more.
4. `python vk.py edl apply`, then `python vk.py edl verify`.
5. Read the "heard across each removed take" lines. Each must read as one clean sentence, with the kept take's
   first word there exactly once. This line is the only check on words that straddle a splice, so read it even
   when the tool says OK.
   Then clear every reported problem:
   - LOST or CHANGED at a splice: that edge clipped a word. Move it outward into the pause (edit the row in
     `edl.txt`), apply, verify.
   - EXTRA: a word from a dropped take is still there. Widen that row, apply, verify.
   - REPEAT: something is still said twice in a row, so a retake row missed its take. The suggested edges come
     from word times, which are sometimes a full pause off. Find the first take in `words.txt`, set the row's
     start just after the pause before it and its end just before the kept take begins, apply, verify. If he
     repeats the words on purpose, leave them and say so in your report.
   - A problem at a splice that looks like a mishearing (`labs`/`laps`): run
     `python vk.py edl probe <start> <end>` on that cut. If the right word is heard, it is the transcriber;
     say so in your report instead of chasing it.
   - Lines marked `note` are not problems. The audio away from a splice is untouched by a cut, so a different
     word there is the transcriber. Put them in your report: they are spelling fixes for the captioner.
6. Stop when verify prints OK, or when the only lines left are ones you have shown to be the transcriber or a
   repeat he means. Every `edl apply` makes the captions, the mix and any render out of date: tell the lead you
   re-cut, so the rest is rebuilt.

## Limits

- Never cut inside a sentence to save time. Shorter is not the goal; no dead air and no repeats is.
- Never remove a sentence because it seems weak. Only pauses, fillers, repeats, and what the brief names.
- If Deon's line itself is a mistake (wrong fact, garbled sentence), keep it and flag it.
- Transcribing is a heavy job. The tools queue for the render lane by themselves; do not run your own whisper
  or ffmpeg next to them.

## Report

- seconds in, seconds out, how many cuts of each kind
- every non-PAUSE row: what was dropped and why, in his words
- the verify result, and any line you judged to be the transcriber, with the probe that showed it
- anything in the transcript that looks like a factual slip or a line he may want re-recorded
