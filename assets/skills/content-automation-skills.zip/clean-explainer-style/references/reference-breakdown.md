# The reference, taken apart

The look in this skill was read off one video: a 131-second reel by @speedy_devv ("How did PewDiePie make an
uncensored AI that never says no?"), which Deon sent on 2026-10-09 with "its animations are so good and aesthetic
... I want it to be like that". The file was `<your-folder>/IMG_8493.MP4`; the full working breakdown (contact sheets, strips,
transcript) was in `<your-folder>/starlink-ambani-video/reference/`. Both may have been cleared since; the five `ref_*.jpg`
images beside this file are kept so the look can still be seen.

Numbers here were measured with `scripts/breakdown.py`. Typeface names and anything about why a frame works were
read by eye and say so.

| image | what to look at |
| --- | --- |
| `ref_sheet_light_0-16s.jpg` | the hook on dark, the flip to light, the logo dropping into the laptop, the word built on screen |
| `ref_sheet_dark_48-64s.jpg` | the held metaphor: coloured clusters in a 3D space, the paper card, the arrow |
| `ref_detail_type_and_cards.jpg` | type, the selection box, a notification card, the big number, mono chips |
| `ref_strip_whip_and_focus.jpg` | 36 consecutive frames: the old scene whips up in 4, the new one focuses in |
| `ref_strip_object_persists.jpg` | 36 consecutive frames: the logo shrinks into the laptop as it rises |
| `kit_dark.png`, `kit_light.png` | what `assets/kit.css` + `kit.js` produce today, for comparison |
| `kit_comparison.png` | a scene a fresh agent built from the skill alone: two numbers and a dot field at true scale |

## 1. What the reference is

| | |
| --- | --- |
| Source | a reel by @speedy_devv (its watermark is on every frame): "How did PewDiePie make an uncensored AI that never says no?" |
| File | 131.4 s, 720x1280 vertical, 30 fps |
| Narration | 445 words in 126.5 s = **211 words a minute**, no narrator on camera; mean pause between phrases 0.29 s |
| Hard cuts | **7 in 131 s**. Everything else is one continuous canvas that changes in place |
| Canvas flips | dark 0-3.4 s (hook), light 3.4-21.9 s (context), dark 21.9-115.3 s (the mechanism), light 115.3-127 s (what it means for you + follow) |
| A real face | only twice: 0-5 s and 94-96 s, and it is the SUBJECT (PewDiePie), never the narrator |
| Sound | the pauses are never silent: median level in the gaps is -30 dB against -17 dB overall, so there is a quiet bed or effects under the voice, and a bass-heavy sting after the last word. I measured this; I cannot hear it, so the track and the individual effects are not identified |

How its two minutes are spent:

| time | what it does | how |
| --- | --- | --- |
| 0-3.4 s | hook, one question | dark canvas, subject's face behind a glossy 3D logo that splits open on "uncensored" |
| 3.4-12 s | who, what, the conflict | light canvas; portrait + the real YouTube video card; logo drops INTO a laptop; a real-looking OpenAI notification slides over it |
| 12-21.9 s | name the method, show the raw material | the word built on screen (ablate + obliterate -> abliteration); the real Hugging Face page; "9,000,000,000 numbers" with a field of digits |
| 21.9-85 s | the mechanism, **one metaphor held for 63 seconds** | prompt -> list of numbers -> coordinates on a map -> the map tilts into 3D -> requests land as glowing dots in coloured clusters -> an arrow between two clusters -> a glass plane presses the map flat |
| 85-106 s | the catch, with proof | the arrow wobbles; a real benchmark card whose score counts down 70.9% -> 52.1%; the real GitHub repo; a scatter plot filling in |
| 106-115 s | the strange part | back to the same 3D map, then one everyday object: a smoke alarm with its siren unplugged |
| 115-127 s | what you should do, follow | light canvas; server rack; the real Hugging Face search counting to 8,305; his own Instagram profile, a cursor clicking Follow, then Share |

The reason it reads as "aesthetic" is restraint: one canvas, one caption system, one accent colour per idea, and
real interfaces redrawn cleanly. The reason it reads as "so good" is that **every picture is the thing the
sentence is about, moving while it is said**. There is not one stock clip, B-roll shot or decorative graphic.

---

## 2. The style system (what to copy)

### Canvas
- Light: `#F8F8F8`. Dark: `#100C0C`. Both carry a square grid so faint it is only visible on a still.
- One subject at a time, centred, with a lot of empty space round it. Nothing touches the frame edge.
- Light canvas for people, companies and documents. Dark canvas for the abstract mechanism and anything glowing.

### Type (three faces, each with one job)
- **Captions and interface text:** a geometric sans in the Google Sans family (Figtree or DM Sans are the nearest
  free ones). Identified by eye, not confirmed.
- **Hero words and names:** a high-contrast serif italic ("Ajax", "abliteration", "brain damage" in quotes).
  Instrument Serif Italic or EB Garamond Italic are close. By eye.
- **Data and small labels:** a monospace ("ablate + obliterate", number grids, chips like `x 0.31`).

### Captions (the signature)
- Sit in one fixed place: top centre, about 14-20% down the frame. They never move to make room.
- 1 to 5 words on screen, two lines at most. The group clears at every phrase boundary.
- The word being spoken is **bold and full contrast**; words already spoken drop to regular weight, mid grey.
- A new word arrives blurred and a few pixels low, and is sharp within 2-3 frames.
- About one keyword per clause gets a **selection box**, drawn like a design tool selecting it: 1.5 px blue outline
  (about `#4878B8`), pale blue fill on light / navy fill (`#082858`) on dark, and two round handles, top-left and
  bottom-right. The box draws on over about 4 frames just after the word lands.
- Occasionally one emoji sits inline before the keyword (laptop, map, brain). Sparingly: about ten in the whole reel.

### Colour
- Almost monochrome. Colour means something every time: purple `#6848F8` for the model, red `#F83838` for
  refusal, amber `#E8A848` for "harmful", and the cluster colours (amber, violet, blue, pink, green) for topics.
- Red is also the "damage" colour on the benchmark card (`#D81828`): struck-out answers, the falling score.

### Objects
- **Real interfaces, redrawn clean:** YouTube card, macOS notification, Hugging Face model page and search,
  arXiv abstract, GitHub repo, Instagram profile. White cards, 16 px corners, soft wide shadow. The relevant line
  gets the same blue selection box as the captions.
- **A few 3D objects**, glossy and simple: the model's logo extruded, a laptop, a server rack, a smoke alarm,
  a glass plate. Each stands for exactly one noun in the narration.
- **Big numbers** in bold sans with a small grey label under them ("9,000,000,000 / numbers in the model"), and
  counters that run while the voice says them (2 -> 4,096 dimensions; 70.9% -> 52.1%).
- **Words built on screen:** two serif words drift together and merge into the new term, with the recipe in mono
  under it. This is how it defines a term.

### Motion (from the frame-by-frame strips)
- **Leave fast, arrive soft.** The old scene whips upward with heavy vertical motion blur in about 4 frames
  (0.13 s). The new one is already on screen underneath, blurred, and takes 8-12 frames to come into focus.
- **Nothing is ever still.** After it lands, everything keeps drifting: the 3D logo turns slowly, two words keep
  easing together, the camera keeps orbiting the 3D map.
- **Objects persist.** The logo shrinks and drops into the laptop screen as the laptop rises to meet it (12
  frames); the flat map tilts and becomes the floor of the 3D space; the same 3D map comes back three times.
  A new idea is a change to the thing already on screen, not a new slide.
- **Cards** come in tilted a few degrees with motion blur, straighten, and sharpen (about 12 frames).
- **The canvas colour only changes on a hard cut**, and only where the story changes register.
- A new visual event lands about every 1-2 seconds, always on the word it belongs to.

### What it never does
No stock footage, no B-roll, no talking head, no lower thirds, no progress bar, no drop shadows on text, no
gradients behind text, no more than one idea on screen, no transition that is only decoration.
