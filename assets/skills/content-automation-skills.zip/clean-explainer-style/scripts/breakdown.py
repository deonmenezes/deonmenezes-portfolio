"""breakdown.py - take a reference video apart so its style can be read off pictures and numbers.

    python breakdown.py <video> <outdir>                       everything below
    python breakdown.py <video> <outdir> --no-transcript       skip the speech pass (about a minute per 2 min of video)
    python breakdown.py <video> <outdir> --strip 11.5:1.2      also a frame-by-frame strip of that window (repeatable)

Writes into <outdir>:
    facts.json          size, fps, duration, hard cuts, canvas colour per second and where it flips, narration pace,
                        how loud the pauses are (a music bed shows up as pauses that are never silent)
    sheets/s_NN.jpg     contact sheets, 2 frames a second, time-stamped: Read every one of these
    strips/t_<time>.jpg every frame of a window, tiled: this is where the motion is (how things arrive and leave)
    transcript.txt, words.json   what is said and when (faster-whisper on CPU, int8: CUDA is broken on this PC)

It measures; it does not judge. Fonts, what is real and what is drawn, and why a frame works are read off the
sheets by eye, and anything read by eye is labelled that way in the write-up.
"""
import argparse
import json
import pathlib
import re
import subprocess
import sys


def run(*a):
    return subprocess.run(a, capture_output=True, text=True, errors="replace")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("out")
    ap.add_argument("--no-transcript", action="store_true")
    ap.add_argument("--strip", action="append", default=[])
    a = ap.parse_args()
    v = a.video
    out = pathlib.Path(a.out)
    (out / "sheets").mkdir(parents=True, exist_ok=True)
    (out / "strips").mkdir(exist_ok=True)
    facts = {"video": v}

    pr = json.loads(run("ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height,r_frame_rate",
                        "-of", "json", v).stdout)
    vs = next(s for s in pr["streams"] if s["codec_type"] == "video")
    n, d = vs["r_frame_rate"].split("/")
    W, H, fps, dur = vs["width"], vs["height"], round(int(n) / int(d), 3), float(pr["format"]["duration"])
    facts.update(width=W, height=H, fps=fps, duration=round(dur, 2), has_audio=any(s["codec_type"] == "audio" for s in pr["streams"]))

    # contact sheets: 2 fps, 8 x 4 per sheet, each cell time-stamped
    cw = 216
    ch = int(cw * H / W / 2) * 2
    run("ffmpeg", "-v", "error", "-y", "-i", v, "-vf",
        f"fps=2,scale={cw}:{ch},drawtext=text='%{{pts\\:hms}}':x=4:y=4:fontsize=18:fontcolor=yellow:box=1:boxcolor=black@0.6,tile=8x4",
        "-q:v", "3", str(out / "sheets" / "s_%02d.jpg"))
    facts["sheets"] = len(list((out / "sheets").glob("s_*.jpg")))

    # hard cuts
    r = run("ffmpeg", "-hide_banner", "-i", v, "-vf", "select='gt(scene,0.3)',showinfo", "-an", "-f", "null", "-")
    cuts = [round(float(x), 2) for x in re.findall(r"pts_time:([0-9.]+)", r.stderr)]
    cuts = [c for i, c in enumerate(cuts) if i == 0 or c - cuts[i - 1] > .25]      # one flash can register twice
    facts["hard_cuts"] = cuts
    facts["cuts_per_minute"] = round(len(cuts) / dur * 60, 1)

    # canvas colour once a second (the most common colour of the frame), and where it flips
    try:
        import numpy as np
        raw = subprocess.run(["ffmpeg", "-v", "error", "-i", v, "-vf", "fps=1,scale=64:64", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                             capture_output=True).stdout
        fr = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 64 * 64, 3)
        cols = []
        for f in fr:
            q = (f // 8) * 8 + 4
            vals, cnt = np.unique(q, axis=0, return_counts=True)
            cols.append("#%02X%02X%02X" % tuple(int(x) for x in vals[cnt.argmax()]))
        lum = [int(c[1:3], 16) * .3 + int(c[3:5], 16) * .59 + int(c[5:7], 16) * .11 for c in cols]
        kind = ["light" if x > 150 else "dark" if x < 70 else "mid" for x in lum]
        runs, start = [], 0
        for i in range(1, len(kind) + 1):
            if i == len(kind) or kind[i] != kind[start]:
                runs.append({"from": start, "to": i, "canvas": kind[start], "colour_approx": max(set(cols[start:i]), key=cols[start:i].count)})
                start = i
        facts["canvas_runs"] = runs
    except Exception as e:                                  # numpy missing: the sheets still show it
        facts["canvas_runs"] = f"not measured: {e}"

    # frame-by-frame strips: asked-for windows, plus the first hard cuts (that is where the transitions are)
    wins = [tuple(float(x) for x in s.split(":")) for s in a.strip]
    wins += [(max(0, c - .5), 1.0) for c in cuts[:3] if not any(abs(c - w[0]) < 1 for w in wins)]
    sw = 180
    sh = int(sw * H / W / 2) * 2
    for t0, span in wins:
        nfr = int(round(span * 30))
        cols_ = min(nfr, 9 if W < H else 6)
        rows = -(-nfr // cols_)
        run("ffmpeg", "-v", "error", "-y", "-ss", str(t0), "-t", str(span), "-i", v, "-vf",
            f"fps=30,scale={sw}:{sh},tile={cols_}x{rows}", "-frames:v", "1", "-q:v", "3", str(out / "strips" / f"t_{t0:06.2f}.jpg"))
    facts["strips"] = [f"t_{t0:06.2f}.jpg" for t0, _ in wins]

    # narration: pace, and how quiet the pauses get
    if facts["has_audio"] and not a.no_transcript:
        wav = out / "audio.wav"
        run("ffmpeg", "-v", "error", "-y", "-i", v, "-vn", "-ac", "1", "-ar", "16000", str(wav))
        try:
            from faster_whisper import WhisperModel
            import numpy as np
            import wave
            m = WhisperModel("small", device="cpu", compute_type="int8")
            segs, _ = m.transcribe(str(wav), word_timestamps=True, vad_filter=False)
            words, lines = [], []
            for s in segs:
                lines.append(f"[{s.start:6.2f}-{s.end:6.2f}] {s.text.strip()}")
                words += [(round(w.start, 2), round(w.end, 2), w.word.strip()) for w in s.words]
            (out / "transcript.txt").write_text("\n".join(lines), encoding="utf-8")
            (out / "words.json").write_text(json.dumps(words))
            if words:
                span = words[-1][1] - words[0][0]
                wf = wave.open(str(wav))
                sr = wf.getframerate()
                x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768
                db = lambda y: round(float(20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)), 1) if len(y) else None
                gaps = [(words[i][1], words[i + 1][0]) for i in range(len(words) - 1) if words[i + 1][0] - words[i][1] >= .22]
                g = [db(x[int((s + .05) * sr):int((e - .05) * sr)]) for s, e in gaps]
                g = [y for y in g if y is not None]
                facts["narration"] = {
                    "words": len(words), "words_per_minute": round(len(words) / span * 60),
                    "pauses": len(gaps), "mean_pause_s": round(float(np.mean([e - s for s, e in gaps])), 2) if gaps else None,
                    "level_overall_db": db(x), "level_in_pauses_median_db": float(np.median(g)) if g else None,
                    "level_after_last_word_db": db(x[int((words[-1][1] + .3) * sr):]),
                    "reading": "pauses within about 15 dB of the overall level mean a music bed or effects under the voice",
                }
        except Exception as e:
            facts["narration"] = f"not measured: {e}"

    (out / "facts.json").write_text(json.dumps(facts, indent=1))
    print(json.dumps({k: facts[k] for k in facts if k != "canvas_runs"}, indent=1))
    print("canvas:", facts["canvas_runs"])
    print(f"\nNow Read every sheet in {out / 'sheets'} and the strips in {out / 'strips'}.")


if __name__ == "__main__":
    main()
