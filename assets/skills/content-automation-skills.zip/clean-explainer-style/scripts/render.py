"""render.py - turn a scene from scene.html into stills, a frame strip, or an mp4.

    python render.py <scene.html> <scene> --stills 0.5,1.7,3.4        one PNG per time  -> <out>/<scene>_<t>.png
    python render.py <scene.html> <scene> --strip 1.4:0.7             every frame of a 0.7 s window, tiled into
                                                                      one image -> <out>/<scene>_strip_1.40.jpg
    python render.py <scene.html> <scene> --mp4                        the whole scene -> <out>/<scene>.mp4
    options: --dur 9 (default: the scene's own)   --ev 1.2,3.4   --size 1920x1080   --fps 30
             --out <dir> (default: out/ beside the html)   --strip-cols 5 (fewer = bigger frames)

Look at stills and one strip BEFORE rendering an mp4: a full scene is one screenshot per frame (30 a second).
A strip shows the ORDER and SPEED of a move. For tilt, focus and blur, also take one full-size still in the
middle of the move. For drift, compare two stills a few seconds apart: it is about 1 px a second.
Run one render at a time; this PC has crashed under parallel heavy jobs.

The page contract (window.setT(t), document.title == "READY") is the same one video-edit's render_anim.py
uses, so a scene written here also renders through that tool inside a video-edit project.
"""
import argparse
import pathlib
import shutil
import subprocess
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("scene")
    ap.add_argument("--stills")
    ap.add_argument("--strip")
    ap.add_argument("--mp4", action="store_true")
    ap.add_argument("--dur", type=float)
    ap.add_argument("--ev", default="")
    ap.add_argument("--size", default="1920x1080")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--out")
    ap.add_argument("--strip-cols", type=int, default=5)
    a = ap.parse_args()
    if not (a.stills or a.strip or a.mp4):
        sys.exit(__doc__)

    html = pathlib.Path(a.html).resolve()
    out = pathlib.Path(a.out) if a.out else html.parent / "out"
    out.mkdir(parents=True, exist_ok=True)
    w, h = (int(x) for x in a.size.lower().split("x"))

    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        try:
            br = pw.chromium.launch(channel="chrome", headless=True, args=["--allow-file-access-from-files"])
        except Exception:
            br = pw.chromium.launch(headless=True, args=["--allow-file-access-from-files"])
        pg = br.new_context(viewport={"width": w, "height": h}, device_scale_factor=1).new_page()
        errors = []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        q = f"?a={a.scene}&w={w}&h={h}" + (f"&d={a.dur}" if a.dur else "") + (f"&ev={a.ev}" if a.ev else "")
        pg.goto(html.as_uri() + q)
        pg.wait_for_load_state("networkidle")
        pg.wait_for_function("document.title !== 'loading'", timeout=15000)
        if errors or pg.title() != "READY":
            sys.exit(f"scene '{a.scene}' did not load: {errors or pg.title()}")
        dur = a.dur or pg.evaluate("K.d")

        def shot(t, path):
            try:
                pg.evaluate(f"window.setT({t})")
            except Exception as e:                       # an error thrown inside the scene's draw()
                br.close()
                sys.exit(f"scene '{a.scene}' threw in draw() at t={t}: {str(e).splitlines()[0]}")
            pg.screenshot(path=str(path))

        if a.stills:
            for t in (float(x) for x in a.stills.split(",")):
                p = out / f"{a.scene}_{t:05.2f}.png"
                shot(t, p)
                print(p)

        if a.strip:
            t0, span = (float(x) for x in a.strip.split(":"))
            tmp = out / f"_strip_{a.scene}"
            shutil.rmtree(tmp, ignore_errors=True)
            tmp.mkdir()
            n = int(round(span * a.fps))
            for i in range(n):
                shot(t0 + i / a.fps, tmp / f"f{i:04d}.png")
            cols = min(n, a.strip_cols)
            rows = -(-n // cols)
            p = out / f"{a.scene}_strip_{t0:05.2f}.jpg"
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", str(a.fps), "-i", str(tmp / "f%04d.png"),
                            "-vf", f"scale={w // 3}:-1,tile={cols}x{rows}:color=0x7F7F7F", "-frames:v", "1", "-q:v", "3", str(p)], check=True)
            shutil.rmtree(tmp)
            print(p, f"({n} frames, {cols}x{rows}, left to right then down; grey cells are padding)")

        if a.mp4:
            tmp = out / f"_frames_{a.scene}"
            shutil.rmtree(tmp, ignore_errors=True)
            tmp.mkdir()
            n = int(round(dur * a.fps))
            for i in range(n):
                shot(i / a.fps, tmp / f"f{i:05d}.png")
            p = out / f"{a.scene}.mp4"
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", str(a.fps), "-i", str(tmp / "f%05d.png"),
                            "-c:v", "libx264", "-crf", "16", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(p)], check=True)
            shutil.rmtree(tmp)
            print(p, f"({n} frames, {dur:.2f} s)")

        if errors:
            sys.exit(f"scene '{a.scene}' threw while drawing: {errors[:3]}")
        br.close()


if __name__ == "__main__":
    main()
