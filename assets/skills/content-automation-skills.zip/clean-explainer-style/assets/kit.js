/* kit.js - the motion. Every helper is a PURE FUNCTION OF t (seconds since the scene started).
   No CSS transitions, no CSS animations, no timers, no Math.random(): frames are rendered one at a time and
   sometimes out of order, so anything that depends on the wall clock comes out wrong.

   The page contract is the one video-edit's render_anim.py already uses:
       scene.html?a=<scene>&d=<seconds>&ev=<t1,t2,...>&w=1920&h=1080
       window.setT(t) draws frame t;  document.title === "READY" once the scene is built.

   The four rules of the look, in code:
     K.life()      leave fast, arrive soft; and never sit still (slow drift for as long as it is on screen)
     K.captions()  one fixed place, spoken word bold, earlier words grey, one keyword in a selection box
     K.sel()       the same selection box on the real line inside a card
     K.count()     numbers run while they are being said
*/
const K = {};

K.clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
K.p     = (t, t0, d) => K.clamp((t - t0) / d);                    // progress 0..1 of a move that starts at t0
K.out   = x => 1 - Math.pow(1 - K.clamp(x), 3);                   // ease-out: quick start, soft landing
K.out5  = x => 1 - Math.pow(1 - K.clamp(x), 5);                   // a harder snap (small things: ticks, chips)
K.inn   = x => Math.pow(K.clamp(x), 2.4);                         // ease-in: slow start, then gone (exits)
K.io    = x => { x = K.clamp(x); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };
K.lerp  = (a, b, x) => a + (b - a) * x;

K.el = (parent, cls, html = "") => {
  const e = document.createElement("div");
  e.className = cls; e.innerHTML = html; parent.appendChild(e); return e;
};

/* markup for a selection box round some text: use inside card HTML (captions build their own) */
K.selHTML = (text, id = "") =>
  `<span class="sel"${id ? ` data-sel="${id}"` : ""}><i class="bx"></i><i class="h1"></i><i class="h2"></i>${text}</span>`;

/* draw a selection box on over ~0.22 s: first handle, the box wipes left to right, second handle */
K.sel = (span, t, t0) => {
  if (!span) return;
  const age = t - t0, [bx, h1, h2] = ["bx", "h1", "h2"].map(c => span.querySelector(":scope > ." + c));
  const wipe = K.out(K.p(age, .04, .16));
  bx.style.clipPath = `inset(-4px ${((1 - wipe) * 100).toFixed(2)}% -4px -4px)`;
  bx.style.opacity = age < .04 ? 0 : 1;
  h1.style.transform = `scale(${K.out(K.p(age, 0, .10))})`;
  h2.style.transform = `scale(${K.out(K.p(age, .14, .10))})`;
};

/* blur = focus (round) + motion (vertical only). The vertical part is an SVG filter, one per element. */
K._nf = 0;
K.blur = (el, focus, vertical = 0) => {
  if (vertical < .4) { el.style.filter = focus > .15 ? `blur(${focus.toFixed(2)}px)` : "none"; return; }
  if (!el._vb) {
    if (!K._svg) {
      K._svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      K._svg.setAttribute("style", "position:absolute;width:0;height:0");
      document.body.appendChild(K._svg);
    }
    const id = "vb" + (++K._nf);
    K._svg.insertAdjacentHTML("beforeend",
      `<filter id="${id}" x="-10%" y="-60%" width="120%" height="220%"><feGaussianBlur stdDeviation="0 1"/></filter>`);
    el._vb = K._svg.lastElementChild.firstElementChild; el._vbid = id;
  }
  el._vb.setAttribute("stdDeviation", `0 ${vertical.toFixed(2)}`);
  el.style.filter = `url(#${el._vbid})` + (focus > .15 ? ` blur(${focus.toFixed(2)}px)` : "");
};

/* The life of one thing on screen. The options object is rebuilt every frame, so ANY field may be computed
   from t before it is passed (a card stepping aside: x: K.lerp(815, 600, K.io(K.p(t, 4, .5)))).

     x, y    where it rests. By default that is its CENTRE; with anchor: "left" it is the middle of its LEFT
             edge (use for source chips, labels and anything left-aligned whose width changes, like a counter)
     in      second it starts arriving            out    second it starts leaving (omit: it stays)
     leave   "whip" (default): straight up with vertical blur, with the rest of the scene
             "fade": dissolves where it stands in 6 frames (one thing leaving while its neighbours stay)
     tilt    degrees it arrives tilted by (cards: -2.5; text: 0)        rest   degrees it rests at
     rise    px it comes up from (70)             blur   px out of focus on arrival (14; small text: 4-6)
     scale   resting scale (1)                    inDur  arrival, seconds (0.40 = 12 frames)
     whip    exit, seconds (0.14 = 4 frames)      drift  0 holds it dead still (rails, chips, ticks)
     dim     {at, to}: fade to opacity `to` from second `at` (a card stepping back behind a newer one)      */
K.life = (el, t, o) => {
  const inDur = o.inDur ?? .40, fade = o.leave === "fade", whip = fade ? .20 : (o.whip ?? .14);
  const on = t >= o.in && (o.out == null || t < o.out + whip);
  el.style.visibility = on ? "visible" : "hidden";
  if (!on) return 0;
  const p = K.p(t, o.in, inDur);
  const a = K.out(p);                                                 // position: most of the way in 5 frames...
  const f = Math.pow(1 - p, 1.5);                                     // ...focus: still resolving at frame 10
  const z = o.out == null ? 0 : (fade ? K.p(t, o.out, whip) : K.inn(K.p(t, o.out, whip)));
  const age = t - o.in, still = o.drift === 0;
  const dy = (1 - a) * (o.rise ?? 70) - (fade ? 0 : z * K.H * .85) - (still ? 0 : age * 1.1);
  const rot = (o.tilt ?? 0) * (1 - a) + (o.rest ?? 0);
  const sc = (o.scale ?? 1) * K.lerp(.965, 1, a) * (still ? 1 : 1 + age * .0022);
  const ax = o.anchor === "left" ? "0" : "-50%";
  el.style.transformOrigin = o.anchor === "left" ? "0 50%" : "50% 50%";
  el.style.transform = `translate(${(+o.x).toFixed(2)}px, ${(o.y + dy).toFixed(2)}px) translate(${ax}, -50%) rotate(${rot.toFixed(3)}deg) scale(${sc.toFixed(5)})`;
  let op = K.clamp(p * 2.2) * (1 - K.clamp(z * (fade ? 1 : 1.15)));
  const d = o.dim ? K.io(K.p(t, o.dim.at, .35)) : 0;
  if (o.dim) op *= K.lerp(1, o.dim.to, d);
  el.style.opacity = op.toFixed(3);
  K.blur(el, f * (o.blur ?? 14) + d * 1.2, fade ? 0 : f * 14 + z * 70);
  return a;
};

/* Captions. words = [{t, w, sel, join, nl, clear}, ...]
     t      second the word is SPOKEN (from the voice's word timings)
     sel    true: the clause's keyword. It gets the selection box and stays bold
     join   true (with sel): this word goes inside the PREVIOUS word's box, which widens as it is said.
            This is how a spoken number or a two-word name gets one box: "twenty" sel, "lakh" sel + join
     nl     true: start the second line with this word (two lines at most)
     clear  true: this word starts a new phrase; the previous one disappears
   Returns {draw(t)}. */
K.captions = (stage, words) => {
  const cap = K.el(stage, "cap");
  const phrases = [];
  let grp = null;
  const span = (cls, html) => { const s = document.createElement("span"); s.className = cls; s.innerHTML = html; return s; };
  words.forEach((w, i) => {
    if (i === 0 || w.clear) { phrases.push({ t: w.t, el: K.el(cap, "ph"), ws: [], grps: [] }); grp = null; }
    const ph = phrases[phrases.length - 1];
    if (w.nl) { ph.el.appendChild(document.createElement("br")); grp = null; }
    const s = span("w" + (w.sel ? " key" : ""), w.w);
    if (w.sel) {
      if (!(w.join && grp)) {
        grp = { t: w.t, el: span("sel", '<i class="bx"></i><i class="h1"></i><i class="h2"></i>') };
        ph.el.appendChild(grp.el); ph.el.appendChild(document.createTextNode(" ")); ph.grps.push(grp);
      } else grp.el.appendChild(document.createTextNode(" "));
      grp.el.appendChild(s);
    } else { grp = null; ph.el.appendChild(s); ph.el.appendChild(document.createTextNode(" ")); }
    ph.ws.push({ ...w, el: s });
  });
  return {
    draw(t) {
      phrases.forEach((ph, i) => {
        const end = i + 1 < phrases.length ? phrases[i + 1].t : Infinity;
        const on = t >= ph.t && t < end;
        ph.el.style.display = on ? "block" : "none";
        if (!on) return;
        let last = -1;
        ph.ws.forEach((w, j) => { if (t >= w.t) last = j; });
        ph.ws.forEach((w, j) => {
          const age = t - w.t;
          if (age < 0) { w.el.style.display = "none"; return; }       // not said yet: takes no room, so the line re-centres
          const a = K.out(K.p(age, 0, .10));                          // sharp within 3 frames
          w.el.style.display = "inline-block";
          w.el.classList.toggle("now", j === last);
          w.el.style.opacity = K.lerp(.5, 1, a).toFixed(3);
          w.el.style.transform = `translateY(${((1 - a) * 7).toFixed(2)}px)`;
          w.el.style.filter = a < .98 ? `blur(${((1 - a) * 6).toFixed(2)}px)` : "none";
        });
        ph.grps.forEach(g => {
          g.el.style.display = t >= g.t ? "inline-block" : "none";
          if (t >= g.t) K.sel(g.el, t, g.t + .06);
        });
      });
    },
  };
};

/* a number that runs while it is being said: start it on the number's first word, end it on its last */
K.count = (el, t, t0, dur, from, to, fmt = n => Math.round(n).toLocaleString("en-US")) => {
  el.textContent = fmt(K.lerp(from, to, K.out(K.p(t, t0, dur))));
};

/* a field of dots for a comparison at true scale: fill(k) lights the first k (pass a fraction of a dot too).
   Give the wrapper the class "it" yourself if K.life should move it. */
K.dots = (parent, { cols, rows, size = 14, gap = 8, color = "currentColor" }) => {
  const el = K.el(parent, "dots");
  el.style.cssText += `display:grid;grid-template-columns:repeat(${cols},${size}px);gap:${gap}px;color:${color}`;
  const ds = [];
  for (let i = 0; i < cols * rows; i++) {
    const d = document.createElement("i");
    d.style.cssText = `width:${size}px;height:${size}px;border-radius:50%;background:currentColor;opacity:.08`;
    el.appendChild(d); ds.push(d);
  }
  return { el, fill(k) { ds.forEach((d, i) => { d.style.opacity = K.lerp(.08, 1, K.clamp(k - i)).toFixed(3); }); } };
};

/* boot: read the query, size the stage, build the scene once, expose setT */
K.boot = SCENES => {
  const P = new URLSearchParams(location.search);
  const name = P.get("a") || Object.keys(SCENES)[0];
  const sc = SCENES[name];
  if (!sc) { document.title = "NO SCENE " + name; return; }
  K.W = +(P.get("w") || 1920); K.H = +(P.get("h") || 1080);
  K.d = +(P.get("d") || sc.dur || 8);
  K.ev = (P.get("ev") || "").split(",").filter(Boolean).map(Number);
  const stage = document.getElementById("stage");
  stage.className = sc.canvas || "light";
  stage.style.width = K.W + "px"; stage.style.height = K.H + "px";
  const parts = sc.build(stage, K.ev) || {};
  window.setT = t => sc.draw(t, parts, K.ev);
  document.fonts.ready.then(() => { window.setT(+(P.get("t") || 0)); document.title = "READY"; });
};
