"""Build a 4:5 Instagram carousel (cover, video slides, follow end slide) from carousel.json.

python build.py <project_dir>                 # every slide
python build.py <project_dir> 01 07           # only those slide numbers
python build.py <project_dir> --out out_test  # write somewhere other than <project_dir>/out

Slide 01 is the cover, 02.. are the clips in config order, the last number is the end slide.
See ../SKILL.md for the carousel.json fields.
"""
import json
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

SKILL = Path(__file__).resolve().parent.parent
W, H = 1080, 1350
VIDEO_CY = 680  # vertical centre of the gameplay window
WM_Y = 1256  # top of the watermark row
WM_SIZE = 68
FONTS = Path("C:/Windows/Fonts")
YELLOW = (255, 214, 10)
X264 = ["-c:v", "libx264", "-preset", "medium", "-threads", "6", "-profile:v", "high",
        "-level", "4.1", "-r", "30", "-g", "60", "-ac", "2", "-movflags", "+faststart"]


def font(name, size):
    return ImageFont.truetype(str(FONTS / name), size)


def run(cmd):
    subprocess.run(cmd, check=True)


class Carousel:
    def __init__(self, project, out=None):
        self.root = Path(project).resolve()
        self.cfg = json.loads((self.root / "carousel.json").read_text(encoding="utf-8"))
        self.out = (self.root / out) if out else self.root / "out"
        self.tmp = self.root / "tmp"
        self.stills = self.out / "stills"
        for d in (self.out, self.tmp, self.stills):
            d.mkdir(parents=True, exist_ok=True)
        self.handle = self.cfg.get("handle", "@deon_tech")
        self.tag = self.cfg.get("tag", "")
        self.slides = self.cfg["slides"]
        self.end_no = f"{len(self.slides) + 2:02d}"
        pfp = self.cfg.get("pfp")
        self.pfp = self.root / pfp if pfp else SKILL / "assets" / "deon_tech_pfp.jpg"
        self.pfp_box = tuple(self.cfg.get("pfp_box", (118, 101, 793, 776)))
        music = self.cfg.get("music")
        self.music = self.root / music if music else None
        # theme: "accent" [r, g, b] replaces the yellow (tag, x marks, window lines, end ring, handle);
        # "panel" [r, g, b, a] is the tint over the blurred bands above and below the clip (default black 120)
        self.accent = tuple(self.cfg.get("accent", YELLOW))
        self.panel = tuple(self.cfg.get("panel", (0, 0, 0, 120)))

    # ---- shared drawing ------------------------------------------------------------------
    def avatar(self, size):
        im = Image.open(self.pfp).convert("RGB").crop(self.pfp_box).resize((size, size), Image.LANCZOS)
        mask = Image.new("L", (size * 2, size * 2), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, size * 2 - 1, size * 2 - 1], fill=255)
        return im, mask.resize((size, size), Image.LANCZOS)

    def watermark(self, img, left=None, y=WM_Y, pill=False):
        """Round profile picture + handle; centred unless a left edge is given."""
        d = ImageDraw.Draw(img)
        fnt = font("segoeuib.ttf", 38)
        total = WM_SIZE + 16 + d.textlength(self.handle, font=fnt)
        x = int((W - total) / 2 if left is None else left)
        if pill:
            d.rounded_rectangle([x - 14, y - 12, x + total + 26, y + WM_SIZE + 12],
                                radius=(WM_SIZE + 24) // 2, fill=(0, 0, 0, 165))
        av, mask = self.avatar(WM_SIZE)
        d.ellipse([x - 3, y - 3, x + WM_SIZE + 3, y + WM_SIZE + 3], fill="white")
        img.paste(av, (x, y), mask)
        d.text((x + WM_SIZE + 16, y + WM_SIZE / 2), self.handle, font=fnt, fill="white", anchor="lm",
               stroke_width=3, stroke_fill="black")

    def fit_cover(self):
        """The cover art centre-cropped to 4:5."""
        im = Image.open(self.root / self.cfg["cover"]["image"]).convert("RGB")
        w, h = im.size
        if w / h > W / H:
            nw = round(h * W / H)
            im = im.crop(((w - nw) // 2, 0, (w - nw) // 2 + nw, h))
        else:
            nh = round(w * H / W)
            im = im.crop((0, (h - nh) // 2, w, (h - nh) // 2 + nh))
        return im.resize((W, H), Image.LANCZOS)

    # ---- still slides (cover, end) -------------------------------------------------------
    def still_video(self, no, music, default_dur=5.0):
        """Still -> short video, with the music bed if one is configured, else silence.

        Stills ship as video so the whole carousel can go up through rupload (images need a public URL).
        """
        out = self.out / f"slide_{no}.mp4"
        cmd = ["ffmpeg", "-v", "error", "-y", "-loop", "1", "-framerate", "30"]
        video = "[0:v]scale=in_range=full:out_range=tv,format=yuv420p[v]"  # JPEG is full range
        if self.music and music:
            start, dur = music
            cmd += ["-t", str(dur), "-i", str(self.stills / f"slide_{no}.jpg"),
                    "-ss", str(start), "-t", str(dur), "-i", str(self.music)]
            audio = (f"[1:a]afade=t=in:d=0.2,afade=t=out:st={dur - 0.7}:d=0.7,"
                     f"volume={self.cfg.get('music_volume', 0.7)},aresample=48000[a]")
            note = f"music from {start}s"
        else:
            dur = default_dur
            cmd += ["-t", str(dur), "-i", str(self.stills / f"slide_{no}.jpg"),
                    "-f", "lavfi", "-t", str(dur), "-i", "anullsrc=r=48000:cl=stereo"]
            audio = "[1:a]anull[a]"
            note = "silent"
        run(cmd + ["-filter_complex", f"{video};{audio}", "-map", "[v]", "-map", "[a]", *X264,
                   "-crf", "16", "-tune", "stillimage", "-c:a", "aac", "-b:a", "192k",
                   "-t", str(dur), str(out)])
        print(f"slide {no}: {out.name} {dur}s (still, {note})")

    def build_cover(self):
        im = self.fit_cover().convert("RGBA")
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        self.watermark(layer, left=44, y=WM_Y - 6, pill=True)
        Image.alpha_composite(im, layer).convert("RGB").save(self.stills / "slide_01.jpg", quality=95)
        self.still_video("01", self.cfg["cover"].get("music"))

    def build_end(self):
        """Closing slide: big profile picture and a follow line over the blurred cover art."""
        end = self.cfg.get("end", {})
        lines = end.get("lines", ["FOLLOW", self.handle, "FOR MORE"])
        bg = self.fit_cover().crop((0, 420, W, H)).resize((W, H), Image.LANCZOS)
        bg = bg.filter(ImageFilter.GaussianBlur(26)).convert("RGBA")
        img = Image.alpha_composite(bg, Image.new("RGBA", (W, H), (0, 0, 0, 150)))
        d = ImageDraw.Draw(img)
        size, cx, top = 400, W // 2, 190
        av, mask = self.avatar(size)
        x = cx - size // 2
        d.ellipse([x - 16, top - 16, x + size + 16, top + size + 16], fill=self.accent)
        d.ellipse([x - 8, top - 8, x + size + 8, top + size + 8], fill="white")
        img.paste(av, (x, top), mask)
        y = top + size + 70
        for text in lines:
            size_pt = 150
            while d.textlength(text, font=font("impact.ttf", size_pt)) > W - 80:
                size_pt -= 6
            fill = self.accent if text.startswith("@") else "white"
            d.text((cx, y), text, font=font("impact.ttf", size_pt), fill=fill, anchor="ma",
                   stroke_width=7, stroke_fill="black")
            y += 176
        img.convert("RGB").save(self.stills / f"slide_{self.end_no}.jpg", quality=95)
        self.still_video(self.end_no, end.get("music"))

    # ---- clip slides -----------------------------------------------------------------------
    @staticmethod
    def wrap(draw, text, fnt, max_w):
        lines, cur = [], ""
        for word in text.split():
            trial = f"{cur} {word}".strip()
            if draw.textlength(trial, font=fnt) <= max_w or not cur:
                cur = trial
            else:
                lines.append(cur)
                cur = word
        lines.append(cur)
        return lines

    @staticmethod
    def fit_title(draw, text, max_w):
        """Largest Impact size where the title fits on one line, else two lines split at a ×."""
        for size in range(104, 63, -4):
            fnt = font("impact.ttf", size)
            if draw.textlength(text, font=fnt) <= max_w:
                return fnt, [text]
        parts = text.split(" × ")
        best = None
        for i in range(1, len(parts)):
            a, b = " × ".join(parts[:i]), "× " + " × ".join(parts[i:])
            for size in range(104, 55, -4):
                fnt = font("impact.ttf", size)
                if max(draw.textlength(a, font=fnt), draw.textlength(b, font=fnt)) <= max_w:
                    if best is None or size > best[0]:
                        best = (size, fnt, [a, b])
                    break
        if best is None:
            raise SystemExit(f"title too long to fit, shorten it: {text}")
        return best[1], best[2]

    @staticmethod
    def draw_title_line(draw, line, fnt, y, accent=YELLOW):
        """Centre a title line, colouring each × in the accent colour."""
        x = (W - draw.textlength(line, font=fnt)) / 2
        for i, chunk in enumerate(line.split("×")):
            if i:
                draw.text((x, y), "×", font=fnt, fill=accent, stroke_width=5, stroke_fill="black")
                x += draw.textlength("×", font=fnt)
            draw.text((x, y), chunk, font=fnt, fill="white", stroke_width=5, stroke_fill="black")
            x += draw.textlength(chunk, font=fnt)

    def overlay_png(self, no, index, slide, video_h):
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        top = VIDEO_CY - video_h // 2
        bottom = VIDEO_CY + video_h // 2
        # darken the blurred panels so titles read on bright footage
        d.rectangle([0, 0, W, top], fill=self.panel)
        d.rectangle([0, bottom, W, H], fill=self.panel)

        tag_f = font("segoeuib.ttf", 34)
        if slide.get("tag"):  # a slide with its own tag (an intro, say) is left out of the count
            tag = slide["tag"]
        else:
            counted = [s for s in self.slides if not s.get("tag")]
            tag = f"{self.tag}  {counted.index(slide) + 1} / {len(counted)}".strip()
        title_f, lines = self.fit_title(d, slide["title"], W - 100)
        line_h = int(title_f.size * 1.12)
        y = max(50, (top - (52 + line_h * len(lines))) // 2)
        d.text(((W - d.textlength(tag, font=tag_f)) / 2, y), tag, font=tag_f, fill=self.accent,
               stroke_width=3, stroke_fill="black")
        y += 52
        for line in lines:
            self.draw_title_line(d, line, title_f, y, self.accent)
            y += line_h

        d.rectangle([0, top - 4, W, top], fill=self.accent)
        d.rectangle([0, bottom, W, bottom + 4], fill=self.accent)

        point_f = font("segoeuib.ttf", 44)
        plines = self.wrap(d, slide["point"], point_f, W - 120)
        credit_f = font("segoeuib.ttf", 34)
        text_h = len(plines) * 58 + 70
        y = bottom + max(24, (WM_Y - 16 - bottom - text_h) // 2)
        for line in plines:
            d.text(((W - d.textlength(line, font=point_f)) / 2, y), line, font=point_f, fill="white",
                   stroke_width=3, stroke_fill="black")
            y += 58
        y += 22
        credit = slide["credit"]
        d.text(((W - d.textlength(credit, font=credit_f)) / 2, y), credit, font=credit_f,
               fill=(200, 200, 200), stroke_width=3, stroke_fill="black")
        if y + 48 > WM_Y:
            raise SystemExit(f"slide {no}: point/credit runs into the watermark row, shorten the point "
                             f"({len(plines)} lines): {slide['point']}")
        self.watermark(img)
        path = self.tmp / f"overlay_{no}.png"
        img.save(path)
        return path

    @staticmethod
    def probe(path):
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height",
             "-of", "csv=p=0", str(path)], capture_output=True, text=True, check=True).stdout
        has_audio, w, h = False, 0, 0
        for row in out.splitlines():
            cols = row.strip().split(",")
            if cols[0] == "audio":
                has_audio = True
            elif cols[0] == "video" and len(cols) >= 3:
                w, h = int(cols[1]), int(cols[2])
        return w, h, has_audio

    def build_clip(self, no, index, slide):
        src = self.root / slide["src"]
        start, dur = slide.get("start", 0), slide["dur"]
        if not 3 <= dur <= 60:
            raise SystemExit(f"slide {no}: Instagram carousel videos must be 3-60 s, got {dur}")
        w, h, has_audio = self.probe(src)
        video_h = round(W * h / w / 2) * 2
        png = self.overlay_png(no, index, slide, video_h)
        out = self.out / f"slide_{no}.mp4"
        vf = (
            f"[0:v]fps=30,split[a][b];"
            f"[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
            f"boxblur=28:4,eq=brightness=-0.22:saturation=1.1[bg];"
            f"[b]scale={W}:{video_h}:flags=lanczos[fg];"
            f"[bg][fg]overlay=0:{VIDEO_CY - video_h // 2}[v1];"
            f"[v1][1:v]overlay=0:0,format=yuv420p[v]"
        )
        cmd = ["ffmpeg", "-v", "error", "-y", "-ss", str(start), "-t", str(dur), "-i", str(src),
               "-loop", "1", "-t", str(dur), "-i", str(png)]
        if has_audio:
            # "loudnorm": true in carousel.json levels every clip to the same loudness (X clips can arrive 13 dB apart)
            level = "loudnorm=I=-18:TP=-2:LRA=11," if self.cfg.get("loudnorm") else ""
            af = f"[0:a]{level}afade=t=in:d=0.25,afade=t=out:st={max(0.0, dur - 0.4)}:d=0.4,aresample=48000[a]"
            cmd += ["-filter_complex", vf + ";" + af, "-map", "[v]", "-map", "[a]"]
        else:
            cmd += ["-f", "lavfi", "-t", str(dur), "-i", "anullsrc=r=48000:cl=stereo",
                    "-filter_complex", vf, "-map", "[v]", "-map", "2:a"]
        run(cmd + [*X264, "-crf", "19", "-c:a", "aac", "-b:a", "160k", "-t", str(dur), str(out)])
        print(f"slide {no}: {out.name} {dur}s (source {w}x{h}, audio={has_audio})")

    def build(self, only):
        if not only or "01" in only:
            self.build_cover()
        for i, slide in enumerate(self.slides, start=1):
            no = f"{i + 1:02d}"
            if not only or no in only:
                self.build_clip(no, i, slide)
        if not only or self.end_no in only:
            self.build_end()


if __name__ == "__main__":
    args = sys.argv[1:]
    out = None
    if "--out" in args:
        i = args.index("--out")
        out = args[i + 1]
        del args[i:i + 2]
    if not args:
        raise SystemExit(__doc__)
    Carousel(args[0], out).build(set(args[1:]))
