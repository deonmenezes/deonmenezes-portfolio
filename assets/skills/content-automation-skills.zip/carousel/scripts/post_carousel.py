"""Publish <project_dir>/out/slide_*.mp4 + caption.txt as one Instagram carousel on @deon_tech.

python post_carousel.py <project_dir> --check    # token, account, files and caption only; uploads nothing
python post_carousel.py <project_dir> --dry-run  # upload and build the carousel container, do not publish
python post_carousel.py <project_dir>            # upload (or reuse the dry run's uploads) and publish

State is kept in <project_dir>/tmp/post_state.json so a re-run never uploads or publishes twice.
Every item must be a video: they go up through rupload, which needs no public URL.
"""
import json
import re
import sys
import time
from pathlib import Path

import requests

CREDS = Path.home() / ".config" / "meta" / "credentials.env"
VERSION = "v21.0"
IG_USER = "YOUR_IG_BUSINESS_ACCOUNT_ID"   # your Instagram business account id
EXPECT_USERNAME = "YOUR_INSTAGRAM_USERNAME"
GRAPH = f"https://graph.facebook.com/{VERSION}"
MAX_ITEMS = 20  # app limit; 11 went through the API on 2026-10-06


def token():
    # The system-user token never expires and survives password changes (a user token dies when the
    # session is invalidated), so it goes first.
    env = {}
    for line in CREDS.read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"')
    for key in ("META_SYSTEM_USER_TOKEN", "META_ACCESS_TOKEN"):
        if env.get(key):
            return env[key]
    raise SystemExit(f"no META_SYSTEM_USER_TOKEN or META_ACCESS_TOKEN in {CREDS}")


def call(method, url, **kw):
    r = requests.request(method, url, timeout=600, **kw)
    try:
        body = r.json()
    except ValueError:
        body = {"raw": r.text[:300]}
    if r.status_code >= 300 or "error" in body:
        raise SystemExit(f"{method} {url.split('?')[0]} -> {r.status_code}: {json.dumps(body)[:600]}")
    return body


def wait_ready(cid, tok, label):
    start = time.time()
    while True:
        s = call("GET", f"{GRAPH}/{cid}", params={"fields": "status_code,status", "access_token": tok})
        code = s.get("status_code")
        if code in ("FINISHED", "PUBLISHED"):
            return code
        if code in ("ERROR", "EXPIRED"):
            raise SystemExit(f"{label}: {code} {s.get('status')}")
        if time.time() - start > 900:
            raise SystemExit(f"{label}: still {code} after 15 min")
        time.sleep(6)


def check_caption(caption):
    if len(caption) > 2200:
        raise SystemExit("caption is over Instagram's 2,200 characters")
    if len(re.findall(r"#\w+", caption)) > 30:
        raise SystemExit("caption has more than 30 hashtags")
    mentions = re.findall(r"(?<![\w.])@[\w.]+", caption)
    if mentions:
        print(f"WARNING: caption @-mentions {mentions}. On Instagram these tag whoever owns those names "
              f"there; write X handles without the @.")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        raise SystemExit(__doc__)
    root = Path(args[0]).resolve()
    out, state_file = root / "out", root / "tmp" / "post_state.json"
    check, dry = "--check" in sys.argv, "--dry-run" in sys.argv

    tok = token()
    me = call("GET", f"{GRAPH}/{IG_USER}", params={"fields": "username", "access_token": tok})
    if me["username"] != EXPECT_USERNAME:
        raise SystemExit(f"token points at @{me['username']}, expected @{EXPECT_USERNAME}")
    files = sorted(out.glob("slide_*.mp4"))
    if not 2 <= len(files) <= MAX_ITEMS:
        raise SystemExit(f"a carousel needs 2-{MAX_ITEMS} items, found {len(files)} in {out}")
    caption = (out / "caption.txt").read_text(encoding="utf-8").strip()
    check_caption(caption)
    state = json.loads(state_file.read_text()) if state_file.exists() else {"children": {}}
    if state.get("media_id"):
        raise SystemExit(f"already published: {state.get('permalink') or state['media_id']}")
    if check:
        print(f"ok: @{me['username']}, {len(files)} videos, caption {len(caption)} chars, nothing uploaded")
        return

    def save():
        state_file.parent.mkdir(exist_ok=True)
        state_file.write_text(json.dumps(state, indent=2))

    for f in files:
        child = state["children"].get(f.name)
        if not child:
            c = call("POST", f"{GRAPH}/{IG_USER}/media", data={
                "media_type": "VIDEO", "is_carousel_item": "true", "upload_type": "resumable",
                "access_token": tok})
            child = state["children"][f.name] = {"id": c["id"], "uploaded": False}
            save()
        if not child["uploaded"]:
            data = f.read_bytes()
            call("POST", f"https://rupload.facebook.com/ig-api-upload/{VERSION}/{child['id']}",
                 headers={"Authorization": f"OAuth {tok}", "offset": "0", "file_size": str(len(data))},
                 data=data)
            child["uploaded"] = True
            save()
        print(f"{f.name}: container {child['id']} {wait_ready(child['id'], tok, f.name)}", flush=True)

    if not state.get("carousel"):
        c = call("POST", f"{GRAPH}/{IG_USER}/media", data={
            "media_type": "CAROUSEL", "caption": caption,
            "children": ",".join(state["children"][f.name]["id"] for f in files),
            "access_token": tok})
        state["carousel"] = c["id"]
        save()
    code = wait_ready(state["carousel"], tok, "carousel")
    print(f"carousel container {state['carousel']} {code} ({len(files)} items)", flush=True)
    if dry:
        print("dry run: not published. The caption is now fixed in the container; "
              "delete tmp/post_state.json to change it.")
        return
    if code == "PUBLISHED":
        print("container already PUBLISHED; check the profile for the post")
        return
    pub = call("POST", f"{GRAPH}/{IG_USER}/media_publish",
               data={"creation_id": state["carousel"], "access_token": tok})
    state["media_id"] = pub["id"]
    save()
    info = call("GET", f"{GRAPH}/{pub['id']}",
                params={"fields": "permalink,media_type,children{media_type}", "access_token": tok})
    state["permalink"] = info.get("permalink")
    save()
    print(f"published: {state['permalink']} ({info.get('media_type')}, "
          f"{len(info.get('children', {}).get('data', []))} items)")


if __name__ == "__main__":
    main()
