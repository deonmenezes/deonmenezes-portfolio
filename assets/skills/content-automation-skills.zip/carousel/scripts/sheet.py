"""Timestamped contact sheet of a clip, for choosing in-points without watching it.

python sheet.py <video> <out.jpg>            # 20 frames across the whole clip
python sheet.py <video> <out.jpg> 7.2 9.0 8  # 8 frames between 7.2 s and 9.0 s (to find an exact cut)
"""
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    video, out = sys.argv[1], sys.argv[2]
    dur = float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video],
        capture_output=True, text=True, check=True).stdout.strip())
    start = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
    end = float(sys.argv[4]) if len(sys.argv) > 4 else dur
    n = int(sys.argv[5]) if len(sys.argv) > 5 else 20
    times = [start + (end - start) * i / n for i in range(n)]
    fnt = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 24)
    cols, tw, th = 5, 384, 216
    sheet = Image.new("RGB", (cols * tw, -(-n // cols) * th))
    with tempfile.TemporaryDirectory() as tmp:
        for i, t in enumerate(times):
            frame = Path(tmp) / f"{i}.png"
            # -ss after -i: slow but frame-exact, which matters when hunting a cut
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video, "-ss", f"{t:.3f}", "-frames:v", "1",
                            "-vf", f"scale={tw}:{th}:force_original_aspect_ratio=decrease,"
                                   f"pad={tw}:{th}:(ow-iw)/2:(oh-ih)/2", str(frame)], check=True)
            if not frame.exists():
                continue
            im = Image.open(frame)
            d = ImageDraw.Draw(im)
            label = f"{t:.1f}s"
            d.rectangle([0, 0, d.textlength(label, font=fnt) + 12, 32], fill="black")
            d.text((6, 3), label, font=fnt, fill="yellow")
            sheet.paste(im, ((i % cols) * tw, (i // cols) * th))
    sheet.save(out, quality=88)
    print(f"{out}: {n} frames, {start:.1f}-{end:.1f} s of {dur:.1f} s")


if __name__ == "__main__":
    main()
