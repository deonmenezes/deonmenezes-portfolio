// Paste into mcp__claude-in-chrome__javascript_tool on an x.com/search results tab (Deon's Chrome is logged in).
// Scrolls the results and returns one line per post: "/handle <status id> | likes | first 85 chars".
// Search URL pattern (URL-encode the q value):
//   https://x.com/search?q=<terms> filter:videos min_faves:2000 since:2026-09-20&src=typed_query&f=top
const seen = new Map();
const grab = () => document.querySelectorAll('article').forEach(a => {
  const link = [...a.querySelectorAll('a[href*="/status/"]')].map(x => x.getAttribute('href')).find(h => /^\/[^/]+\/status\/\d+$/.test(h));
  if (!link || seen.has(link)) return;
  const text = (a.querySelector('[data-testid="tweetText"]')?.innerText || '').replace(/\s+/g, ' ').slice(0, 85);
  const likes = (a.querySelector('[data-testid="like"], [data-testid="unlike"]')?.getAttribute('aria-label') || '').replace(/\D+/g, ' ').trim();
  seen.set(link, link.replace('/status/', ' ') + ' | ' + likes + ' | ' + text);
});
await new Promise(r => setTimeout(r, 2500));
for (let i = 0; i < 16; i++) { grab(); window.scrollBy(0, 1800); await new Promise(r => setTimeout(r, 900)); }
grab();
[...seen.values()].join('\n')
