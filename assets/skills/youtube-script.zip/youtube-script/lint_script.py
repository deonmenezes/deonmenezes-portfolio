"""Lint a YouTube narration script for generated-sounding writing.

Usage: python lint_script.py <script.py | script.txt>

script.py must define SEGMENTS = [(name, [beat, ...]), ...] (the format every video project uses).
A .txt file is treated as one segment with one beat per blank-line-separated paragraph.
Exit code 0 = OK, 1 = things to fix.

Every limit here was measured on five reference transcripts (ColdFusion: Dropbox, Flappy Bird,
AI industry; Founders: Claude Shannon, Elon) on 2026-10-04. It catches wording and rhythm only.
It cannot tell whether the script has a person, a question and a story, so a pass is not approval.
"""
import importlib.util
import re
import sys

# Zero hits across all five reference transcripts. (label, regex)
NEVER = [
    ("list-of-sections hook", r"\b(we'?ll|i'?ll|we'?re going to|i'?m going to) (break down|walk through|go through|cover|explain|explore|unpack|look at)\b[^.?!]*,[^.?!]*,"),
    ("list-of-sections hook", r"\b(we'?ll|i'?ll) (break down|walk through|explain what)\b"),
    ("stock opener", r"\blet'?s (dive|start with the basics|unpack|break (it|this) down)\b|\bover the next (few )?minutes\b"),
    ("announced reveal", r"\bnow for the part\b|\bthe (punchline|kicker)\b|\bchang\w+ everything\b|\blet that sink in\b|\bthe math gets\b"),
    ("three-for-rhythm", r"\bthree \w+,? (from |on |in |running on )?three \w+"),
    ("essay vocabulary", r"\b(delve|tapestry|leverag\w+|seamless\w*|game.?chang\w+|mind.?blowing|revolutionary|at its core|in essence|a world where)\b"),
]

# Things the references do, rarely: at most twice in a 3,000-word episode. Each is allowed
# once per RARE_EVERY words (minimum once). (label, regex)
RARE = [
    ("announced reveal ('here's the...', 'this is where...')", r"\bhere'?s (the|where|what|why)\b|\bthis is where\b|\bthat'?s where\b"),
    ("question answered by the script itself ('Why?', 'The result?')", r"(?:^|[.!?]\s+)(The (result|answer|catch|reason|problem)\?|Why\?|So what\?|Why \w+ though\?)"),
    ("'it wasn't X, it was Y'", r"\b(it'?s|that'?s|this is|it was|that was)(n'?t| not) [^.?!,]{2,40}[.,] (it'?s|it was|that'?s)\b"),
]
RARE_EVERY = 1500

# References run at 2.3-5.0 of these per 1000 words; the Rust script ran at 7.9.
INTENSIFIER = r"\b(genuinely|truly|incredibly|absolutely|completely|literally|wild|insane|insanely|ridiculous|hardcore|massive|fascinating|refreshingly|quietly|simply|essentially|ultimately|fundamentally|basically)\b"
INTENSIFIER_MAX = 5.0

# A bare "I" next to another single capital is a letter-spaced acronym ("A I", "I W four L"), not the narrator.
FIRST = r"(?<![A-Z] )\bI\b(?! [A-Z]\b)|\b(I'm|I've|I'd|I'll|my|me)\b"
QUOTE = r"\b(said|says|wrote|writes|told|called it|put it|quote|admit\w*|describ\w+|according to)\b"


def load(path):
    if path.endswith(".py"):
        spec = importlib.util.spec_from_file_location("script", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        segs = []
        for seg in mod.SEGMENTS:
            name, beats = (seg[0], seg[1]) if isinstance(seg, (tuple, list)) else (seg["name"], seg["beats"])
            # dict beats are real soundbites (clip audio), not narration: skip them
            segs.append((name, [b if isinstance(b, str) else b[0] for b in beats if not isinstance(b, dict)]))
        return segs
    text = open(path, encoding="utf-8").read()
    return [("text", [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()])]


def sentences(text):
    return [s for s in re.split(r"(?<=[.?!])\s+", text.strip()) if s]


def find(segs, rx):
    """All matches of rx as 'segment[beat]: ...context...' strings."""
    out = []
    for name, beats in segs:
        for i, beat in enumerate(beats):
            for m in re.finditer(rx, beat, flags=re.I):
                a, b = max(0, m.start() - 20), min(len(beat), m.end() + 30)
                out.append(f"{name}[{i}]: ...{beat[a:b].strip()}...")
    return out


def main(path):
    segs = load(path)
    beats = [b for _, bs in segs for b in bs]
    text = " ".join(beats)
    words = len(text.split())
    sents = sentences(text)
    per1k = lambda n: n * 1000 / max(words, 1)
    problems = 0

    print(f"{path}: {words} words, {len(beats)} beats, {len(sents)} sentences\n")

    print("Never (0 in the references):")
    seen = set()
    for label, rx in NEVER:
        for hit in find(segs, rx):
            where = hit.split(":")[0]  # one line per label per beat
            if (label, where) not in seen:
                seen.add((label, where))
                print(f"  FIX {label}  {hit}")
    problems += len(seen)
    if not seen:
        print("  ok")

    allowed = max(1, words // RARE_EVERY)
    print(f"\nRare (at most {allowed} each in a script this long):")
    for label, rx in RARE:
        hits = find(segs, rx)
        ok = len(hits) <= allowed
        problems += not ok
        print(f"  {'ok ' if ok else 'FIX'} {label}: {len(hits)}")
        if not ok:
            for h in hits:
                print(f"        {h}")

    hits = find(segs, INTENSIFIER)
    rate = round(per1k(len(hits)), 1)
    ok = rate <= INTENSIFIER_MAX
    problems += not ok
    print(f"\n  {'ok ' if ok else 'FIX'} intensifiers and filler adverbs: {rate:.1f} per 1000 words (want <= {INTENSIFIER_MAX:.0f})")
    if not ok:
        for h in hits:
            print(f"        {h}")

    first = per1k(len(re.findall(FIRST, text)))
    you = per1k(len(re.findall(r"\byou(r|'re|'ve|'ll)?\b", text, flags=re.I)))
    questions = per1k(sum(s.endswith("?") for s in sents))
    quotes = per1k(len(re.findall(QUOTE, text, flags=re.I)))
    short = 100 * sum(len(s.split()) <= 5 for s in sents) / max(len(sents), 1)
    # References: I 3-18, you 8-20, questions 2-5, quote verbs 3-7 (per 1000 words); short 10-16 %.
    checks = [
        ("narrator present: I / my per 1000 words", first, ">= 2.5", first >= 2.5),
        ("talks to the viewer: 'you' per 1000 words", you, ">= 6", you >= 6),
        ("questions per 1000 words", questions, ">= 1.5", questions >= 1.5),
        ("sources quoted: said/wrote/told per 1000 words", quotes, ">= 3", quotes >= 3),
        ("short sentences (<= 5 words), %", short, "9-20", 9 <= short <= 20),
    ]
    print("\nVoice and rhythm:")
    for label, val, want, ok in checks:
        problems += not ok
        print(f"  {'ok ' if ok else 'FIX'} {label:48s} {val:5.1f}   (want {want})")

    if len(beats) >= 8:
        # A paragraph that closes on a short verdict line, e.g. "The stakes are the entire difference."
        slogans = [(n, i, sentences(b)[-1]) for n, bs in segs for i, b in enumerate(bs)
                   if len(sentences(b)) >= 3 and len(sentences(b)[-1].split()) <= 7]
        share = 100 * len(slogans) / len(beats)
        print(f"\nRead these paragraph endings aloud ({share:.0f}% of beats close on a short line; cut any that are slogans):")
        for n, i, s in slogans:
            print(f"      {n}[{i}]: {s}")

    print("\nOK (wording only: check the question, the person and the story yourself)" if not problems
          else f"\n{problems} thing(s) to fix before voicing.")
    return 1 if problems else 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    sys.exit(main(sys.argv[1]))
