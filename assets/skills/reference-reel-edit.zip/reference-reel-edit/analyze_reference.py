"""Break down a reference reel: cuts, timestamped contact sheets, key frames, transcript, colours, sound design.
Usage: python analyze_reference.py <reference.mp4> <out_dir>
Outputs in out_dir: cuts.txt, sheet*.jpg (every 0.5s, 48 per sheet), tx.json + transcript printout,
audio.txt (music-bed / whoosh / sting hints). Read the sheets, then grab full-res frames of anything unclear."""
import sys, os, json, subprocess
import numpy as np, cv2
from PIL import Image, ImageDraw

src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)

# 1. cuts (scene > 0.22)
log = subprocess.run(["ffmpeg", "-i", src, "-vf", "select='gt(scene,0.22)',showinfo", "-an", "-f", "null", "-"],
                     capture_output=True, text=True).stderr
cuts = [float(x.split("pts_time:")[1].split()[0]) for x in log.splitlines() if "pts_time:" in x]
open(f"{out}/cuts.txt", "w").write(" ".join(f"{c:.3f}" for c in cuts))
print("cuts:", " ".join(f"{c:.2f}" for c in cuts))

# 2. contact sheets every 0.5s
cap = cv2.VideoCapture(src); fps = cap.get(5) or 30; n = int(cap.get(7))
W, H, cols, per = 150, 267, 12, 48
frames = []
for k in range(0, n, int(fps / 2)):
    cap.set(1, k); ok, fr = cap.read()
    if not ok: break
    frames.append((k / fps, Image.fromarray(cv2.cvtColor(cv2.resize(fr, (W, H)), cv2.COLOR_BGR2RGB))))
for s in range(0, len(frames), per):
    chunk = frames[s:s + per]
    S = Image.new("RGB", (W * cols, H * ((len(chunk) + cols - 1) // cols))); d = ImageDraw.Draw(S)
    for i, (t, im) in enumerate(chunk):
        x, y = (i % cols) * W, (i // cols) * H
        S.paste(im, (x, y)); d.rectangle((x, y, x + 34, y + 13), fill=(0, 0, 0)); d.text((x + 2, y + 1), f"{t:.1f}", fill=(255, 60, 60))
    S.save(f"{out}/sheet{s // per}.jpg", quality=85)
print("sheets:", (len(frames) + per - 1) // per)

# 3. transcript with word timings
try:
    from faster_whisper import WhisperModel
    m = WhisperModel("small.en", device="cpu", compute_type="int8")
    segs, _ = m.transcribe(src, word_timestamps=True)
    tx = []
    for sg in segs:
        print(f"{sg.start:6.2f}-{sg.end:6.2f} {sg.text}")
        tx.append(dict(s=sg.start, e=sg.end, t=sg.text, w=[(w.word, round(w.start, 2), round(w.end, 2)) for w in sg.words]))
    json.dump(tx, open(f"{out}/tx.json", "w"), indent=0)
except Exception as e:
    print("transcribe failed:", e)

# 4. sound design hints
import librosa
y, sr = librosa.load(src, sr=22050); hop = 512
rms = librosa.feature.rms(y=y, hop_length=hop)[0]; t = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop)
S = np.abs(librosa.stft(y, hop_length=hop))[:, :len(rms)]; f = librosa.fft_frequencies(sr=sr)
on = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop)[:len(rms)]
lines = []
tempo, _ = librosa.beat.beat_track(y=y, sr=sr); lines.append(f"tempo estimate: {float(np.atleast_1d(tempo)[0]):.1f} bpm")
dbfs = 20 * np.log10(rms / rms.max() + 1e-9)
silent = t[dbfs < -60]
lines.append(f"digital-silence spans (music stops / sting gaps): {np.round(silent[::10], 2).tolist()[:40]}")
for c in cuts:
    i = (t >= c - 0.15) & (t < c + 0.25)
    if not i.any(): continue
    tt = t[i][np.argmax(on[i])]; k = (t >= tt - 0.05) & (t < tt + 0.35)
    fl = float(librosa.feature.spectral_flatness(S=S[:, k]).mean()); hi = float(S[f > 4000][:, k].sum() / S[:, k].sum())
    tag = "WHOOSH/noise hit" if fl > 0.03 or hi > 0.33 else ""
    lines.append(f"cut {c:6.2f}: onset {on[i].max():5.1f} @ {tt:.2f} flatness {fl:.3f} hi>4k {hi:.2f} {tag}")
open(f"{out}/audio.txt", "w").write("\n".join(lines)); print("\n".join(lines))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-lavfi", "showspectrumpic=s=1600x300:legend=0:scale=log", f"{out}/spectrum.png"])
