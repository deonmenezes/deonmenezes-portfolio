#!/usr/bin/env python3
"""Sent-log for Deon's manual Instagram DMs. One JSON object per line in sent-log.jsonl next to this file.

  python dmlog.py start <campaign> --audience "who" --text "exact message"    record what a campaign is
  python dmlog.py add <campaign> <username> sent|skipped|failed [--note ".."]  one line per person, after the attempt
  python dmlog.py has <campaign> <username>                                    exit 0 if already sent, 1 if not
  python dmlog.py who <username>                                               everything ever logged for one person
  python dmlog.py report <campaign> [--targets file.txt]                       counts, and who in the targets is not sent
  python dmlog.py list                                                         every campaign with counts

Campaign ids look like <thing>-story-2026-10-05. Usernames are stored lowercase without the @.
Set DMLOG=<path> to use another file (for tests). It never holds cookies, tokens or thread ids.
"""
import argparse
import datetime
import json
import os
import pathlib
import sys

LOG = pathlib.Path(os.environ.get("DMLOG") or pathlib.Path(__file__).with_name("sent-log.jsonl"))


def load():
    if not LOG.exists():
        return []
    rows = []
    for n, line in enumerate(LOG.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except ValueError:   # a line torn by a crash or a full disk: keep the rest of the log usable
            print(f"WARNING: sent-log line {n} is damaged and was skipped; check it by hand before sending", file=sys.stderr)
    return rows


def append(row):
    with LOG.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%MZ")


def norm(u):
    return u.strip().lstrip("@").lower()


def people(rows, campaign):
    """Latest status per username in a campaign; 'sent' is never overwritten by a later 'failed'."""
    state = {}
    for r in rows:
        if r.get("kind") == "dm" and r["campaign"] == campaign:
            if state.get(r["user"], {}).get("status") == "sent":
                continue
            state[r["user"]] = r
    return state


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("start"); p.add_argument("campaign"); p.add_argument("--audience", required=True); p.add_argument("--text", required=True)
    p = sub.add_parser("add"); p.add_argument("campaign"); p.add_argument("user"); p.add_argument("status", choices=["sent", "skipped", "failed"]); p.add_argument("--note", default="")
    p = sub.add_parser("has"); p.add_argument("campaign"); p.add_argument("user")
    p = sub.add_parser("who"); p.add_argument("user")
    p = sub.add_parser("report"); p.add_argument("campaign"); p.add_argument("--targets")
    sub.add_parser("list")
    a = ap.parse_args()
    rows = load()

    if a.cmd == "start":
        if any(r.get("kind") == "campaign" and r["campaign"] == a.campaign for r in rows):
            sys.exit("campaign exists: " + a.campaign)
        append({"kind": "campaign", "campaign": a.campaign, "ts": now(), "audience": a.audience, "text": a.text})
        print("started", a.campaign)
    elif a.cmd == "add":
        u = norm(a.user)
        if a.status == "sent" and people(rows, a.campaign).get(u, {}).get("status") == "sent":
            sys.exit(u + " is already logged as sent in " + a.campaign + ": do not send again")
        append({"kind": "dm", "campaign": a.campaign, "user": u, "status": a.status, "ts": now(), "note": a.note})
        print(a.status, u)
    elif a.cmd == "has":
        st = people(rows, a.campaign).get(norm(a.user), {}).get("status", "none")
        print(st)
        sys.exit(0 if st == "sent" else 1)
    elif a.cmd == "who":
        u = norm(a.user)
        hit = [r for r in rows if r.get("kind") == "dm" and r["user"] == u]
        for r in hit:
            print(r["ts"], r["campaign"], r["status"], r.get("note", ""))
        if not hit:
            print("nothing logged for", u)
    elif a.cmd == "report":
        st = people(rows, a.campaign)
        meta = [r for r in rows if r.get("kind") == "campaign" and r["campaign"] == a.campaign]
        if meta:
            print("audience:", meta[0]["audience"]); print("text:\n" + meta[0]["text"] + "\n")
        for k in ("sent", "skipped", "failed"):
            names = sorted(u for u, r in st.items() if r["status"] == k)
            print(k, len(names), ", ".join(names))
            if k != "sent":
                for u in names:
                    if st[u].get("note"):
                        print("   ", u, "-", st[u]["note"])
        if a.targets:
            want = [norm(x) for x in pathlib.Path(a.targets).read_text(encoding="utf-8").split() if x.strip()]
            todo = [u for u in want if st.get(u, {}).get("status") != "sent"]
            print("targets", len(want), "| not sent", len(todo), ":", ", ".join(todo))
    else:
        camps = {}
        for r in rows:
            c = camps.setdefault(r["campaign"], {"sent": 0, "skipped": 0, "failed": 0, "last": ""})
            if r.get("kind") == "dm":
                c[r["status"]] += 1
            c["last"] = max(c["last"], r["ts"])
        for k, c in camps.items():
            print(k, "sent", c["sent"], "skipped", c["skipped"], "failed", c["failed"], "last", c["last"])
        if not camps:
            print("no campaigns logged yet")


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    main()
