// instagram-dm snippets. Each block is the body for ONE call of the browser script tool
// (mcp__claude-in-chrome__javascript_tool, action javascript_exec) on a tab already on https://www.instagram.com/.
// Edit the CONSTANTS at the top of a block, paste the block, run it. Top-level await is fine.
// Blocks A-H only READ. Blocks I-J are the only ones that touch a message box (J sends nothing by itself).
// Return summaries only: the tool blocks results that look like cookies or query strings, and no block here reads
// document.cookie, localStorage or any token. Never add that.

//=== A: whose session is this (run first, every time) ===
// x-ig-app-id below is instagram.com's own public web-client id (the same for every visitor), not a personal id.
const H = {'x-ig-app-id':'936619743392459','x-requested-with':'XMLHttpRequest'};
const j = await (await fetch('/api/v1/direct_v2/inbox/?persistentBadging=true&folder=&limit=1&thread_message_limit=1', {headers:H, credentials:'include'})).json();
JSON.stringify({viewer: j.viewer && j.viewer.username, pk: j.viewer && String(j.viewer.pk), pendingRequests: j.pending_requests_total})
// Must say viewer "deon_tech" (pk YOUR_IG_USER_PK). Anything else: stop.

//=== B: his live stories (last 24 h): pk, time, question stickers ===
const H = {'x-ig-app-id':'936619743392459','x-requested-with':'XMLHttpRequest'};
const ME = 'YOUR_IG_USER_PK';
const s = await (await fetch('/api/v1/feed/reels_media/?reel_ids=' + ME, {headers:H, credentials:'include'})).json();
const reel = (s.reels && s.reels[ME]) || (s.reels_media && s.reels_media[0]) || {items: []};
window.__live = Object.fromEntries(reel.items.map(i => [i.pk, i]));
JSON.stringify(reel.items.map(i => ({pk: i.pk, at: new Date(i.taken_at*1000).toISOString().slice(0,16), type: i.media_type, viewers: i.total_viewer_count || i.viewer_count,
  q: (i.story_questions||[]).map(x => x.question_sticker && x.question_sticker.question)})))
// A story video shows black in a screenshot. To see it, overlay image_versions2.candidates[0].url in an <img>.

//=== C: his archived stories (older than 24 h) ===
// First navigate the tab to https://www.instagram.com/archive/stories/ and wait 4 s, so the page itself calls day_shells.
const ME = 'YOUR_IG_USER_PK';
const e = performance.getEntriesByType('resource').filter(x => /day_shells/.test(x.name)).pop();
const u = new URL(e.name);
const H = {'x-ig-app-id':'936619743392459','x-requested-with':'XMLHttpRequest','x-asbd-id':'359341'};
const ajax = async (path) => {                         // the page's own query string is needed; keep it inside the page
  const q = new URLSearchParams(u.search); const p = new URL(path, location.origin);
  for (const [k,v] of p.searchParams) q.set(k, v);
  const r = await fetch(p.pathname + '?' + q.toString(), {headers:H, credentials:'include'});
  const t = await r.text();
  try { return JSON.parse(t.replace(/^for \(;;\);/, '')); } catch (err) { return {_bad: t.slice(0,100), _status: r.status}; }
};
const days = ((await ajax('/api/v1/archive/reel/day_shells/')).payload || {}).items || [];
const ids = days.slice(0, 10).map(d => d.id);          // archiveDay:<id>, newest first
const r = await fetch('/api/v1/feed/reels_media/?' + ids.map(i => 'reel_ids=' + encodeURIComponent(i)).join('&'), {headers:{'x-ig-app-id':'936619743392459','x-requested-with':'XMLHttpRequest'}, credentials:'include'});
const j = await r.json(); window.__arch = {}; const out = [];
for (const reel of Object.values(j.reels || {})) for (const i of reel.items || []) {
  window.__arch[i.pk] = i;
  out.push({pk: i.pk, at: new Date(i.taken_at*1000).toISOString().slice(0,16), type: i.media_type, viewers: i.total_viewer_count || i.viewer_count,
    q: (i.story_questions||[]).map(x => x.question_sticker && x.question_sticker.question), responses: ((i.story_question_responder_infos||[])[0]||{}).question_response_count});
}
JSON.stringify({status: r.status, days: days.length, out})
// Pick the story with Deon. Its pk is STORY_PK below. Only the newest 20 question-box answers come with it (block G).

//=== D: scan the inbox in the background (all of his threads since CUT) ===
// Both folders: '' = General, '0' = Primary. Message requests are NOT here (block H). About 1.1 s per page of 20 threads;
// ~90 pages covered 2.5 days. A single call dies at 45 s, so this starts a loop and returns at once. Poll with block E.
const CUT = Date.parse('<<CUT_ISO e.g. 2026-10-04T08:00:00Z>>') * 1000;      // microseconds
const FOLDERS = ['', '0'];
const ME = 'YOUR_IG_USER_PK';
const H = {'x-ig-app-id':'936619743392459','x-requested-with':'XMLHttpRequest'};
const sleep = ms => new Promise(r => setTimeout(r, ms));
window.__scan = {pages: 0, threads: 0, done: false, err: null, oldest: null, rows: {}};
(async () => {
  const S = window.__scan;
  for (const folder of FOLDERS) {
    let cursor = null;
    for (let n = 0; n < 160; n++) {
      let j;
      try {
        const r = await fetch('/api/v1/direct_v2/inbox/?persistentBadging=true&folder=' + folder + '&limit=20&thread_message_limit=10' + (cursor ? '&cursor=' + encodeURIComponent(cursor) : ''), {headers:H, credentials:'include'});
        if (!r.ok) { S.err = 'HTTP ' + r.status + ' folder "' + folder + '"'; return; }     // 429/401: stop, do not retry
        j = await r.json();
      } catch (e) { S.err = String(e); return; }
      S.pages++; let stop = false;
      for (const t of (j.inbox && j.inbox.threads) || []) {
        S.threads++; S.oldest = Number(t.last_activity_at);
        if (S.oldest < CUT) { stop = true; continue; }
        if (t.is_group || !(t.users && t.users.length === 1)) continue;
        const items = t.items || [];
        const mine = items.filter(it => String(it.user_id) === ME);
        const inbound = items.filter(it => String(it.user_id) !== ME && Number(it.timestamp) >= CUT).map(it => {
          const rs = it.reel_share || {};
          return {ts: Number(it.timestamp), ty: it.item_type, rt: rs.type || null, st: rs.media ? String(rs.media.pk || '') : null,
                  tx: ((it.text || rs.text || '') + '').replace(/\s+/g, ' ').slice(0, 80),
                  mineAfter: mine.filter(m => Number(m.timestamp) > Number(it.timestamp)).length};
        });
        if (inbound.length) S.rows[t.users[0].username] = {pk: String(t.users[0].pk), tid: t.thread_id, folder, inbound,
          lastMine: ((mine[0] && (mine[0].text || '')) + '').slice(0, 60)};
      }
      cursor = j.inbox && j.inbox.oldest_cursor;
      if (stop || !(j.inbox && j.inbox.has_older)) break;
      await sleep(1100);
    }
  }
  S.done = true;
})();
'scan started'

//=== E: poll the scan ===
const S = window.__scan;
JSON.stringify({pages: S.pages, threads: S.threads, done: S.done, err: S.err, people: Object.keys(S.rows).length,
  oldest: S.oldest ? new Date(S.oldest/1000).toISOString().slice(0,16) : null})
// Keep polling (wait 10-20 s between polls) until done is true. err set = stop and report it.

//=== F: build the recipient list from the finished scan ===
// MODE 'story'   : people whose thread has a reply to STORY_PK
// MODE 'keyword' : people whose inbound text matches KEYWORD (use only with a time window Deon gave)
// MODE 'names'   : exactly the usernames in NAMES (commenters, or a list Deon pasted); flags names with no thread
const MODE = 'story';
const STORY_PK = '<<story pk from block B or C>>';
const KEYWORD = /<<word>>/i;
const NAMES = [];
const S = window.__scan; const rows = S.rows; const out = [];
if (MODE === 'names') {
  for (const n of NAMES) out.push(rows[n] ? {u: n, tid: rows[n].tid, type: 'thread', tx: rows[n].inbound.slice(-1)[0].tx, mineAfter: rows[n].inbound.slice(-1)[0].mineAfter}
                                         : {u: n, tid: null, type: 'NO THREAD IN WINDOW', tx: '', mineAfter: 0});
} else for (const [u, v] of Object.entries(rows)) {
  const hit = v.inbound.filter(i => MODE === 'story' ? i.st === STORY_PK : KEYWORD.test(i.tx));
  if (hit.length) out.push({u, tid: v.tid, type: hit.map(i => i.rt || i.ty).join('+'), tx: hit.map(i => i.tx).join(' ; ').slice(0, 90), mineAfter: Math.max(...hit.map(i => i.mineAfter))});
}
const byType = {}; out.forEach(o => byType[o.type] = (byType[o.type] || 0) + 1);
window.__list = out;
JSON.stringify({scanDone: S.done, oldest: S.oldest ? new Date(S.oldest/1000).toISOString().slice(0,16) : null, n: out.length, byType, rows: out})
// type "reply" = he typed a reply to the story. Other types (reaction, an emoji) are NOT in "replied": show them to Deon
// as a separate count. mineAfter > 0 = he (or an automation) already wrote after their message: read that thread's tail.

//=== G: question-box answers (newest 20 only; the web cannot page further) ===
const STORY_PK = '<<archived story pk from block C>>';
const info = ((window.__arch || {})[STORY_PK] || {}).story_question_responder_infos;
const x = (info && info[0]) || {};
JSON.stringify({question: x.question, total: x.question_response_count, got: (x.responders || []).length, moreOnWeb: x.more_available,
  responders: (x.responders || []).map(r => ({u: r.user && r.user.username, pk: r.user && String(r.user.pk), a: (r.response || '').slice(0, 60)}))})
// total > got: the rest cannot be read here. Ask Deon for a screen recording of the Responses screen, or tell him he can
// send them from the phone (each card has a Reply button). Then match the usernames against block F with MODE 'names'.

//=== H: message requests (people who are not in the inbox folders; UI only) ===
// Step 1: navigate the tab to https://www.instagram.com/direct/requests/ and wait 5 s. Step 2: list the rows.
const rows = [...document.querySelectorAll('div[role="button"]')].filter(e => /·/.test(e.innerText || '') && (e.innerText || '').length < 400);
rows.map((e, i) => i + ': ' + e.innerText.replace(/\n+/g, ' / ').slice(0, 110)).join('\n')
// Step 3, for row N (set N): open it and read the thread. Opening clears the unread dot; no read receipt is sent.
// Replying inside a request ACCEPTS it, which shows Deon's activity status and read receipts to that person: tell Deon first.
//   const N = 0; const b = [...document.querySelectorAll('div[role="button"]')].filter(e => /·/.test(e.innerText || '') && (e.innerText || '').length < 400)[N];
//   const before = location.pathname; b.click();
//   for (let k = 0; k < 16 && location.pathname === before; k++) await new Promise(r => setTimeout(r, 400));
//   await new Promise(r => setTimeout(r, 1500));
//   const t = document.body.innerText; const m = t.match(/Accept message request from ([^?]*)\?/);
//   JSON.stringify({path: location.pathname, who: m && m[1], tail: t.slice(Math.max(0, t.lastIndexOf('View profile')), t.indexOf('Accept message request from')).slice(-300)})
// The "Hidden Requests" folder at the top of that page was never opened. Say so when the count matters.

//=== H2: commenters on one post, from the web session (UNTESTED: the endpoint was never run from this skill) ===
// Needs the post's numeric media pk. A shortcode (instagram.com/reel/<code>/) converts like this. Instagram's own comments
// endpoint may refuse or page oddly; if it fails, do not retry: use `python ~/.claude/skills/reel-automation/scripts/reel.py diag <post_id>`
// (newest 30 comments with what happened to each) or read the comments out of the open reel page.
const CODE = '<<shortcode>>';
const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
const PK = [...CODE].reduce((n, c) => n * 64n + BigInt(A.indexOf(c)), 0n).toString();
const H = {'x-ig-app-id':'936619743392459','x-requested-with':'XMLHttpRequest'};
const r = await fetch('/api/v1/media/' + PK + '/comments/?can_support_threading=true&permalink_enabled=false', {headers:H, credentials:'include'});
const j = r.ok ? await r.json() : {};
JSON.stringify({status: r.status, n: (j.comments || []).length, more: j.has_more_comments, comments: (j.comments || []).map(c => ({u: c.user && c.user.username, t: (c.text || '').slice(0, 60)}))})

//=== I: open one thread and put the message in the box (sends NOTHING) ===
// Before running: navigate the tab to https://www.instagram.com/direct/t/<tid>/ (tid from block F) and wait 10 s. The page is slow.
const WANT = '<<username>>';
const MARKER = '<<a phrase unique to this message, e.g. a code unique to this send>>';
const MSG = "<<message, real line breaks written as \n>>";
const sleep = ms => new Promise(r => setTimeout(r, ms));
let box = null; const t0 = Date.now();
while (Date.now() - t0 < 36000) {                       // wait for the box AND the right person on screen
  box = document.querySelector('[contenteditable=true][role=textbox]');
  if (box && document.body.innerText.includes(WANT)) break;
  box = null; await sleep(500);
}
if (!box) throw new Error('guard: thread for ' + WANT + ' not loaded');
await sleep(2500);
let p = box; for (let i = 0; i < 14 && p.parentElement; i++) { p = p.parentElement; if (p.innerText.length > 200) break; }
const before = p.innerText.replace(/\n{2,}/g, '\n');
if (before.includes(MARKER)) throw new Error('already sent to ' + WANT);       // the thread itself is the second duplicate guard
if (box.innerText.trim()) throw new Error('box not empty');
box.focus();
const dt = new DataTransfer(); dt.setData('text/plain', MSG);                    // paste keeps line breaks; typing \n would send early
box.dispatchEvent(new ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true}));
await sleep(1500);
if (box.innerText.replace(/\s+/g, ' ').trim() !== MSG.replace(/\s+/g, ' ').trim()) throw new Error('fill mismatch');
'filled for ' + WANT + ' | thread so far: ' + before.slice(-260)
// Then take a screenshot (the send only lands after one), read the thread tail it shows, and press Return or click the
// Send button where the screenshot shows it. Do not click by remembered coordinates: the window size changes them.

//=== J: confirm it went (run ~5 s after the send) ===
const MARKER = '<<same marker>>';
const box = document.querySelector('[contenteditable=true][role=textbox]');
let p = box; for (let i = 0; i < 14 && p.parentElement; i++) { p = p.parentElement; if (p.innerText.length > 200) break; }
const r = {boxEmpty: !box.innerText.trim(), inThread: p.innerText.includes(MARKER), tail: p.innerText.replace(/\n{2,}/g, '\n').slice(-60)};
JSON.stringify(r)
// sent = boxEmpty and inThread. A trailing "Sending" in the tail is normal for a second or two.
// boxEmpty false = the click did not register (seen 3 times in 13): screenshot, press Return or click again ONCE. Never paste twice.
