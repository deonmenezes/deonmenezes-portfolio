# A correction the builder can execute

Four fields, every time. One defect, one scoped change.

```
Revise [composition / scene] using BRIEF.md.
Location: global frame [210] ([7.00 s]).
Observed problem: [the cursor overlaps the result label].

Change only: [the cursor's post-press path. Depart at 204, reach the resting point by 210,
resting point inside the card with 24 px clearance from the result label, path clear of the label throughout].
Keep fixed: [press at 195, reveal at 210, card geometry, copy, audio cues; cursor holds at its destination through 419].

Render stills at [195, 210, 222, 240] and a moving preview of [180-249].
Check the intermediate frames for overlap and jumps.
Report the changed values and the output file names.
```

Priority when several are open: missing information and unreadable text, then timing, then visual detail.

The loop stays local:

```
observed defect -> one scoped edit -> the affected frames -> the surrounding scene boundary -> normal-speed playback
```
