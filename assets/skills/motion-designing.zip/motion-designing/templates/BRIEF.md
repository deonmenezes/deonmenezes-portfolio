# Motion brief: [piece name]

His words: "[exact request]"

## 1. Goal
Show: [the ONE thing this piece makes obvious, e.g. how the product exports a finished report]
Viewer: [who watches, where: LinkedIn feed, IG reel, product page]
Opening copy: [outcome, max eight words]
Closing copy: [one next action and where]

## 2. Delivery and assets
Composition: [name], [1080x1080 | 1920x1080 | 1080x1920], [30] fps, [N] frames ([s] s).
All timeline numbers are GLOBAL, inclusive frame numbers unless marked local.
Assets: [logo], [screens], [footage], [font], [music], [sfx]  (inspect sizes and font loading before building)
Missing / needs approval: [list]

## 3. Layout
Origin top-left, pixels. Background [#], text [#], accent [#]. Safe margin [64] px.
Headline box: x[ ], y[ ], width[ ]; [64] px, line height [1.1], max [2] lines. Longest expected copy: "[ ]".
Product card: x[ ], y[ ], w[ ], h[ ], radius[ ]. Logo space: [ ].
Layer order (back to front): [background, card, product content, cursor, headline].

## 4. Timeline (seconds | frames | event | owner)
| s | frame | event | owner of the screen |
| --- | --- | --- | --- |
| 0.0-0.6 | 0-18 | headline enters: offset 24 to 0, opacity 0 to 1, cubic ease-out | headline |
| 0.6-1.4 | 18-42 | card enters: offset 60 to 0, opacity 0 to 1 | card |
| 1.4-4.0 | 42-119 | hold, settled | headline then card |
| ... | ... | ... | ... |

Reading holds (from legible to gone): [text] [from s] [to s]
Scene boundaries: [scene] in-state [ ] / out-state [ ]

## 5. Sound cues
| frame | event | sound | note |
| --- | --- | --- | --- |
| [195] | press | click transient | hit offset from hitpoint.py |
| [210] | reveal | reveal accent | |
| [438] | closing hold | music settles | |

## 6. Review stages
1. Opening only: stills at frames [0, 18, 42, 60, 119] + moving preview. Check wrapping, margins, settled positions.
2. After approval: remaining scenes, stills at [ ] and boundary ranges [ ].
3. Sound pass, then full export + probe + normal-speed watch.

## Decisions taken without him (tell him)
- [ ]
