"""timeline.py - check a motion timeline before anything is built.

    python timeline.py timeline.json            table + checks; exit 1 if a check fails
    python timeline.py --s2f 0.6 --fps 30       quick conversion (also --f2s 195)

timeline.json:
{
  "fps": 30,
  "ref_fps": 60,                                  optional: also print frames at the reference's rate
  "length": 20.0,                                 seconds (optional)
  "events": [ {"t": 6.5, "name": "press registers"}, ... ],
  "holds":  [ {"name": "result label", "from": 7.8, "to": 14.0, "text": "report_q3.pdf saved"} ],
  "owners": [ {"what": "button", "from": 5.0, "to": 7.0}, {"what": "result", "from": 7.0, "to": 14.0} ],
  "scenes": [ {"name": "product", "from": 4.0, "to": 14.0}, ... ]
}
Times are seconds. "from" is when the text becomes LEGIBLE, not when its entrance starts.
A hold needs at least 0.3 s + 0.3 s per word (override per hold with "min", e.g. when his voice-over says the
same words while they are on screen, the viewer reads along and about 0.2 s per word is enough).
Owners are things that hold attention; cuts and entrances that hand over on the same frame are fine.
"""
import argparse, json, sys


def f(t, fps):
    return int(round(t * fps))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", nargs="?")
    ap.add_argument("--fps", type=float, default=30)
    ap.add_argument("--s2f", type=float)
    ap.add_argument("--f2s", type=int)
    a = ap.parse_args()
    if a.s2f is not None:
        print(f"{a.s2f} s = {a.s2f * a.fps:.2f} frames at {a.fps:g} fps (use {f(a.s2f, a.fps)})")
        return
    if a.f2s is not None:
        print(f"frame {a.f2s} = {a.f2s / a.fps:.4f} s at {a.fps:g} fps")
        return
    if not a.file:
        ap.error("give timeline.json, or --s2f / --f2s")

    J = json.load(open(a.file, encoding="utf-8"))
    fps, rf = J.get("fps", 30), J.get("ref_fps")
    fails, warns = [], []

    print(f"fps {fps}" + (f"   (reference {rf} fps)" if rf else ""))
    print(f"{'s':>8} {'frame':>6}" + (f" {'ref f':>6}" if rf else "") + "  event")
    ev = J.get("events", [])
    for e in ev:
        print(f"{e['t']:8.3f} {f(e['t'], fps):6d}" + (f" {f(e['t'], rf):6d}" if rf else "") + f"  {e['name']}")
    ts = [e["t"] for e in ev]
    if ts != sorted(ts):
        fails.append("events are out of order")
    seen = {}
    for e in ev:
        fr = f(e["t"], fps)
        if fr in seen:
            warns.append(f"'{e['name']}' and '{seen[fr]}' land on the same frame {fr}")
        seen[fr] = e["name"]

    L = J.get("length")
    if L:
        print(f"length {L} s = {f(L, fps)} frames (last frame {f(L, fps) - 1})")
        for e in ev:
            if e["t"] >= L:
                fails.append(f"'{e['name']}' at {e['t']} s is past the end")

    if J.get("holds"):
        print("\nreading holds")
    for h in J.get("holds", []):
        dur = h["to"] - h["from"]
        words = len(str(h.get("text", "")).split())
        need = h.get("min", 0.3 + 0.3 * words)
        ok = dur + 1e-9 >= need
        print(f"  {h['name']}: {h['from']:.2f}-{h['to']:.2f} s = {dur:.2f} s / {f(dur, fps)} frames, "
              f"{words} words, needs {need:.2f} s  {'ok' if ok else 'TOO SHORT'}")
        if not ok:
            fails.append(f"hold '{h['name']}' is {dur:.2f} s, needs {need:.2f} s")

    ow = sorted(J.get("owners", []), key=lambda o: o["from"])
    if ow:
        print("\nwho owns the screen")
    for o in ow:
        print(f"  {o['from']:6.2f}-{o['to']:6.2f} s  frames {f(o['from'], fps)}-{f(o['to'], fps) - 1}  {o['what']}")
    for x, y in zip(ow, ow[1:]):
        if y["from"] < x["to"] - 1e-9:
            fails.append(f"'{x['what']}' and '{y['what']}' both own the screen {y['from']:.2f}-{min(x['to'], y['to']):.2f} s")

    sc = J.get("scenes", [])
    if sc:
        print("\nscenes (global start frame; local frame n = global start + n)")
    for s in sc:
        g0 = f(s["from"], fps)
        inside = [e for e in ev if s["from"] <= e["t"] < s.get("to", 1e9)]
        print(f"  {s['name']}: global {g0}-{f(s.get('to', s['from']), fps) - 1}"
              + "".join(f"\n      {e['name']}: global {f(e['t'], fps)} = local {f(e['t'], fps) - g0}" for e in inside))
    for x, y in zip(sc, sc[1:]):
        if "to" in x and abs(x["to"] - y["from"]) > 1e-9:
            warns.append(f"scene '{x['name']}' ends {x['to']} s but '{y['name']}' starts {y['from']} s "
                         f"({'overlap: shortens the total' if y['from'] < x['to'] else 'gap'})")

    for w in warns:
        print(f"WARN  {w}")
    for x in fails:
        print(f"FAIL  {x}")
    print("PASS" if not fails else f"{len(fails)} check(s) failed")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
