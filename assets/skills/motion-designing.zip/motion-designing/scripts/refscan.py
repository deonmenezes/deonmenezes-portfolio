"""refscan.py - take a reference video apart for ONE motion decision.

    python refscan.py reference.mp4 [--out ref] [--fps 2] [--width 960]
        probe (size, fps, duration), an overview image every 1/fps s, ref/sheet.png with time + source frame
        under each image, and a REFERENCE.md skeleton to fill in.
    python refscan.py reference.mp4 --out ref --burst 3.2,7.5 [--span 0.5]
        every consecutive SOURCE frame from t-span to t+span for each time, ref/burst_<t>/ and a labelled sheet
        ref/burst_<t>.png. Use it around entrances, landings and cuts.

Labels are source frame numbers at the reference's own fps. Overview times are the sample times (k / fps).
"""
import argparse, glob, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _lane


def sheet(images, labels, out, cols=6, width=320):
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print("  (Pillow missing: no sheet, read the images directly)")
        return
    if not images:
        return
    ims = [Image.open(p).convert("RGB") for p in images]
    h = int(ims[0].height * width / ims[0].width)
    pad = 30
    rows = (len(ims) + cols - 1) // cols
    S = Image.new("RGB", (cols * width, rows * (h + pad)), (18, 18, 18))
    d = ImageDraw.Draw(S)
    try:
        font = ImageFont.truetype("arial.ttf", 18)
    except Exception:
        font = ImageFont.load_default()
    for i, (im, lab) in enumerate(zip(ims, labels)):
        x, y = (i % cols) * width, (i // cols) * (h + pad)
        S.paste(im.resize((width, h)), (x, y))
        d.text((x + 6, y + h + 5), lab, fill=(235, 235, 235), font=font)
    S.save(out)
    print(f"  sheet -> {out}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--out", default="ref")
    ap.add_argument("--fps", type=float, default=2.0)
    ap.add_argument("--width", type=int, default=960)
    ap.add_argument("--burst", help="comma-separated seconds")
    ap.add_argument("--span", type=float, default=0.5)
    a = ap.parse_args()

    info = _lane.probe(a.video)
    if "fps" not in info:
        raise SystemExit("no video stream")
    fps = info["fps"]
    os.makedirs(a.out, exist_ok=True)
    print(f"{a.video}: {info['width']}x{info['height']}, {info['fps_str']} ({fps:.3f} fps), "
          f"{info['duration']:.3f} s, about {info['frames']} frames, {info['codec']}"
          + (f", rotation {info['rotation']}" if info.get("rotation") else ""))
    scale = f"scale={a.width}:-2"

    with _lane.lane("motion refscan"):
        if not a.burst:
            od = os.path.join(a.out, "overview")
            os.makedirs(od, exist_ok=True)
            for f in glob.glob(os.path.join(od, "*.jpg")):
                os.remove(f)
            _lane.run(["ffmpeg", "-v", "error", "-y", "-threads", "2", "-i", a.video,
                       "-vf", f"fps={a.fps},{scale}", "-q:v", "3", os.path.join(od, "ref-%04d.jpg")])
            imgs = sorted(glob.glob(os.path.join(od, "ref-*.jpg")))
            labs = [f"{k / a.fps:6.2f}s  f{round(k / a.fps * fps)}" for k in range(len(imgs))]
            sheet(imgs, labs, os.path.join(a.out, "sheet.png"))
            md = os.path.join(a.out, "REFERENCE.md")
            if not os.path.exists(md):
                open(md, "w", encoding="utf-8").write(SKELETON.format(
                    v=a.video, w=info["width"], h=info["height"], fr=info["fps_str"], fps=fps,
                    d=info["duration"], n=info["frames"]))
                print(f"  skeleton -> {md}")
            print(f"  {len(imgs)} overview images -> {od}")
        else:
            for t in [float(x) for x in a.burst.split(",") if x.strip()]:
                t0 = max(0.0, t - a.span)
                n = int(round(2 * a.span * fps)) + 1
                bd = os.path.join(a.out, f"burst_{t:07.3f}")
                os.makedirs(bd, exist_ok=True)
                for f in glob.glob(os.path.join(bd, "*.jpg")):
                    os.remove(f)
                _lane.run(["ffmpeg", "-v", "error", "-y", "-threads", "2", "-ss", f"{t0:.4f}", "-i", a.video,
                           "-frames:v", str(n), "-vf", scale, "-q:v", "3", "-fps_mode", "passthrough",
                           os.path.join(bd, "f%03d.jpg")])
                imgs = sorted(glob.glob(os.path.join(bd, "f*.jpg")))
                f0 = round(t0 * fps)
                labs = [f"f{f0 + i}  {(f0 + i) / fps:.3f}s" for i in range(len(imgs))]
                sheet(imgs, labs, bd + ".png", cols=min(8, max(1, len(imgs))), width=240)
                print(f"  burst {t:.3f}s: source frames {f0}-{f0 + len(imgs) - 1} -> {bd}")


SKELETON = """# Reference: {v}

MEASURED by ffprobe: {w}x{h}, {fr} ({fps:.3f} fps), {d:.3f} s, about {n} frames.
All frame numbers below are SOURCE frames at {fps:.3f} fps.

The ONE job this reference has: [e.g. the card's controlled landing]

Label each value MEASURED (read off an extracted frame), ESTIMATED (eyeballed) or PROPOSED (our choice).

## Events
| event | source frame | time | how known |
| --- | --- | --- | --- |
| entrance starts | | | |
| landing | | | |
| text readable | | | |
| attention pulled away / cut | | | |

## The main object
- Box at start (x, y, w, h in source pixels):
- Box at landing:
- Direction, duration, scale change, opacity change, visible overshoot:
- What the movement reveals:

## Order of appearance
product -> headline -> supporting labels? (frames)

## Readable hold, and the state carried into the next shot

## Uncertain values and the frames needed to settle them

## Proposed shot with OUR assets (no copying of their logo, copy or screens)
layout, focal point, entrance, product response, reading hold; missing assets; questions for Deon
"""

if __name__ == "__main__":
    main()
