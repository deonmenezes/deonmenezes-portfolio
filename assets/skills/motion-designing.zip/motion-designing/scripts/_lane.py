"""Shared helpers: the video-edit render lane (when that skill is installed) and ffmpeg/ffprobe calls."""
import contextlib, json, os, subprocess, sys

VE = os.path.expanduser("~/.claude/skills/video-edit/scripts")
LOW = 0x00004000 if os.name == "nt" else 0          # BELOW_NORMAL_PRIORITY_CLASS


@contextlib.contextmanager
def lane(what):
    """Hold video-edit's machine-wide lane if it exists (this PC corrupts memory under parallel load); else no-op."""
    if os.path.isdir(VE):
        sys.path.insert(0, VE)
        try:
            import vkit
        except Exception:
            vkit = None
        if vkit is not None:
            with vkit.lane(what):
                os.environ["VK_LANE_HELD"] = "1"
                try:
                    yield
                finally:
                    os.environ.pop("VK_LANE_HELD", None)
                return
    yield


def run(cmd, check=True):
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=LOW)
    if check and p.returncode:
        raise SystemExit(f"FAILED ({p.returncode}): {' '.join(map(str, cmd))[:600]}\n{p.stderr[-1500:]}")
    return p


def probe(path):
    """width, height, fps (float), fps_str, duration, frames for the first video stream; audio-only files too."""
    r = run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path])
    j = json.loads(r.stdout)
    v = next((s for s in j.get("streams", []) if s.get("codec_type") == "video"), None)
    dur = float(j.get("format", {}).get("duration") or 0)
    out = {"duration": dur, "has_audio": any(s.get("codec_type") == "audio" for s in j.get("streams", []))}
    if v:
        fr = v.get("avg_frame_rate") or v.get("r_frame_rate") or "0/1"
        n, d = (fr.split("/") + ["1"])[:2]
        fps = float(n) / float(d) if float(d) else 0.0
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(sd["rotation"])
        w, h = int(v["width"]), int(v["height"])
        if abs(rot) in (90, 270):
            w, h = h, w
        out.update(width=w, height=h, fps=fps, fps_str=fr, rotation=rot,
                   frames=int(v.get("nb_frames") or round(dur * fps)), codec=v.get("codec_name"))
    return out


def audio(path, sr=48000):
    """mono float32 samples via ffmpeg (numpy array), and the sample rate"""
    import numpy as np
    p = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-map", "0:a:0", "-ac", "1", "-ar", str(sr),
                        "-f", "f32le", "-"], capture_output=True, creationflags=LOW)
    if p.returncode:
        raise SystemExit(f"could not read audio from {path}: {p.stderr.decode(errors='replace')[-800:]}")
    return np.frombuffer(p.stdout, dtype=np.float32), sr
