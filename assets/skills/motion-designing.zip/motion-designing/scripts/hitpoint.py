"""hitpoint.py - where is the audible hit in a sound, and does a mix really hit on its event frames?

    python hitpoint.py whoosh.wav                       first audible sound, strongest transient, peak
    python hitpoint.py whoosh.wav --event 195 --fps 30  + where to START the file so its hit lands on frame 195
    python hitpoint.py mix.wav --check 6.50,7.00        is there an onset within one frame of each time?

A soft lead-in or silence at the start moves the audible hit away from the file's start: place by the hit.
Any audio or video file ffmpeg can read works.
"""
import argparse, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _lane


def envelope(x, sr, win=0.005):
    import numpy as np
    n = max(1, int(sr * win))
    m = len(x) // n
    e = np.sqrt(np.mean(x[: m * n].reshape(m, n) ** 2, axis=1) + 1e-12)
    return 20 * np.log10(e), win


def onsets(db, win):
    """positive jumps in level over ~15 ms: a crude but honest transient detector"""
    import numpy as np
    k = 3
    d = np.zeros_like(db)
    d[k:] = db[k:] - db[:-k]
    d[d < 0] = 0
    return d


def main():
    import numpy as np
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--event", type=int, help="target frame for the hit")
    ap.add_argument("--fps", type=float, default=30)
    ap.add_argument("--check", help="comma-separated seconds that should each have an onset")
    ap.add_argument("--floor", type=float, default=40, help="audible = within this many dB of the peak")
    a = ap.parse_args()

    x, sr = _lane.audio(a.file)
    if not len(x):
        raise SystemExit("no audio samples")
    db, win = envelope(x, sr)
    peak_db = float(db.max())
    t_peak = float(np.argmax(db) * win)
    audible = np.nonzero(db > peak_db - a.floor)[0]
    t_first = float(audible[0] * win) if len(audible) else 0.0
    on = onsets(db, win)

    if a.check:
        frame = 1 / a.fps
        bad = 0
        for t in [float(s) for s in a.check.split(",") if s.strip()]:
            i0, i1 = int(max(0, t - frame) / win), int((t + frame) / win) + 1
            seg = on[i0:i1]
            j = int(np.argmax(seg)) if len(seg) else 0
            jump = float(seg[j]) if len(seg) else 0.0
            at = (i0 + j) * win
            lvl = float(db[min(len(db) - 1, i0 + j + 3)])
            ok = jump >= 6 and lvl > peak_db - a.floor
            bad += not ok
            print(f"  {t:.3f} s (frame {round(t * a.fps)}): biggest jump {jump:+.1f} dB at {at:.3f} s, "
                  f"level {lvl:.1f} dBFS  {'HIT' if ok else 'NO CLEAR ONSET'}")
        print("PASS" if not bad else f"{bad} time(s) without a clear onset")
        sys.exit(1 if bad else 0)

    # strongest transient = biggest level jump among loud frames
    mask = db > peak_db - 20
    cand = np.where(mask, on, 0)
    t_hit = float(np.argmax(cand) * win)
    print(f"{a.file}: {len(x) / sr:.3f} s, peak {peak_db:.1f} dBFS (5 ms RMS)")
    print(f"  first audible  {t_first:.3f} s   ({a.floor:g} dB under the peak)")
    print(f"  hit (transient){t_hit:.3f} s")
    print(f"  loudest point  {t_peak:.3f} s")
    if a.event is not None:
        te = a.event / a.fps
        start = te - t_hit
        print(f"  to land the hit on frame {a.event} ({te:.3f} s): start the file at {start:.3f} s "
              f"(frame {start * a.fps:.2f})" + ("  NOTE: before 0, trim the file's head instead" if start < 0 else ""))


if __name__ == "__main__":
    main()
