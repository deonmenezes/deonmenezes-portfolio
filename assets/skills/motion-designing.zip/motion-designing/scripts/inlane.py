"""inlane.py - run any heavy command (a Remotion render, an ffmpeg encode) inside video-edit's machine lane.

    python inlane.py npx remotion render Launch out/launch.mp4 --codec=h264 --concurrency=2

Waits for the lane if another render holds it; runs at below-normal priority; output streams through.
Without the video-edit skill installed it just runs the command.
"""
import os, subprocess, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _lane

if len(sys.argv) < 2:
    raise SystemExit(__doc__)
with _lane.lane("motion: " + " ".join(sys.argv[1:4])):
    cmd = sys.argv[1:]
    if os.name == "nt":
        cmd = ["cmd", "/c"] + cmd                      # npx is npx.cmd on Windows
    sys.exit(subprocess.call(cmd, creationflags=_lane.LOW))
