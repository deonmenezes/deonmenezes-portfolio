# motion-designing

A Claude Code skill by Deon Menezes (@deon_tech on Instagram, @DeonMen on X).

Plans and fixes anything that moves on screen (titles, product demos, logo reveals) as a brief with frame numbers: what enters, when it lands, how long it stays readable.

This is a copy of the skill he uses every day, shared from his talk on automating content with Claude Code.
More: https://deonmenezes.com/resources/content-automation

## Install

1. Unzip this file into `~/.claude/skills/`, so you end up with `~/.claude/skills/motion-designing/SKILL.md`.
2. Open Claude Code and ask for it by name, for example: "use the motion-designing skill".
3. Read SKILL.md once and change the parts that are about his setup to yours.

## Before you use it

- It was written for one person's machine and accounts. Paths, ids and account names are placeholders now:
  `<your-home>`, `<your-folder>`, `YOUR_..._ID`, `YOUR_..._TOKEN` and so on. Put your own in.
- No keys, tokens, passwords or private ids are included. Keep yours in your own `.env` or credentials file.
- Only text and code are included. Fonts, images, videos, sound files, model files and logs were left out,
  so anything that points at them needs your own copy (most fonts it names are free on Google Fonts).
- It mentions other skills, tools and project folders that are not in this zip. Treat those as examples of how
  he works, or skip those steps.
- "Deon", "he" and "his rules" in the text are the original owner. Read them as you.

## Files

  SKILL.md
  references/motion-rules.md
  references/remotion-lane.md
  scripts/_lane.py
  scripts/hitpoint.py
  scripts/inlane.py
  scripts/refscan.py
  scripts/timeline.py
  templates/BRIEF.md
  templates/correction.md
