# Motion rules, with numbers

Starting values, not laws. Every one gets tuned in playback, one parameter at a time, with the destination fixed.

## Time and frames

- Write timing in seconds, convert to frames at the chosen fps, keep both in the brief.
  0.5 s = 15 frames at 30 fps, 30 frames at 60 fps. 0.6 s entrance = 18 frames at 30 fps.
- Label every reference timestamp with its source fps. A 60 fps reference does not map frame-for-frame to a 30 fps
  output.
- Scene-local vs global frames: local frame 30 in a sequence starting at global 120 is global 150. Corrections and
  cue lists always use GLOBAL frames; say "local" explicitly when you mean it.
- Overlapping transitions shorten the total: account for the overlap when computing the film length.

## Entrances

- Main object first, supporting information after a small delay: try 0.1 s (3 frames at 30) between a headline and
  its label, then tune the order by eye.
- A starting pair that works for a card: vertical offset 60 px to 0 and opacity 0 to 1 over 0.8 s (24 frames),
  cubic ease-out, clamped endpoints. A headline: offset 24 px to 0 over 0.6 s.
- Springs: tune duration, damping, stiffness and overshoot one at a time, replaying the same entrance. Overshoot
  belongs to light, playful objects; text and product screens land clean.
- The landing frame is a promise: the next scene starts from that exact position, scale and highlight.

## Holds

- Count the hold from the frame the words become legible.
- 8 frames at 30 fps is 0.27 s: nobody reads that. A rough floor is 0.3 s + one word per 0.3 s for short text
  (a five-word headline needs about 1.8 s), more for unfamiliar names and numbers.
- During a hold, supporting motion stays quiet: a slow push of scale 1.00 to 1.03 over 3 s is enough. Use a linear
  interpolation over the hold, not a per-frame percentage (percentages compound).
- Read it aloud at normal speed. If the hold ends before you finish reading, extend it.

## A product action is an event

Starting state -> pointer on the control -> the press registers -> the result appears -> the result is held long
enough to read its name. Example at 30 fps:

```
4.0 s  frame 120  screen visible, card settled
5.0 s  frame 150  cursor sets off for the button
6.0 s  frame 180  cursor reaches the button
6.5 s  frame 195  press registers (cursor scale 1 at 192, 0.92 at 195, 1 at 201)
7.0 s  frame 210  result appears
7.8 s  frame 234  result label fully readable
14.0 s frame 420  closing shot begins
```

- The cursor path stays clear of text; record its waypoints. After the press it leaves to a resting point with
  clearance (24 px) from the result label.

## Ownership

- One thing owns the screen at a time. The button until it responds, then the result for the whole reading window.
- If a cursor crosses a headline during an entrance, delay one event or change the path.
- In a face or photo run, each face owns its beat; the speed-up (one beat, half beat, quarter beat) is fine only
  after the viewer has met the first two or three at full length.

## Blur

- Decide what blur adds to THIS fast move. Apply it during the entrance only, let it settle with the movement, keep
  the reading hold sharp. Check sampled frames for smeared text and trails that persist after landing.

## Copy and layout

- Short opening line (eight words max); the product demonstration carries the explanation. Anything needing
  several sentences gets its own scene.
- Design against the LONGEST copy you expect. Record: headline width, max lines, logo space, final positions.
- Check the real font in the rendered still (weight, spacing). Changing the headline means re-rendering its landing
  frame before reviewing the entrance in motion. Same for a longer product name in the close.
- Explicit line breaks only where they improve the reading.
- Keep essential content inside a safe margin (64 px on 1080 square; inside the platform UI zones on a 9:16 reel).

## Sound

- Every cue has an event frame: click on the press, reveal accent on the reveal, riser drop on the cut, shutter on
  each face, music settling on the closing hold.
- Files have lead-ins and silence: find the audible hit (`hitpoint.py`) and offset the file so the HIT lands on
  the frame, not the file start.
- Music and effects on separate tracks with their own placement and level. Check the loudest event, the quietest
  useful cue and the ending on headphones AND a phone speaker. Under speech, voices win (his house style: loud
  voices).

## Scene boundaries (longer films)

- Each scene has an incoming state and an outgoing state, written down. For a continuous transition the next scene
  starts from the previous one's final position, scale and highlighted field.
- Fonts, palette, spacing and recurring elements live in shared settings; any deliberate exception is recorded.
- Work one scene (or a small related group) at a time, each with its assets, purpose and boundary states.
- After a local edit, check BOTH neighbouring boundaries before watching the assembled film.
- Keep accepted entrance, cursor and text components for reuse; re-check their timing when assets or copy change.

## Lessons from his own edits

- A 25 s LinkedIn cut (2026-10-20): problem lines first; title card lands on a riser's drop + hit; a partner super
  with their logos; 18-face run locked to the music's bar downbeats (1 beat, then half, then quarter) ending on a
  grid that slams in on the downbeat with a shutter click; song ends on its own last hit. He asked for "WE ARE
  GIVING AWAY" over "WE GAVE AWAY" (present tense in titles) and for suspense under the opening problem.
