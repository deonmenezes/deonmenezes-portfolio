# Remotion lane: standalone launch clips from real product screens

For a short film built around ONE product action (export a report, generate an image, send a DM), square 1080x1080
or 16:9, about 20 s. Remotion renders React components per frame, which is the same pure-function-of-frame contract
as `anim.html`.

## Setup (once per project)

Needs Node.js, FFmpeg and FFprobe (all present on this PC: node 22, ffmpeg 7.1).

```bash
npx create-video --yes --blank <slug>-launch
cd <slug>-launch
npx remotion skills add          # pick Claude Code: installs Remotion's own agent guidance
npm run dev                      # preview studio
```

Layout: product assets in `public/`, the reference at `reference.mp4`, the brief at `BRIEF.md`, reference frames in
`frames/`, previews in `out/`.

On this PC a Remotion render is a heavy job (the PC corrupts memory under parallel load). Run every `render` and
`still` through the lane wrapper, with `--concurrency=2`:
`python ~/.claude/skills/motion-designing/scripts/inlane.py npx remotion render Launch out/launch.mp4 --codec=h264 --concurrency=2`

## Code rules

- Drive every animated value from `useCurrentFrame()` with `interpolate()` (clamped) or `spring()`. No CSS
  transitions or animations: they flicker in renders.
- Random variation only from `random(seed)`.
- Timing and layout as exported constants (seconds and frames side by side); entrance offset, destination, duration
  and spring config stored together.
- Scenes as `<Sequence from={...}>`; remember frames inside are LOCAL.
- `@remotion/transitions` overlaps scenes: subtract the overlap from the total duration.
- Motion blur via `@remotion/motion-blur` only on the entrance, never across a reading hold.
- Audio: separate `<Audio>` per cue with its own `startFrom`/`volume`, placed so the audible hit lands on the event.

## Commands

```bash
npx remotion still Launch out/opening.png --frame=60
npx remotion still Launch out/product.png --frame=240
npx remotion still Launch out/closing.png --frame=540
npx remotion render Launch out/transition.mp4 --frames=90-149 --codec=h264     # a boundary range
npx remotion render Launch out/launch.mp4 --codec=h264                          # the approved film
ffprobe -v error -select_streams v:0 -show_entries stream=width,height,avg_frame_rate,duration -of json out/launch.mp4
```

## First prompt to the builder (after BRIEF.md is saved)

```
Read BRIEF.md and the installed Remotion guidance.
Inspect public/ and confirm that the required assets are available.
Summarize the opening's layout, event frames, and animation curves.
Flag any conflicting requirements or missing inputs before implementation.
Implement only the first review stage specified in BRIEF.md.
Return the stills, moving preview, changed files, and checks performed.
Wait for approval before continuing.
```

## The sellable package (if Deon offers it as a service)

"Launch Clip": one feature, one approved script, one 20 s 1080x1080 MP4, one cover image from an approved frame,
one revision round (timing, copy, sound). The article used $150 as an illustrative pilot price; test it against
the real hours. Before starting: agree script, assets, deadline, payment, revision scope, where the client may use
it and whether it can go in his portfolio. During production send the three stills for direction approval, then
the moving preview, then the final. Feedback is tied to frame numbers. Make one complete sample first (own product
or one whose owner agreed) and time the whole job. Remotion's license allows commercial work for covered users:
check the current terms (https://github.com/remotion-dev/remotion/blob/main/LICENSE.md).
