"""Read-only snapshot of what is trending and how Deon's own reels are doing.

    python gather.py                 every source, compact text, ~1 min
    python gather.py --only my_reels,hn,github
    python gather.py --json          the raw items as JSON
    python gather.py --list          source names

It imports the collectors from <your-folder>/trending/server.py and calls them directly, so it
needs no running server. Nothing is written: the snapshot file the dashboard keeps
for 24 h view gains is NOT touched, so the gain column is not available here.
Each source runs with its own timeout and a failure is reported on one line.
"""
import importlib.util
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutTimeout

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
SERVER = "<your-folder>/trending/server.py"
TIMEOUT = 75  # seconds per source

spec = importlib.util.spec_from_file_location("trending_server", SERVER)
srv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(srv)
srv.save_json = lambda *a, **k: None  # never write into <your-folder>/trending/data


YT_CHANNEL = "YOUR_YOUTUBE_CHANNEL_ID"  # your channel id (UC...)


def my_youtube():
    """Own channel from its public RSS feed: the only keyless source with view counts."""
    import re
    xml = srv.http_get("https://www.youtube.com/feeds/videos.xml?channel_id=" + YT_CHANNEL)
    out = []
    for e in xml.split("<entry>")[1:16]:
        v = re.search(r'statistics views="(\d+)"', e)
        out.append({"title": re.search(r"<title>(.*?)</title>", e).group(1),
                    "time": re.search(r"<published>(.*?)</published>", e).group(1)[:10],
                    "views": int(v.group(1)) if v else None,
                    "url": re.search(r'<link rel="alternate" href="(.*?)"', e).group(1)})
    return out


EXTRA = {"my_youtube": (my_youtube, 0, "Your YouTube channel (public RSS)")}


def pick(name):
    return (srv.SOURCES.get(name) or EXTRA[name])[0]


def fmt(name, items):
    out = []
    for i in items:
        if name == "my_reels":
            out.append("%s | views %s reach %s saves %s shares %s likes %s comments %s | %s | %s" % (
                (i.get("time") or "")[:10], i.get("views"), i.get("reach"), i.get("saved"), i.get("shares"),
                i.get("likes"), i.get("comments"), i.get("url"), i.get("title")))
        else:
            bits = [str(i.get("title") or "")[:110]]
            for k in ("views", "likes", "plays", "traffic", "points", "comments", "today", "stars", "age", "channel", "source", "time"):
                if i.get(k) not in (None, "", 0):
                    bits.append("%s=%s" % (k, str(i[k])[:24]))
            if i.get("url"):
                bits.append(str(i["url"])[:90])
            out.append(" | ".join(bits))
    return out


def main():
    args = sys.argv[1:]
    if "--list" in args:
        print("\n".join(list(srv.SOURCES) + list(EXTRA)))
        return
    names = list(srv.SOURCES) + list(EXTRA)
    if "--only" in args:
        names = args[args.index("--only") + 1].split(",")
    limit = 12
    ex = ThreadPoolExecutor(max_workers=8)
    futs = {n: ex.submit(pick(n)) for n in names}
    result, t0 = {}, time.time()
    for n, f in futs.items():
        try:
            result[n] = {"items": f.result(timeout=max(1, TIMEOUT - (time.time() - t0)))}
        except FutTimeout:
            result[n] = {"error": "timed out after %ss" % TIMEOUT}
        except Exception as e:
            result[n] = {"error": "%s: %s" % (type(e).__name__, str(e)[:160])}
    if "--json" in args:
        print(json.dumps(result, ensure_ascii=False, default=str))
    else:
        print("snapshot %s" % time.strftime("%Y-%m-%d %H:%M %Z"))
        for n in names:
            r, label = result[n], (srv.SOURCES.get(n) or EXTRA[n])[2]
            if "error" in r:
                print("\n## %s FAILED: %s" % (n, r["error"]))
                continue
            print("\n## %s (%d items) - %s" % (n, len(r["items"]), label))
            for line in fmt(n, r["items"])[: 30 if n == "my_reels" else limit]:
                print("  " + line)
    ex.shutdown(wait=False, cancel_futures=True)
    import os
    sys.stdout.flush()
    os._exit(0)  # background fetch threads must not hold the process open


if __name__ == "__main__":
    main()
