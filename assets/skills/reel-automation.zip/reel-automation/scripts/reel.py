"""reel.py - the comment-to-DM automation for one @deon_tech reel, driven by a spec file.

    python reel.py new <slug>                     write flows/spec-<slug>.json from the template
    python reel.py check <spec>                   validate the spec (links live, no link in public replies ...)
    python reel.py status [n]                     the next-post slot and the newest n posts          (read-only)
    python reel.py arm <spec> [--apply]           put the spec on the Next Post Automation slot
    python reel.py attach <spec> <post_id|latest> [--apply] [--force]
                                                  put it on a posted reel, verify, save the record, disarm the slot
    python reel.py disarm [--apply]               switch the slot off
    python reel.py diag [n | post_id]             why a reel "isn't automated": steps of the last 30 comments each

<spec> is a slug (flows/spec-<slug>.json) or a path. Nothing is written to InstantDM without --apply.
The token is read from IDM_TOKEN, else from Chrome with extract_token2.py. It is never printed.
"""
import datetime, glob, json, os, re, subprocess, sys, urllib.error, urllib.request

HOME = "<your-home>/instantdm-api-docs"          # token extractor and the records of every live automation
FLOWS = HOME + "/flows"
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__))).replace("\\", "/")
API = "https://api.instantdm.com/"
DM_MAX_BYTES = 1000                                  # Meta's limit for one Instagram text message
DM_MAX_WORDS = 60                                    # Deon: "less words" (2026-10-08); links are not counted
LATEST_MAX_HOURS = 6                                 # `attach ... latest` distrusts a post older than this
# anything that reads as a link in a public line: a scheme, www, word.tld, or "dot com"
LINK = re.compile(r"https?://|www[.]|[a-z0-9-]+[.][a-z]{2,24}\b|\bdot\s+(com|io|ai|co)\b", re.I)
FOLLOW = re.compile(r"\bfollow(?:ing|ed|s)?\b(?![- ]up)(?!\s+(?:the|these|those)\s+steps)", re.I)
PLACEHOLDER = re.compile(r"<[^<>\n]+>|^\s*\d+[.]\s*[.]{3}\s*$", re.M)
URL = re.compile(r"https?://[^\s>\]]+")

for s in (sys.stdout, sys.stderr):
    s.reconfigure(encoding="utf-8", errors="replace")

_token = None


def token():
    global _token
    if _token:
        return _token
    t = os.environ.get("IDM_TOKEN", "").strip()
    if not t:
        r = subprocess.run([sys.executable, HOME + "/extract_token2.py"], capture_output=True, text=True, timeout=180)
        t = (r.stdout.strip().splitlines() or [""])[-1].strip()
    if not t:
        sys.exit("No InstantDM token. Chrome on this PC must be logged in to app.instantdm.com (the login lives in "
                 "your Chrome profile); ask Deon to log in, then run again.")
    _token = t
    return t


def call(path, method="GET", body=None):
    """The parsed JSON answer, or {"_http": code-or-"ERR", "_body": ...} for anything that is not one."""
    req = urllib.request.Request(API + path, data=json.dumps(body).encode() if body is not None else None, method=method)
    req.add_header("Authorization", token())         # the raw JWT, no "Bearer "
    if body is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            out = json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        return {"_http": e.code, "_body": e.read().decode("utf-8", "replace")[:300]}
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        return {"_http": "ERR", "_body": repr(e)[:200]}
    return out if isinstance(out, (dict, list)) else {"_http": "ERR", "_body": "empty answer"}


def failed(x):
    """Why an answer cannot be trusted as a read of an automation, or None."""
    if not isinstance(x, dict):
        return "not an object"
    if x.get("_http"):
        return "HTTP %s %s" % (x["_http"], x.get("_body", "")[:80]) + (
            " (token rejected: is Chrome still logged in to app.instantdm.com?)" if x["_http"] in (401, 403) else "")
    if not isinstance(unwrap(x).get("auto_reply"), dict):
        return "no auto_reply in the answer"
    return None


def unwrap(x):
    return x.get("data", x) if isinstance(x, dict) and isinstance(x.get("data"), dict) else x


def flow_on(raw):
    """A Flow Editor flow on this post. The API reports it beside `data`, not inside it."""
    d = unwrap(raw) if isinstance(raw, dict) else {}
    return bool((isinstance(raw, dict) and raw.get("flow_ids")) or d.get("flow_ids") or d.get("flow_editor"))


def summ(raw):
    x = unwrap(raw) if isinstance(raw, dict) else {}
    a = x.get("auto_reply") or {}
    dm0 = (a.get("dms") or [""])[0]
    tw = a.get("triger_words") or []
    return {"http": (raw.get("_http") if isinstance(raw, dict) else "ERR"), "enable": a.get("enable"),
            "followers_only": a.get("followers_only"), "automate_all": a.get("automate_all"),
            "triggers": tw[:4] + (["(+%d)" % (len(tw) - 4)] if len(tw) > 4 else []),
            "flow": flow_on(raw), "dm0": dm0[:70] if isinstance(dm0, str) else "(not text)"}


def show(label, raw):
    print(f"{label:8}", json.dumps(summ(raw), ensure_ascii=False))


def now():
    return datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M %Z")


# ------------------------------------------------------------------ spec

def spec_path(arg):
    if os.path.isfile(arg):
        return arg
    p = f"{FLOWS}/spec-{arg}.json"
    if not os.path.isfile(p):
        sys.exit(f"no spec at {arg} or {p}. Start one with: python reel.py new {arg}")
    return p


def load_spec(arg):
    p = spec_path(arg)
    s = json.load(open(p, encoding="utf-8-sig"))
    if not isinstance(s, dict):
        sys.exit(f"{p}: a spec is one JSON object")
    s["_path"] = p
    return s


def dm_text(s):
    dm = s.get("dm") or ""
    if isinstance(dm, list):
        dm = "\n".join(str(x) for x in dm)
    return str(dm).replace("{url}", s.get("url") or "").strip()


def strs(x):
    """True when x is a list of non-blank strings."""
    return isinstance(x, list) and bool(x) and all(isinstance(i, str) and i.strip() for i in x)


def variants(words):
    out = []
    for w in words:
        w = w.strip()
        for v in (w, w.lower(), w.upper(), w.capitalize(), w.title()):
            if v and v not in out:
                out.append(v)
    return out


def dm_urls(s):
    return [u.rstrip(".,;:!?'\"") for u in URL.findall(dm_text(s))]


def url_ok(u):
    try:
        req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status == 200, r.status
    except urllib.error.HTTPError as e:
        return False, e.code
    except Exception as e:
        return False, repr(e)[:80]


def dead_links(s):
    out = []
    for u in dm_urls(s):
        ok, st = url_ok(u)
        if not ok:
            out.append(f"link not live ({st}): {u}")
    return out


def check(s, gate_off=None, online=True):
    """Every problem that would make the automation wrong. An empty list means it may be armed."""
    bad = []
    dm = dm_text(s)
    all_comments = s.get("all_comments") is True
    if not re.fullmatch(r"[a-z0-9-]+", str(s.get("slug") or "")):
        bad.append("slug: lowercase letters, digits and dashes")
    if s.get("all_comments") not in (None, True, False):
        bad.append("all_comments: true or false")
    if not all_comments and not strs(s.get("keywords")):
        bad.append("keywords: a list with the word he says in the reel (no blanks), or set all_comments true")
    if not dm:
        bad.append("dm: empty")
    if "{url}" in json.dumps(s.get("dm", "")) and not s.get("url"):
        bad.append("dm uses {url} but url is empty")
    n = len(dm.encode("utf-8"))
    if n > DM_MAX_BYTES:
        bad.append(f"dm is {n} bytes; one Instagram message holds {DM_MAX_BYTES}. Shorten it")
    words = len(URL.sub(" ", dm).split())
    if words > DM_MAX_WORDS:
        bad.append(f"dm is {words} words; {DM_MAX_WORDS} at most. Deon: \"better in understand and lesss words\" (2026-10-08)")
    lines = [x.strip() for x in dm.splitlines() if x.strip()]
    top = next((i for i, x in enumerate(lines) if URL.search(x)), None)
    if top is not None and (top > 1 or len(URL.sub(" ", lines[top]).split()) > 1):
        bad.append("the link is the highlight: on its own line (a pointer emoji is fine), right under the opening line. "
                   "Deon: \"keep the link as highlight\" (2026-10-08)")
    m = FOLLOW.search(dm)
    if m:
        bad.append(f"dm says \"{dm[max(0, m.start() - 20):m.end() + 20].strip()}\": no follow request in the DM. The gate "
                   "does that job; Deon: \"dont request or beg for a follow\" (2026-10-04)")
    if not dm_urls(s):
        bad.append("dm has no link: what is being delivered?")
    if online:
        bad += dead_links(s)
    replies = s.get("replies")
    if not strs(replies) or not 3 <= len(replies) <= 6:
        bad.append("replies: a list of 3 to 6 public reply variants (no blanks)")
        replies = []
    nf = s.get("not_followed", [])
    if nf and not strs(nf):
        bad.append("not_followed: a list of lines (no blanks)")
        nf = []
    gate = s.get("gate") if isinstance(s.get("gate"), dict) else {}
    gate_lines = [str(gate.get("title") or ""), str(gate.get("description") or "")]
    for where, lines in (("replies", replies), ("not_followed", nf), ("gate", gate_lines)):
        for line in lines:
            if LINK.search(line):
                bad.append(f"{where}: a public line carries a link ({line!r}); the link goes only in the DM")
            if "\n" in line or len(line) > 80:
                bad.append(f"{where}: one short line each ({line[:40]!r}...)")
    for where, text in [("dm", dm)] + [("replies", x) for x in replies] + [("not_followed", x) for x in nf] + [("gate", x) for x in gate_lines]:
        if PLACEHOLDER.search(text):
            bad.append(f"{where}: template placeholder left in ({PLACEHOLDER.search(text).group(0).strip()!r})")
    if s.get("gate_on", True) is False:
        if not gate_off:
            bad.append("gate_on is false. The follow gate is ON for every reel unless Deon says to remove it for this one; "
                       "if he did, pass --gate-off \"<his words>\"")
    elif not all(x.strip() for x in gate_lines):
        bad.append("gate: title and description for the follow card")
    return bad


def body_from(s):
    b = json.load(open(SKILL + "/templates/base.json", encoding="utf-8"))
    a = b["auto_reply"]
    gate = s.get("gate") if isinstance(s.get("gate"), dict) else {}
    a.update({
        "enable": True,
        "automate_all": "true" if s.get("all_comments") is True else "false",
        "triger_words": [] if s.get("all_comments") is True else variants(s["keywords"]),
        "dm_template_type": "text", "enable_dm_reply": True, "enable_comment_reply": True,
        "dms": [dm_text(s)],
        "reply_comments": list(s["replies"]),
        "followers_only": s.get("gate_on", True) is not False,
    })
    if s.get("not_followed"):
        a["not_followed_comments"] = list(s["not_followed"])
    a["ask_follow"].update({"title": gate.get("title") or "", "description": gate.get("description") or ""})
    a["welcome_message"]["enabled"] = False
    b["platform"] = "instagram"
    return b


def preview(s, b):
    a = b["auto_reply"]
    print(f"reel       {s.get('reel', '')}")
    print(f"triggers   {'ALL comments' if a['automate_all'] == 'true' else a['triger_words']}")
    print(f"gate       {'ON  ' + a['ask_follow']['title'] + ' / ' + a['ask_follow']['description'] if a['followers_only'] else 'OFF'}")
    print(f"replies    {a['reply_comments']}")
    print(f"dm         {len(a['dms'][0].encode('utf-8'))} bytes")
    print("-" * 72 + "\n" + a["dms"][0] + "\n" + "-" * 72)


def guard(s, a, online=True):
    bad = check(s, gate_off=a.get("gate_off"), online=online)
    if bad:
        print("SPEC NOT OK:")
        for x in bad:
            print("  -", x)
        sys.exit(2)


def verify(back, b):
    """Keys of auto_reply that do not read back as sent. Every key is compared, public lines included."""
    if failed(back):
        return [failed(back)]
    got, want = unwrap(back)["auto_reply"], b["auto_reply"]
    return [k for k in want if got.get(k) != want[k]]


def gate_note(b, a):
    if b["auto_reply"]["followers_only"]:
        return "Follow gate ON."
    return f"Gate OFF on Deon's word: {a.get('gate_off')}."


def save(name, b, note, s):
    rec = dict(b)
    rec["_note"] = note
    rec["_spec"] = s["_path"]
    p = f"{FLOWS}/{name}.json"
    json.dump(rec, open(p + ".tmp", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    os.replace(p + ".tmp", p)
    return p


# ------------------------------------------------------------------ commands

def posts():
    r = call("ig-posts")
    if not isinstance(r, dict) or r.get("_http"):
        sys.exit("could not list the posts: " + (failed(r) or "unexpected answer"))
    return (r.get("posts_lists") or {}).get("data") or []


def age_hours(post):
    try:
        t = datetime.datetime.strptime(post.get("timestamp", ""), "%Y-%m-%dT%H:%M:%S%z")
        return (datetime.datetime.now(datetime.timezone.utc) - t).total_seconds() / 3600
    except ValueError:
        return None


def cmd_new(a):
    slug = a["args"][0]
    if not re.fullmatch(r"[a-z0-9-]+", slug):
        sys.exit("slug: lowercase letters, digits and dashes")
    p = f"{FLOWS}/spec-{slug}.json"
    if os.path.exists(p):
        sys.exit(f"{p} exists")
    s = json.load(open(SKILL + "/templates/spec.json", encoding="utf-8"))
    s["slug"] = slug
    json.dump(s, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", p, "- fill it in, then: python reel.py check", slug)


def cmd_check(a):
    s = load_spec(a["args"][0])
    guard(s, a)
    preview(s, body_from(s))
    print("SPEC OK")


def count(a, default):
    try:
        return int(a["args"][0]) if a["args"] else default
    except ValueError:
        sys.exit("give a number of posts")


def cmd_status(a):
    n = count(a, 5)
    show("SLOT", call("next-post?post_id=1"))
    for p in posts()[:n]:
        print(f"\n{p.get('id')}  {p.get('timestamp', '')[:16]}  {p.get('media_type')}  comments {p.get('comments_count')}  "
              f"{p.get('permalink', '')}\n         {(p.get('caption') or '').replace(chr(10), ' ')[:100]}")
        show("  AUTO", call("automate-post?post_id=%s" % p.get("id")))


def cmd_arm(a):
    s = load_spec(a["args"][0])
    guard(s, a)
    b = body_from(s)
    b["post_id"] = "1"
    preview(s, b)
    show("SLOT now", call("next-post?post_id=1"))
    if not a["apply"]:
        print("\nDRY RUN. Nothing sent. Re-run with --apply to arm the slot.")
        return
    r = call("next-post", "POST", b)
    print("POST    ", json.dumps(r, ensure_ascii=False)[:160])
    if isinstance(r, dict) and r.get("_http"):
        sys.exit("NOT ARMED: the write was refused")
    back = call("next-post?post_id=1")
    show("SLOT", back)
    diff = verify(back, b)
    if diff:
        sys.exit(f"NOT ARMED: the slot does not read back what was sent (differs in {diff})")
    note = f"NEXT-POST slot armed {now()} for the '{s.get('reel', s['slug'])}' reel from {os.path.basename(s['_path'])}. " + gate_note(b, a)
    print("ARMED. record:", save("next-post-" + s["slug"], b, note, s))
    print("The slot lands on WHATEVER he posts next (story and carousel included) and is sometimes lost. "
          f"When he says the reel is up:  python reel.py attach {s['slug']} latest --apply")


def cmd_attach(a):
    s = load_spec(a["args"][0])
    guard(s, a, online=False)                        # a link host that hiccups must not cost minutes here: see STOP below
    if len(a["args"]) < 2:
        sys.exit("attach <spec> <post_id|latest>")
    want = a["args"][1]
    plist = posts()
    post = plist[0] if want == "latest" and plist else next((p for p in plist if p.get("id") == want), None)
    if not post:
        sys.exit(f"post {want} is not in the newest {len(plist)} posts InstantDM lists; check the id with: python reel.py status")
    pid, cap = post["id"], (post.get("caption") or "")
    print(f"post       {pid}  {post.get('timestamp', '')[:16]}  {post.get('media_type')}  comments {post.get('comments_count')}")
    print(f"           {post.get('permalink', '')}\n           {cap.replace(chr(10), ' ')[:140]}")
    raw = call("automate-post?post_id=" + pid)
    show("POST now", raw)
    if failed(raw):
        sys.exit("Not attached: could not read what is on the post now (" + failed(raw) + ")")
    slot = call("next-post?post_id=1")
    show("SLOT now", slot)
    b = body_from(s)
    b.update({"post_id": pid, "flow_editor": False, "flow_ids": {}})
    stop = dead_links(s)
    if s.get("all_comments") is not True and not any(
            re.search(r"(?<!\w)" + re.escape(k.strip()) + r"(?!\w)", cap, re.I) for k in s["keywords"]):
        stop.append(f"the caption does not contain any of {s['keywords']} as a word: is this the right post?")
    if want == "latest":
        h = age_hours(post)
        if post.get("media_type") != "VIDEO":
            stop.append(f"the newest post is a {post.get('media_type')}, not a reel")
        if h is None or h > LATEST_MAX_HOURS:
            stop.append(f"the newest post is {'of unknown age' if h is None else '%.0f h old' % h}: has the reel really gone up? "
                        "Give its post id if this is the one")
    if flow_on(raw):
        stop.append("a Flow Editor flow is attached to this post; a quick automation on top would DM people twice. Delete the flow first")
    cur_a = unwrap(raw)["auto_reply"]
    if cur_a.get("enable") and cur_a.get("dms") and cur_a.get("dms") != b["auto_reply"]["dms"]:
        stop.append("this post already has a different automation switched on (see POST now)")
    for x in stop:
        print("STOP:", x)
    if stop and not a["force"]:
        sys.exit("Not attached. If you are sure, add --force.")
    if not a["apply"]:
        print("\nDRY RUN. Nothing sent. Re-run with --apply to attach.")
        return
    r = call("automate-post", "POST", b)
    print("ATTACH  ", json.dumps(r, ensure_ascii=False)[:160])
    if isinstance(r, dict) and r.get("_http"):
        sys.exit("NOT ATTACHED: the write was refused")
    back = call("automate-post?post_id=" + pid)
    show("POST", back)
    diff = verify(back, b)
    if diff or flow_on(back):
        sys.exit(f"NOT ATTACHED: the post does not read back what was sent (differs in {diff or 'a flow is on it'})")
    note = (f"Quick automation for the '{s.get('reel', s['slug'])}' reel ({post.get('permalink', '')}, posted {post.get('timestamp', '')}), "
            f"attached {now()} with {post.get('comments_count')} comments already on the post, from {os.path.basename(s['_path'])}. "
            + gate_note(b, a))
    print("ATTACHED. record:", save("quick-" + pid, b, note, s))
    n = post.get("comments_count") or 0
    if n:
        print(f"NOTE: {n} comment(s) were on the post before this. InstantDM has no backfill: run `python reel.py diag {pid}` "
              "and tell Deon how many keyword comments got nothing.")
    # the slot fires on any next post: switch it off, but only if it is still holding THIS reel's automation
    if failed(slot):
        sys.exit("ATTACHED, but the slot could not be read (" + failed(slot) + "): it may still be armed. Run: python reel.py disarm --apply")
    sa = unwrap(slot)["auto_reply"]
    if not sa.get("enable"):
        print("SLOT     already off")
    elif sa.get("dms") != b["auto_reply"]["dms"]:
        print("SLOT     holds a different automation (another reel's): left armed")
    else:
        disarm(apply=True)


def disarm(apply):
    raw = call("next-post?post_id=1")
    if failed(raw):
        sys.exit("SLOT NOT READ (" + failed(raw) + "): it may still be armed")
    slot = unwrap(raw)
    if not slot["auto_reply"].get("enable"):
        print("SLOT     already off")
        return
    if not apply:
        show("SLOT now", raw)
        print("DRY RUN. Re-run with --apply to switch it off.")
        return
    base = json.load(open(SKILL + "/templates/base.json", encoding="utf-8"))
    off = {k: slot.get(k, v) for k, v in base.items()}           # only the fields a client sends, not the server's own
    off["auto_reply"] = {k: slot["auto_reply"].get(k, v) for k, v in base["auto_reply"].items()}
    off["auto_reply"]["enable"] = False
    off.update({"post_id": "1", "platform": "instagram"})
    print("DISARM  ", json.dumps(call("next-post", "POST", off), ensure_ascii=False)[:120])
    back = call("next-post?post_id=1")
    show("SLOT", back)
    if failed(back) or unwrap(back)["auto_reply"].get("enable"):
        sys.exit("SLOT STILL ARMED (or unreadable): it will land on whatever is posted next. Try again, or switch it off in the app "
                 "(Instagram DM > Next Post Automation)")
    for p in glob.glob(FLOWS + "/next-post-*.json"):             # keep the record on disk honest
        try:
            rec = json.load(open(p, encoding="utf-8"))
            if rec.get("auto_reply", {}).get("dms") == slot["auto_reply"].get("dms") and "disarmed" not in rec.get("_note", ""):
                rec["_note"] = rec.get("_note", "") + f" Slot disarmed {now()}."
                json.dump(rec, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        except (OSError, ValueError):
            pass


def cmd_disarm(a):
    disarm(a["apply"])


def cmd_diag(a):
    arg = a["args"][0] if a["args"] else "3"
    plist = posts()
    chosen = [p for p in plist if p.get("id") == arg] or ([{"id": arg}] if len(arg) > 6 else plist[:count(a, 3)])
    h = unwrap(call("get-health-status"))
    today = datetime.datetime.now(datetime.timezone.utc)
    for i in (h.get("issues") or []) if isinstance(h, dict) else []:
        last = str(i.get("last_error_at") or "")
        try:
            age = (today - datetime.datetime.fromisoformat(last)).days
        except ValueError:
            age = None
        print(f"HEALTH   {str(i.get('category')):32} errors {str(i.get('error_count')):<5} last {last[:16]}"
              + ("  (stale)" if age is not None and age > 3 else ""))
    for p in chosen:
        pid = p.get("id")
        print(f"\n=== {pid}  {p.get('timestamp', '')[:16]}  comments {p.get('comments_count')}  "
              f"{(p.get('caption') or '').replace(chr(10), ' ')[:80]}")
        show("  AUTO", call("automate-post?post_id=%s" % pid))
        c = call("ig-post-comments?post_id=%s" % pid)
        if isinstance(c, dict) and c.get("_http"):
            print("  comments not read:", failed(c))
            continue
        items = (unwrap(c) or {}).get("items") or []
        tally = {}
        for r in items:
            key = " + ".join(r.get("steps") or []) or "(no steps: no keyword in the comment, or not processed)"
            if r.get("reason"):
                key += "  [" + str(r["reason"])[:90] + "]"
            tally[key] = tally.get(key, 0) + 1
        print(f"  last {len(items)} comments InstantDM saw:")
        for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
            print(f"    {v:3}  {k}")
    show("\nSLOT", call("next-post?post_id=1"))
    print("\nReading it: 'DM Sent' = delivered. 'DM not sent' with 1545133 = the follow gate held back a non-follower "
          "(expected, not an outage). 'Comment Not enabled' = no public reply was posted under that comment, so the "
          "reel can look dead while DMs are going out. No steps = the comment had no keyword.")


def main():
    argv = sys.argv[1:]
    a = {"gate_off": None}
    if "--gate-off" in argv:
        i = argv.index("--gate-off")
        if i + 1 >= len(argv) or argv[i + 1].startswith("--") or not argv[i + 1].strip():
            sys.exit("--gate-off needs his exact words, in quotes")
        a["gate_off"] = argv[i + 1]
        del argv[i:i + 2]
    a["apply"], a["force"] = "--apply" in argv, "--force" in argv
    argv = [x for x in argv if x not in ("--apply", "--force")]
    cmds = {"new": cmd_new, "check": cmd_check, "status": cmd_status, "arm": cmd_arm, "attach": cmd_attach,
            "disarm": cmd_disarm, "diag": cmd_diag}
    if not argv or argv[0] not in cmds or (argv[0] in ("new", "check", "arm", "attach") and len(argv) < 2):
        sys.exit(__doc__)
    a["args"] = argv[1:]
    cmds[argv[0]](a)


if __name__ == "__main__":
    main()
